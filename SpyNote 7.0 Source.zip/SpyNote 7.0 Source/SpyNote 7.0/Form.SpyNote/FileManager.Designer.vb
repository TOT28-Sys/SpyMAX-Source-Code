﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FileManager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BOXDOWN = New System.Windows.Forms.PictureBox()
        Me.ProgressBar1 = New SpyNote_7._0.SN.ThemeProgressBar()
        Me.PNLTOP = New System.Windows.Forms.Panel()
        Me.PNL1 = New System.Windows.Forms.Panel()
        Me.ONLICON = New System.Windows.Forms.Panel()
        Me.Camera = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine5 = New SpyNote_7._0.SN.LinearLine()
        Me.Screenshots = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine4 = New SpyNote_7._0.SN.LinearLine()
        Me.DIRECTORY_PICTURES = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine2 = New SpyNote_7._0.SN.LinearLine()
        Me.DIRECTORY_DCIM = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine1 = New SpyNote_7._0.SN.LinearLine()
        Me.DIRECTORY_DOWNLOADS = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine3 = New SpyNote_7._0.SN.LinearLine()
        Me.StorageDirectory = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.TSEP0 = New SpyNote_7._0.SN.ThemeSeparator()
        Me.BTNBACK0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.BTNNEXT0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.TEXTPATH = New SpyNote_7._0.SN.ThemeTextBox()
        Me.PNLERRORS = New System.Windows.Forms.Panel()
        Me.LBER = New System.Windows.Forms.Label()
        Me.PN = New System.Windows.Forms.Panel()
        Me.PCNOTF = New System.Windows.Forms.PictureBox()
        Me.cntxDowManager = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenTheFileUsingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RenameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetWallpaperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Download02ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediaPlayerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZipToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnZipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewImge = New System.Windows.Forms.PictureBox()
        Me.ViewManager = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VisualStudioHorizontalScrollBar1 = New SpyNote_7._0.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar1 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.Trans = New System.Windows.Forms.Timer(Me.components)
        Me.Transdown = New System.Windows.Forms.Timer(Me.components)
        Me.TProgressBar = New System.Windows.Forms.Timer(Me.components)
        Me.TScrolls = New System.Windows.Forms.Timer(Me.components)
        Me.SELCT_PK = New System.Windows.Forms.ContextMenuStrip(Me.components)
        CType(Me.BOXDOWN, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PNLTOP.SuspendLayout()
        Me.PNL1.SuspendLayout()
        Me.ONLICON.SuspendLayout()
        Me.PNLERRORS.SuspendLayout()
        Me.PN.SuspendLayout()
        CType(Me.PCNOTF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cntxDowManager.SuspendLayout()
        CType(Me.ViewImge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ViewManager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BOXDOWN
        '
        Me.BOXDOWN.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BOXDOWN.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BOXDOWN.Location = New System.Drawing.Point(0, 404)
        Me.BOXDOWN.Name = "BOXDOWN"
        Me.BOXDOWN.Size = New System.Drawing.Size(633, 18)
        Me.BOXDOWN.TabIndex = 0
        Me.BOXDOWN.TabStop = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Animated = True
        Me.ProgressBar1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.ProgressBar1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.ProgressBar1.Customization = "AAAAAAAAAAAAAAAAAAAAAA=="
        Me.ProgressBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ProgressBar1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.ProgressBar1.Image = Nothing
        Me.ProgressBar1.Location = New System.Drawing.Point(0, 394)
        Me.ProgressBar1.Maximum = 100
        Me.ProgressBar1.Minimum = 0
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.NoRounding = False
        Me.ProgressBar1.Size = New System.Drawing.Size(633, 10)
        Me.ProgressBar1.TabIndex = 4
        Me.ProgressBar1.Text = "ThemeProgressBar1"
        Me.ProgressBar1.Transparent = False
        Me.ProgressBar1.Value = 0
        '
        'PNLTOP
        '
        Me.PNLTOP.Controls.Add(Me.PNL1)
        Me.PNLTOP.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNLTOP.Location = New System.Drawing.Point(0, 0)
        Me.PNLTOP.Name = "PNLTOP"
        Me.PNLTOP.Size = New System.Drawing.Size(633, 51)
        Me.PNLTOP.TabIndex = 5
        '
        'PNL1
        '
        Me.PNL1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.PNL1.Controls.Add(Me.ONLICON)
        Me.PNL1.Controls.Add(Me.TSEP0)
        Me.PNL1.Controls.Add(Me.BTNBACK0)
        Me.PNL1.Controls.Add(Me.BTNNEXT0)
        Me.PNL1.Controls.Add(Me.TEXTPATH)
        Me.PNL1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNL1.Location = New System.Drawing.Point(0, 0)
        Me.PNL1.Name = "PNL1"
        Me.PNL1.Size = New System.Drawing.Size(633, 51)
        Me.PNL1.TabIndex = 0
        '
        'ONLICON
        '
        Me.ONLICON.Controls.Add(Me.Camera)
        Me.ONLICON.Controls.Add(Me.LinearLine5)
        Me.ONLICON.Controls.Add(Me.Screenshots)
        Me.ONLICON.Controls.Add(Me.LinearLine4)
        Me.ONLICON.Controls.Add(Me.DIRECTORY_PICTURES)
        Me.ONLICON.Controls.Add(Me.LinearLine2)
        Me.ONLICON.Controls.Add(Me.DIRECTORY_DCIM)
        Me.ONLICON.Controls.Add(Me.LinearLine1)
        Me.ONLICON.Controls.Add(Me.DIRECTORY_DOWNLOADS)
        Me.ONLICON.Controls.Add(Me.LinearLine3)
        Me.ONLICON.Controls.Add(Me.StorageDirectory)
        Me.ONLICON.Location = New System.Drawing.Point(6, 23)
        Me.ONLICON.Name = "ONLICON"
        Me.ONLICON.Size = New System.Drawing.Size(499, 20)
        Me.ONLICON.TabIndex = 14
        '
        'Camera
        '
        Me.Camera.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Camera.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Camera.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Camera.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Camera.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Camera.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Camera.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Camera.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Camera.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Camera.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Camera.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Camera.Dock = System.Windows.Forms.DockStyle.Left
        Me.Camera.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Camera.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.Camera.ImageChoice = Nothing
        Me.Camera.Location = New System.Drawing.Point(142, 0)
        Me.Camera.Name = "Camera"
        Me.Camera.ShowImage = False
        Me.Camera.ShowText = False
        Me.Camera.Size = New System.Drawing.Size(20, 20)
        Me.Camera.TabIndex = 22
        Me.Camera.Text = "ThemeButtonImge1"
        Me.Camera.TextAlignment = System.Drawing.StringAlignment.Center
        Me.Camera.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Camera.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Camera.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine5
        '
        Me.LinearLine5.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine5.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine5.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine5.Location = New System.Drawing.Point(134, 0)
        Me.LinearLine5.Name = "LinearLine5"
        Me.LinearLine5.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine5.TabIndex = 21
        Me.LinearLine5.Text = "LinearLine5"
        '
        'Screenshots
        '
        Me.Screenshots.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Screenshots.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Screenshots.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Screenshots.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Screenshots.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Screenshots.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Screenshots.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Screenshots.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Screenshots.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Screenshots.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Screenshots.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Screenshots.Dock = System.Windows.Forms.DockStyle.Left
        Me.Screenshots.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Screenshots.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.Screenshots.ImageChoice = Nothing
        Me.Screenshots.Location = New System.Drawing.Point(114, 0)
        Me.Screenshots.Name = "Screenshots"
        Me.Screenshots.ShowImage = False
        Me.Screenshots.ShowText = False
        Me.Screenshots.Size = New System.Drawing.Size(20, 20)
        Me.Screenshots.TabIndex = 20
        Me.Screenshots.Text = "ThemeButtonImge1"
        Me.Screenshots.TextAlignment = System.Drawing.StringAlignment.Center
        Me.Screenshots.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Screenshots.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Screenshots.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine4
        '
        Me.LinearLine4.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine4.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine4.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine4.Location = New System.Drawing.Point(106, 0)
        Me.LinearLine4.Name = "LinearLine4"
        Me.LinearLine4.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine4.TabIndex = 19
        Me.LinearLine4.Text = "LinearLine4"
        '
        'DIRECTORY_PICTURES
        '
        Me.DIRECTORY_PICTURES.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_PICTURES.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.DIRECTORY_PICTURES.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_PICTURES.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.DIRECTORY_PICTURES.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_PICTURES.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_PICTURES.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_PICTURES.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_PICTURES.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.DIRECTORY_PICTURES.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_PICTURES.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.DIRECTORY_PICTURES.Dock = System.Windows.Forms.DockStyle.Left
        Me.DIRECTORY_PICTURES.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.DIRECTORY_PICTURES.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.DIRECTORY_PICTURES.ImageChoice = Nothing
        Me.DIRECTORY_PICTURES.Location = New System.Drawing.Point(86, 0)
        Me.DIRECTORY_PICTURES.Name = "DIRECTORY_PICTURES"
        Me.DIRECTORY_PICTURES.ShowImage = False
        Me.DIRECTORY_PICTURES.ShowText = False
        Me.DIRECTORY_PICTURES.Size = New System.Drawing.Size(20, 20)
        Me.DIRECTORY_PICTURES.TabIndex = 18
        Me.DIRECTORY_PICTURES.Text = "ThemeButtonImge1"
        Me.DIRECTORY_PICTURES.TextAlignment = System.Drawing.StringAlignment.Center
        Me.DIRECTORY_PICTURES.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.DIRECTORY_PICTURES.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.DIRECTORY_PICTURES.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine2
        '
        Me.LinearLine2.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine2.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine2.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine2.Location = New System.Drawing.Point(78, 0)
        Me.LinearLine2.Name = "LinearLine2"
        Me.LinearLine2.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine2.TabIndex = 17
        Me.LinearLine2.Text = "LinearLine2"
        '
        'DIRECTORY_DCIM
        '
        Me.DIRECTORY_DCIM.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DCIM.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.DIRECTORY_DCIM.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DCIM.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.DIRECTORY_DCIM.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DCIM.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_DCIM.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_DCIM.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_DCIM.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.DIRECTORY_DCIM.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_DCIM.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.DIRECTORY_DCIM.Dock = System.Windows.Forms.DockStyle.Left
        Me.DIRECTORY_DCIM.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.DIRECTORY_DCIM.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.DIRECTORY_DCIM.ImageChoice = Nothing
        Me.DIRECTORY_DCIM.Location = New System.Drawing.Point(58, 0)
        Me.DIRECTORY_DCIM.Name = "DIRECTORY_DCIM"
        Me.DIRECTORY_DCIM.ShowImage = False
        Me.DIRECTORY_DCIM.ShowText = False
        Me.DIRECTORY_DCIM.Size = New System.Drawing.Size(20, 20)
        Me.DIRECTORY_DCIM.TabIndex = 16
        Me.DIRECTORY_DCIM.Text = "ThemeButtonImge1"
        Me.DIRECTORY_DCIM.TextAlignment = System.Drawing.StringAlignment.Center
        Me.DIRECTORY_DCIM.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.DIRECTORY_DCIM.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.DIRECTORY_DCIM.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine1
        '
        Me.LinearLine1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine1.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine1.Location = New System.Drawing.Point(50, 0)
        Me.LinearLine1.Name = "LinearLine1"
        Me.LinearLine1.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine1.TabIndex = 15
        Me.LinearLine1.Text = "LinearLine1"
        '
        'DIRECTORY_DOWNLOADS
        '
        Me.DIRECTORY_DOWNLOADS.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.Dock = System.Windows.Forms.DockStyle.Left
        Me.DIRECTORY_DOWNLOADS.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.DIRECTORY_DOWNLOADS.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.DIRECTORY_DOWNLOADS.ImageChoice = Nothing
        Me.DIRECTORY_DOWNLOADS.Location = New System.Drawing.Point(30, 0)
        Me.DIRECTORY_DOWNLOADS.Name = "DIRECTORY_DOWNLOADS"
        Me.DIRECTORY_DOWNLOADS.ShowImage = False
        Me.DIRECTORY_DOWNLOADS.ShowText = False
        Me.DIRECTORY_DOWNLOADS.Size = New System.Drawing.Size(20, 20)
        Me.DIRECTORY_DOWNLOADS.TabIndex = 14
        Me.DIRECTORY_DOWNLOADS.Text = "ThemeButtonImge1"
        Me.DIRECTORY_DOWNLOADS.TextAlignment = System.Drawing.StringAlignment.Center
        Me.DIRECTORY_DOWNLOADS.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.DIRECTORY_DOWNLOADS.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine3
        '
        Me.LinearLine3.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine3.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine3.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine3.Location = New System.Drawing.Point(20, 0)
        Me.LinearLine3.Name = "LinearLine3"
        Me.LinearLine3.Size = New System.Drawing.Size(10, 20)
        Me.LinearLine3.TabIndex = 13
        Me.LinearLine3.Text = "LinearLine1"
        '
        'StorageDirectory
        '
        Me.StorageDirectory.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.StorageDirectory.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.StorageDirectory.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.StorageDirectory.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.StorageDirectory.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.StorageDirectory.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.StorageDirectory.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.StorageDirectory.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.StorageDirectory.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.StorageDirectory.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.StorageDirectory.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.StorageDirectory.Dock = System.Windows.Forms.DockStyle.Left
        Me.StorageDirectory.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.StorageDirectory.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.StorageDirectory.ImageChoice = Nothing
        Me.StorageDirectory.Location = New System.Drawing.Point(0, 0)
        Me.StorageDirectory.Name = "StorageDirectory"
        Me.StorageDirectory.ShowImage = False
        Me.StorageDirectory.ShowText = False
        Me.StorageDirectory.Size = New System.Drawing.Size(20, 20)
        Me.StorageDirectory.TabIndex = 12
        Me.StorageDirectory.Text = "ThemeButtonImge1"
        Me.StorageDirectory.TextAlignment = System.Drawing.StringAlignment.Center
        Me.StorageDirectory.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.StorageDirectory.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.StorageDirectory.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'TSEP0
        '
        Me.TSEP0.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TSEP0.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP0.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP0.Location = New System.Drawing.Point(0, 41)
        Me.TSEP0.Name = "TSEP0"
        Me.TSEP0.Size = New System.Drawing.Size(633, 10)
        Me.TSEP0.TabIndex = 13
        Me.TSEP0.Text = "ThemeSeparator4"
        '
        'BTNBACK0
        '
        Me.BTNBACK0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNBACK0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.BTNBACK0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNBACK0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.BTNBACK0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNBACK0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNBACK0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNBACK0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNBACK0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BTNBACK0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNBACK0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BTNBACK0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BTNBACK0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BTNBACK0.ImageChoice = Nothing
        Me.BTNBACK0.Location = New System.Drawing.Point(5, 2)
        Me.BTNBACK0.Name = "BTNBACK0"
        Me.BTNBACK0.ShowImage = False
        Me.BTNBACK0.ShowText = False
        Me.BTNBACK0.Size = New System.Drawing.Size(20, 20)
        Me.BTNBACK0.TabIndex = 12
        Me.BTNBACK0.Text = "ThemeButtonImge1"
        Me.BTNBACK0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BTNBACK0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNBACK0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BTNBACK0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'BTNNEXT0
        '
        Me.BTNNEXT0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNNEXT0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(93, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.BTNNEXT0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNNEXT0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(73, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.BTNNEXT0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BTNNEXT0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNNEXT0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNNEXT0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNNEXT0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BTNNEXT0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNNEXT0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BTNNEXT0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BTNNEXT0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BTNNEXT0.ImageChoice = Nothing
        Me.BTNNEXT0.Location = New System.Drawing.Point(35, 2)
        Me.BTNNEXT0.Name = "BTNNEXT0"
        Me.BTNNEXT0.ShowImage = False
        Me.BTNNEXT0.ShowText = False
        Me.BTNNEXT0.Size = New System.Drawing.Size(20, 20)
        Me.BTNNEXT0.TabIndex = 11
        Me.BTNNEXT0.Text = "ThemeButtonImge1"
        Me.BTNNEXT0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BTNNEXT0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNNEXT0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BTNNEXT0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'TEXTPATH
        '
        Me.TEXTPATH.__CLRXX_S = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.TEXTPATH.__CLRXX_SLave = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TEXTPATH._CBorderEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TEXTPATH._CBorderEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TEXTPATH._CBorderEnter0_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TEXTPATH._CBorderEnter1_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TEXTPATH._CBorderLave0_S = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.TEXTPATH._CBorderLave1_S = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.TEXTPATH._CVK_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TEXTPATH.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TEXTPATH.BackColor = System.Drawing.Color.Transparent
        Me.TEXTPATH.Btnshow = False
        Me.TEXTPATH.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TEXTPATH.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.TEXTPATH.Location = New System.Drawing.Point(61, 3)
        Me.TEXTPATH.MaxLength = 32767
        Me.TEXTPATH.Multiline = False
        Me.TEXTPATH.Name = "TEXTPATH"
        Me.TEXTPATH.ReadOnly = False
        Me.TEXTPATH.Size = New System.Drawing.Size(570, 19)
        Me.TEXTPATH.TabIndex = 10
        Me.TEXTPATH.Text = "%PATH%"
        Me.TEXTPATH.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left
        Me.TEXTPATH.UseSystemPasswordChar = False
        '
        'PNLERRORS
        '
        Me.PNLERRORS.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.PNLERRORS.Controls.Add(Me.LBER)
        Me.PNLERRORS.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PNLERRORS.Location = New System.Drawing.Point(0, 375)
        Me.PNLERRORS.Name = "PNLERRORS"
        Me.PNLERRORS.Size = New System.Drawing.Size(633, 19)
        Me.PNLERRORS.TabIndex = 6
        Me.PNLERRORS.Visible = False
        '
        'LBER
        '
        Me.LBER.AutoSize = True
        Me.LBER.Dock = System.Windows.Forms.DockStyle.Left
        Me.LBER.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBER.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LBER.Location = New System.Drawing.Point(0, 0)
        Me.LBER.Name = "LBER"
        Me.LBER.Size = New System.Drawing.Size(37, 15)
        Me.LBER.TabIndex = 0
        Me.LBER.Text = "Errors"
        '
        'PN
        '
        Me.PN.Controls.Add(Me.PCNOTF)
        Me.PN.Controls.Add(Me.ViewImge)
        Me.PN.Controls.Add(Me.ViewManager)
        Me.PN.Controls.Add(Me.VisualStudioHorizontalScrollBar1)
        Me.PN.Controls.Add(Me.VisualStudioVerticalScrollBar1)
        Me.PN.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PN.Location = New System.Drawing.Point(0, 51)
        Me.PN.Name = "PN"
        Me.PN.Size = New System.Drawing.Size(633, 324)
        Me.PN.TabIndex = 7
        '
        'PCNOTF
        '
        Me.PCNOTF.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.PCNOTF.ContextMenuStrip = Me.cntxDowManager
        Me.PCNOTF.ErrorImage = Nothing
        Me.PCNOTF.InitialImage = Nothing
        Me.PCNOTF.Location = New System.Drawing.Point(100, 73)
        Me.PCNOTF.Name = "PCNOTF"
        Me.PCNOTF.Size = New System.Drawing.Size(131, 68)
        Me.PCNOTF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PCNOTF.TabIndex = 9
        Me.PCNOTF.TabStop = False
        Me.PCNOTF.Visible = False
        '
        'cntxDowManager
        '
        Me.cntxDowManager.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshToolStripMenuItem, Me.OpenTheFileUsingToolStripMenuItem, Me.UploadFileToolStripMenuItem, Me.DownloadToolStripMenuItem, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.EditfileToolStripMenuItem, Me.DeleteToolStripMenuItem, Me.RenameToolStripMenuItem, Me.AddFilesToolStripMenuItem, Me.SetWallpaperToolStripMenuItem, Me.Download02ToolStripMenuItem, Me.MediaPlayerToolStripMenuItem, Me.ZipToolStripMenuItem})
        Me.cntxDowManager.Name = "cntxDowManager"
        Me.cntxDowManager.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.cntxDowManager.Size = New System.Drawing.Size(200, 334)
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'OpenTheFileUsingToolStripMenuItem
        '
        Me.OpenTheFileUsingToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenTheFileUsingToolStripMenuItem.Name = "OpenTheFileUsingToolStripMenuItem"
        Me.OpenTheFileUsingToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.OpenTheFileUsingToolStripMenuItem.Text = "Open the file using"
        '
        'UploadFileToolStripMenuItem
        '
        Me.UploadFileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UploadFileToolStripMenuItem.Name = "UploadFileToolStripMenuItem"
        Me.UploadFileToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.UploadFileToolStripMenuItem.Text = "Upload File"
        '
        'DownloadToolStripMenuItem
        '
        Me.DownloadToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DownloadToolStripMenuItem.Name = "DownloadToolStripMenuItem"
        Me.DownloadToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.DownloadToolStripMenuItem.Text = "Download"
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.CutToolStripMenuItem.Text = "Cut"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'EditfileToolStripMenuItem
        '
        Me.EditfileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.EditfileToolStripMenuItem.Name = "EditfileToolStripMenuItem"
        Me.EditfileToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always
        Me.EditfileToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.EditfileToolStripMenuItem.Text = "Edit"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Delete), System.Windows.Forms.Keys)
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'RenameToolStripMenuItem
        '
        Me.RenameToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RenameToolStripMenuItem.Name = "RenameToolStripMenuItem"
        Me.RenameToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.RenameToolStripMenuItem.Text = "Rename"
        '
        'AddFilesToolStripMenuItem
        '
        Me.AddFilesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AddFilesToolStripMenuItem.Name = "AddFilesToolStripMenuItem"
        Me.AddFilesToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.AddFilesToolStripMenuItem.Text = "Add Files"
        '
        'SetWallpaperToolStripMenuItem
        '
        Me.SetWallpaperToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SetWallpaperToolStripMenuItem.Name = "SetWallpaperToolStripMenuItem"
        Me.SetWallpaperToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.SetWallpaperToolStripMenuItem.Text = "Set Wallpaper"
        '
        'Download02ToolStripMenuItem
        '
        Me.Download02ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Download02ToolStripMenuItem.Name = "Download02ToolStripMenuItem"
        Me.Download02ToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.Download02ToolStripMenuItem.Text = "Open Downloads folder"
        '
        'MediaPlayerToolStripMenuItem
        '
        Me.MediaPlayerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.StopToolStripMenuItem})
        Me.MediaPlayerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.MediaPlayerToolStripMenuItem.Name = "MediaPlayerToolStripMenuItem"
        Me.MediaPlayerToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.MediaPlayerToolStripMenuItem.Text = "Media Player"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(98, 22)
        Me.StartToolStripMenuItem.Text = "Start"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(98, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'ZipToolStripMenuItem
        '
        Me.ZipToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZipToolStripMenuItem1, Me.UnZipToolStripMenuItem})
        Me.ZipToolStripMenuItem.Name = "ZipToolStripMenuItem"
        Me.ZipToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ZipToolStripMenuItem.Text = "Compress Files"
        '
        'ZipToolStripMenuItem1
        '
        Me.ZipToolStripMenuItem1.Name = "ZipToolStripMenuItem1"
        Me.ZipToolStripMenuItem1.Size = New System.Drawing.Size(106, 22)
        Me.ZipToolStripMenuItem1.Text = "Zip"
        '
        'UnZipToolStripMenuItem
        '
        Me.UnZipToolStripMenuItem.Name = "UnZipToolStripMenuItem"
        Me.UnZipToolStripMenuItem.Size = New System.Drawing.Size(106, 22)
        Me.UnZipToolStripMenuItem.Text = "UnZip"
        '
        'ViewImge
        '
        Me.ViewImge.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ViewImge.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ViewImge.Location = New System.Drawing.Point(437, 129)
        Me.ViewImge.Name = "ViewImge"
        Me.ViewImge.Size = New System.Drawing.Size(170, 170)
        Me.ViewImge.TabIndex = 8
        Me.ViewImge.TabStop = False
        Me.ViewImge.Visible = False
        '
        'ViewManager
        '
        Me.ViewManager.AllowUserToAddRows = False
        Me.ViewManager.AllowUserToDeleteRows = False
        Me.ViewManager.AllowUserToResizeColumns = False
        Me.ViewManager.AllowUserToResizeRows = False
        Me.ViewManager.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ViewManager.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.ViewManager.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ViewManager.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ViewManager.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.ViewManager.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ViewManager.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.ViewManager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ViewManager.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.ViewManager.ContextMenuStrip = Me.cntxDowManager
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ViewManager.DefaultCellStyle = DataGridViewCellStyle2
        Me.ViewManager.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ViewManager.EnableHeadersVisualStyles = False
        Me.ViewManager.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ViewManager.Location = New System.Drawing.Point(0, 0)
        Me.ViewManager.Name = "ViewManager"
        Me.ViewManager.RowHeadersVisible = False
        Me.ViewManager.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.ViewManager.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ViewManager.ShowCellToolTips = False
        Me.ViewManager.Size = New System.Drawing.Size(623, 314)
        Me.ViewManager.TabIndex = 7
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column1.HeaderText = ""
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 40
        '
        'Column2
        '
        Me.Column2.HeaderText = "Name"
        Me.Column2.Name = "Column2"
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column2.Width = 63
        '
        'Column3
        '
        Me.Column3.HeaderText = "Size"
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 53
        '
        'Column4
        '
        Me.Column4.HeaderText = "File extension"
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 103
        '
        'Column5
        '
        Me.Column5.HeaderText = "Last Modified"
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 103
        '
        'Column6
        '
        Me.Column6.HeaderText = "Recently"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 76
        '
        'VisualStudioHorizontalScrollBar1
        '
        Me.VisualStudioHorizontalScrollBar1.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar1.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar1.Location = New System.Drawing.Point(0, 314)
        Me.VisualStudioHorizontalScrollBar1.Maximum = 1
        Me.VisualStudioHorizontalScrollBar1.Minimum = 0
        Me.VisualStudioHorizontalScrollBar1.Name = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar1.Size = New System.Drawing.Size(623, 10)
        Me.VisualStudioHorizontalScrollBar1.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar1.TabIndex = 6
        Me.VisualStudioHorizontalScrollBar1.Text = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.Value = 0
        '
        'VisualStudioVerticalScrollBar1
        '
        Me.VisualStudioVerticalScrollBar1.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar1.LargeChange = 10
        Me.VisualStudioVerticalScrollBar1.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Llen = -1
        Me.VisualStudioVerticalScrollBar1.Location = New System.Drawing.Point(623, 0)
        Me.VisualStudioVerticalScrollBar1.Maximum = 1
        Me.VisualStudioVerticalScrollBar1.Minimum = 0
        Me.VisualStudioVerticalScrollBar1.Name = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar1.Size = New System.Drawing.Size(10, 324)
        Me.VisualStudioVerticalScrollBar1.SmallChange = 10
        Me.VisualStudioVerticalScrollBar1.TabIndex = 5
        Me.VisualStudioVerticalScrollBar1.Text = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Value = 0
        '
        'Trans
        '
        Me.Trans.Interval = 40
        '
        'Transdown
        '
        Me.Transdown.Interval = 20
        '
        'TProgressBar
        '
        Me.TProgressBar.Interval = 1
        '
        'TScrolls
        '
        Me.TScrolls.Interval = 1
        '
        'SELCT_PK
        '
        Me.SELCT_PK.Name = "SELCT_PK"
        Me.SELCT_PK.ShowImageMargin = False
        Me.SELCT_PK.Size = New System.Drawing.Size(36, 4)
        '
        'FileManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(633, 422)
        Me.Controls.Add(Me.PN)
        Me.Controls.Add(Me.PNLERRORS)
        Me.Controls.Add(Me.PNLTOP)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.BOXDOWN)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.MinimumSize = New System.Drawing.Size(177, 295)
        Me.Name = "FileManager"
        Me.Opacity = 0R
        Me.Text = "File Manager"
        CType(Me.BOXDOWN, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PNLTOP.ResumeLayout(False)
        Me.PNL1.ResumeLayout(False)
        Me.ONLICON.ResumeLayout(False)
        Me.PNLERRORS.ResumeLayout(False)
        Me.PNLERRORS.PerformLayout()
        Me.PN.ResumeLayout(False)
        CType(Me.PCNOTF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cntxDowManager.ResumeLayout(False)
        CType(Me.ViewImge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ViewManager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BOXDOWN As PictureBox
    Friend WithEvents ProgressBar1 As SN.ThemeProgressBar
    Friend WithEvents PNLTOP As Panel
    Friend WithEvents PNL1 As Panel
    Friend WithEvents TEXTPATH As SN.ThemeTextBox
    Friend WithEvents BTNBACK0 As SN.ThemeButtonImge
    Friend WithEvents BTNNEXT0 As SN.ThemeButtonImge
    Friend WithEvents ONLICON As Panel
    Friend WithEvents DIRECTORY_DOWNLOADS As SN.ThemeButtonImge
    Friend WithEvents LinearLine3 As SN.LinearLine
    Friend WithEvents StorageDirectory As SN.ThemeButtonImge
    Friend WithEvents TSEP0 As SN.ThemeSeparator
    Friend WithEvents DIRECTORY_PICTURES As SN.ThemeButtonImge
    Friend WithEvents LinearLine2 As SN.LinearLine
    Friend WithEvents DIRECTORY_DCIM As SN.ThemeButtonImge
    Friend WithEvents LinearLine1 As SN.LinearLine
    Friend WithEvents Screenshots As SN.ThemeButtonImge
    Friend WithEvents LinearLine4 As SN.LinearLine
    Friend WithEvents Camera As SN.ThemeButtonImge
    Friend WithEvents LinearLine5 As SN.LinearLine
    Friend WithEvents PNLERRORS As Panel
    Friend WithEvents LBER As Label
    Friend WithEvents PN As Panel
    Friend WithEvents VisualStudioVerticalScrollBar1 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents VisualStudioHorizontalScrollBar1 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents ViewManager As DataGridView
    Friend WithEvents Column1 As DataGridViewImageColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents cntxDowManager As ContextMenuStrip
    Friend WithEvents RefreshToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenTheFileUsingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UploadFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DownloadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditfileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RenameToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddFilesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetWallpaperToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Download02ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MediaPlayerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ZipToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ZipToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents UnZipToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewImge As PictureBox
    Friend WithEvents PCNOTF As PictureBox
    Friend WithEvents Trans As Timer
    Friend WithEvents Transdown As Timer
    Friend WithEvents TProgressBar As Timer
    Friend WithEvents TScrolls As Timer
    Friend WithEvents SELCT_PK As ContextMenuStrip
End Class
