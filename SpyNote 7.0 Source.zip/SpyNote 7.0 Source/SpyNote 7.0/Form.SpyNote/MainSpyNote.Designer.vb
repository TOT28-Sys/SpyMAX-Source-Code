﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainSpyNote
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainSpyNote))
        Me.ContextTools = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.PayloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FoldersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientsFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientFolderDownloadsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherClientFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BuildingFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ScommandToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CCMDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PowhellToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WndToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FirStartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FirStopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EdweToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceiveConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckPortsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SdsafdToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SdfsdfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.sgsdfgvdfv = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextView = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.LogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlackListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MonitorAndroidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.OnLoginShowAlertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCONTROL = New System.Windows.Forms.Panel()
        Me.PC = New System.Windows.Forms.Panel()
        Me.PNLWOW = New System.Windows.Forms.Panel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.PNL0 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Colum1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Colum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Colum3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Colum4 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Colum5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Colum6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Colum7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Colum8 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Colum9 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Colum10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextControl = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.FileManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SMSManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CallsManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactsManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocationManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CameraManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShellTerminalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplicationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrophoneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyloggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleintTCPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToBlackListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PhoneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FunToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VisualStudioHorizontalScrollBar1 = New SpyNote_7._0.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar1 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.PNLLOGES = New System.Windows.Forms.Panel()
        Me.MTabControl = New SpyNote_7._0.SN.ThemeTabControl()
        Me.TabPageMonitorAndroid = New System.Windows.Forms.TabPage()
        Me.PNLMonitor = New System.Windows.Forms.Panel()
        Me.DataMonitorAndroidView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn6 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VisualStudioHorizontalScrollBar4 = New SpyNote_7._0.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar5 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.PNLTOOL_Monitor = New System.Windows.Forms.Panel()
        Me.BAutoDelete1 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine8 = New SpyNote_7._0.SN.LinearLine()
        Me.BDeleteAll2 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine9 = New SpyNote_7._0.SN.LinearLine()
        Me.BDelete2 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine10 = New SpyNote_7._0.SN.LinearLine()
        Me.Bdown2 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.TabPageBlackList = New System.Windows.Forms.TabPage()
        Me.LNothing1 = New System.Windows.Forms.Label()
        Me.DataBlackListView = New System.Windows.Forms.DataGridView()
        Me.Column44 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VisualStudioHorizontalScrollBar3 = New SpyNote_7._0.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar4 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.PNLTOOL_BlackList = New System.Windows.Forms.Panel()
        Me.LinearLine21 = New SpyNote_7._0.SN.LinearLine()
        Me.LBAddress = New System.Windows.Forms.Label()
        Me.LinearLine7 = New SpyNote_7._0.SN.LinearLine()
        Me.BDeleteAll1 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine6 = New SpyNote_7._0.SN.LinearLine()
        Me.BRefres0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine5 = New SpyNote_7._0.SN.LinearLine()
        Me.BDelete1 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine4 = New SpyNote_7._0.SN.LinearLine()
        Me.TTextAddress = New SpyNote_7._0.SN.ThemeTextBox()
        Me.Bdown1 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.BADD0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.TabPageConnectionLogs = New System.Windows.Forms.TabPage()
        Me.PanelLogsMove = New System.Windows.Forms.Panel()
        Me.DataLogsView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn4 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Str0 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Str1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Str2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Str3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PNLTOOL_Logs = New System.Windows.Forms.Panel()
        Me.BAutoDelete0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine3 = New SpyNote_7._0.SN.LinearLine()
        Me.BDeleteAll0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine2 = New SpyNote_7._0.SN.LinearLine()
        Me.BDelete0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.LinearLine1 = New SpyNote_7._0.SN.LinearLine()
        Me.Bdown0 = New SpyNote_7._0.SN.ThemeButtonImge()
        Me.VisualStudioHorizontalScrollBar2 = New SpyNote_7._0.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar3 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.PNLLOGESTOP = New System.Windows.Forms.Panel()
        Me.PNLTEXT = New System.Windows.Forms.Panel()
        Me.MaximTab = New System.Windows.Forms.PictureBox()
        Me.CloseTab = New System.Windows.Forms.PictureBox()
        Me.LabelText = New SpyNote_7._0.SN.ThemeTit()
        Me.VisualStudioVerticalScrollBar2 = New SpyNote_7._0.SN.VisualStudioVerticalScrollBar()
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.PNL3 = New System.Windows.Forms.Panel()
        Me.GView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn3 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TSEP3 = New SpyNote_7._0.SN.ThemeSeparator()
        Me.L3 = New System.Windows.Forms.LinkLabel()
        Me.PNL2 = New System.Windows.Forms.Panel()
        Me.NView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn2 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TSEP2 = New SpyNote_7._0.SN.ThemeSeparator()
        Me.L2 = New System.Windows.Forms.LinkLabel()
        Me.PNL1 = New System.Windows.Forms.Panel()
        Me.PView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.P1 = New System.Windows.Forms.Panel()
        Me.TSEP1 = New SpyNote_7._0.SN.ThemeSeparator()
        Me.L1 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Closeinformations = New System.Windows.Forms.PictureBox()
        Me.ThemeTit1 = New SpyNote_7._0.SN.ThemeTit()
        Me.BOXDOWN = New System.Windows.Forms.PictureBox()
        Me.PanelTop = New System.Windows.Forms.Panel()
        Me.TSEP0 = New SpyNote_7._0.SN.ThemeSeparator()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutSpyNoteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FacebookToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateLabels = New System.Windows.Forms.Timer(Me.components)
        Me.DownPNL = New System.Windows.Forms.Timer(Me.components)
        Me.Trans = New System.Windows.Forms.Timer(Me.components)
        Me.TScrolls = New System.Windows.Forms.Timer(Me.components)
        Me.SELCT_Apks = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ContextTools.SuspendLayout()
        Me.ContextView.SuspendLayout()
        Me.PCONTROL.SuspendLayout()
        Me.PC.SuspendLayout()
        Me.PNLWOW.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.PNL0.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextControl.SuspendLayout()
        Me.PNLLOGES.SuspendLayout()
        Me.MTabControl.SuspendLayout()
        Me.TabPageMonitorAndroid.SuspendLayout()
        Me.PNLMonitor.SuspendLayout()
        CType(Me.DataMonitorAndroidView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PNLTOOL_Monitor.SuspendLayout()
        Me.TabPageBlackList.SuspendLayout()
        CType(Me.DataBlackListView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PNLTOOL_BlackList.SuspendLayout()
        Me.TabPageConnectionLogs.SuspendLayout()
        Me.PanelLogsMove.SuspendLayout()
        CType(Me.DataLogsView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PNLTOOL_Logs.SuspendLayout()
        Me.PNLLOGESTOP.SuspendLayout()
        Me.PNLTEXT.SuspendLayout()
        CType(Me.MaximTab, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CloseTab, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LabelText, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelMain.SuspendLayout()
        Me.PNL3.SuspendLayout()
        CType(Me.GView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.PNL2.SuspendLayout()
        CType(Me.NView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.PNL1.SuspendLayout()
        CType(Me.PView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.P1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.Closeinformations, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ThemeTit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BOXDOWN, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTop.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ContextTools
        '
        Me.ContextTools.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PayloadToolStripMenuItem, Me.FoldersToolStripMenuItem, Me.ToolStripMenuItem1, Me.ScommandToolStripMenuItem, Me.WndToolStripMenuItem, Me.EdweToolStripMenuItem, Me.SdsafdToolStripMenuItem, Me.ToolStripMenuItem2, Me.sgsdfgvdfv, Me.OptionsToolStripMenuItem})
        Me.ContextTools.Name = "ContextTools"
        Me.ContextTools.OwnerItem = Me.ToolsToolStripMenuItem
        Me.ContextTools.Size = New System.Drawing.Size(160, 192)
        '
        'PayloadToolStripMenuItem
        '
        Me.PayloadToolStripMenuItem.Image = Global.SpyNote_7._0.My.Resources.Resources.BuildTool
        Me.PayloadToolStripMenuItem.Name = "PayloadToolStripMenuItem"
        Me.PayloadToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.PayloadToolStripMenuItem.Text = "Payload"
        '
        'FoldersToolStripMenuItem
        '
        Me.FoldersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClientsFolderToolStripMenuItem, Me.ClientFolderDownloadsToolStripMenuItem, Me.OtherClientFolderToolStripMenuItem, Me.BuildingFolderToolStripMenuItem})
        Me.FoldersToolStripMenuItem.Name = "FoldersToolStripMenuItem"
        Me.FoldersToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.FoldersToolStripMenuItem.Text = "Folders"
        '
        'ClientsFolderToolStripMenuItem
        '
        Me.ClientsFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ClientsFolderToolStripMenuItem.Name = "ClientsFolderToolStripMenuItem"
        Me.ClientsFolderToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.ClientsFolderToolStripMenuItem.Text = "Victims"
        '
        'ClientFolderDownloadsToolStripMenuItem
        '
        Me.ClientFolderDownloadsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ClientFolderDownloadsToolStripMenuItem.Name = "ClientFolderDownloadsToolStripMenuItem"
        Me.ClientFolderDownloadsToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.ClientFolderDownloadsToolStripMenuItem.Text = "Downloads"
        '
        'OtherClientFolderToolStripMenuItem
        '
        Me.OtherClientFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OtherClientFolderToolStripMenuItem.Name = "OtherClientFolderToolStripMenuItem"
        Me.OtherClientFolderToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.OtherClientFolderToolStripMenuItem.Text = "Victim"
        '
        'BuildingFolderToolStripMenuItem
        '
        Me.BuildingFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BuildingFolderToolStripMenuItem.Name = "BuildingFolderToolStripMenuItem"
        Me.BuildingFolderToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.BuildingFolderToolStripMenuItem.Text = "APK Store"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(156, 6)
        '
        'ScommandToolStripMenuItem
        '
        Me.ScommandToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CCMDToolStripMenuItem, Me.PowhellToolStripMenuItem})
        Me.ScommandToolStripMenuItem.Name = "ScommandToolStripMenuItem"
        Me.ScommandToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.ScommandToolStripMenuItem.Text = "Commands"
        '
        'CCMDToolStripMenuItem
        '
        Me.CCMDToolStripMenuItem.Name = "CCMDToolStripMenuItem"
        Me.CCMDToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CCMDToolStripMenuItem.Text = "CMD"
        '
        'PowhellToolStripMenuItem
        '
        Me.PowhellToolStripMenuItem.Name = "PowhellToolStripMenuItem"
        Me.PowhellToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.PowhellToolStripMenuItem.Text = "Power Shell"
        '
        'WndToolStripMenuItem
        '
        Me.WndToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FirStartToolStripMenuItem, Me.FirStopToolStripMenuItem, Me.FfToolStripMenuItem})
        Me.WndToolStripMenuItem.Name = "WndToolStripMenuItem"
        Me.WndToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.WndToolStripMenuItem.Text = "Firewall"
        '
        'FirStartToolStripMenuItem
        '
        Me.FirStartToolStripMenuItem.Name = "FirStartToolStripMenuItem"
        Me.FirStartToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FirStartToolStripMenuItem.Text = "On"
        '
        'FirStopToolStripMenuItem
        '
        Me.FirStopToolStripMenuItem.Name = "FirStopToolStripMenuItem"
        Me.FirStopToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FirStopToolStripMenuItem.Text = "Off"
        '
        'FfToolStripMenuItem
        '
        Me.FfToolStripMenuItem.Name = "FfToolStripMenuItem"
        Me.FfToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FfToolStripMenuItem.Text = "Advanced Security"
        '
        'EdweToolStripMenuItem
        '
        Me.EdweToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReceiveConnectionToolStripMenuItem, Me.CheckPortsToolStripMenuItem})
        Me.EdweToolStripMenuItem.Name = "EdweToolStripMenuItem"
        Me.EdweToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.EdweToolStripMenuItem.Text = "Test Connection"
        '
        'ReceiveConnectionToolStripMenuItem
        '
        Me.ReceiveConnectionToolStripMenuItem.Name = "ReceiveConnectionToolStripMenuItem"
        Me.ReceiveConnectionToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.ReceiveConnectionToolStripMenuItem.Text = "Receive connection"
        '
        'CheckPortsToolStripMenuItem
        '
        Me.CheckPortsToolStripMenuItem.Name = "CheckPortsToolStripMenuItem"
        Me.CheckPortsToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.CheckPortsToolStripMenuItem.Text = "Check ports"
        '
        'SdsafdToolStripMenuItem
        '
        Me.SdsafdToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SdfsdfToolStripMenuItem})
        Me.SdsafdToolStripMenuItem.Name = "SdsafdToolStripMenuItem"
        Me.SdsafdToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.SdsafdToolStripMenuItem.Text = "Victims Settings"
        '
        'SdfsdfToolStripMenuItem
        '
        Me.SdfsdfToolStripMenuItem.Name = "SdfsdfToolStripMenuItem"
        Me.SdfsdfToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.SdfsdfToolStripMenuItem.Text = "Edit Host"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(156, 6)
        '
        'sgsdfgvdfv
        '
        Me.sgsdfgvdfv.Name = "sgsdfgvdfv"
        Me.sgsdfgvdfv.Size = New System.Drawing.Size(159, 22)
        Me.sgsdfgvdfv.Text = "APK INSTALL"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.OptionsToolStripMenuItem.Text = "Options..."
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDown = Me.ContextTools
        Me.ToolsToolStripMenuItem.Image = Global.SpyNote_7._0.My.Resources.Resources.MenuItem
        Me.ToolsToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'ContextView
        '
        Me.ContextView.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LogsToolStripMenuItem, Me.BlackListToolStripMenuItem, Me.MonitorAndroidToolStripMenuItem, Me.InformationsToolStripMenuItem, Me.ToolStripMenuItem3, Me.OnLoginShowAlertToolStripMenuItem})
        Me.ContextView.Name = "ContextView"
        Me.ContextView.OwnerItem = Me.ViewToolStripMenuItem
        Me.ContextView.Size = New System.Drawing.Size(165, 120)
        '
        'LogsToolStripMenuItem
        '
        Me.LogsToolStripMenuItem.Checked = True
        Me.LogsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LogsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogsToolStripMenuItem.Name = "LogsToolStripMenuItem"
        Me.LogsToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.LogsToolStripMenuItem.Tag = "Checked"
        Me.LogsToolStripMenuItem.Text = "Connections Log"
        '
        'BlackListToolStripMenuItem
        '
        Me.BlackListToolStripMenuItem.Checked = True
        Me.BlackListToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.BlackListToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BlackListToolStripMenuItem.Name = "BlackListToolStripMenuItem"
        Me.BlackListToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.BlackListToolStripMenuItem.Tag = "Checked"
        Me.BlackListToolStripMenuItem.Text = "Black List"
        '
        'MonitorAndroidToolStripMenuItem
        '
        Me.MonitorAndroidToolStripMenuItem.Checked = True
        Me.MonitorAndroidToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.MonitorAndroidToolStripMenuItem.Name = "MonitorAndroidToolStripMenuItem"
        Me.MonitorAndroidToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.MonitorAndroidToolStripMenuItem.Tag = "Checked"
        Me.MonitorAndroidToolStripMenuItem.Text = "Monitor Android"
        '
        'InformationsToolStripMenuItem
        '
        Me.InformationsToolStripMenuItem.Checked = True
        Me.InformationsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.InformationsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.InformationsToolStripMenuItem.Name = "InformationsToolStripMenuItem"
        Me.InformationsToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.InformationsToolStripMenuItem.Tag = "Checked"
        Me.InformationsToolStripMenuItem.Text = "Service Status"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(161, 6)
        '
        'OnLoginShowAlertToolStripMenuItem
        '
        Me.OnLoginShowAlertToolStripMenuItem.Checked = True
        Me.OnLoginShowAlertToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.OnLoginShowAlertToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OnLoginShowAlertToolStripMenuItem.Name = "OnLoginShowAlertToolStripMenuItem"
        Me.OnLoginShowAlertToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.OnLoginShowAlertToolStripMenuItem.Tag = "Checked"
        Me.OnLoginShowAlertToolStripMenuItem.Text = "login show alerts"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDown = Me.ContextView
        Me.ViewToolStripMenuItem.Image = Global.SpyNote_7._0.My.Resources.Resources.ProcessToolStripMenuItem
        Me.ViewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'PCONTROL
        '
        Me.PCONTROL.BackColor = System.Drawing.Color.Transparent
        Me.PCONTROL.Controls.Add(Me.PC)
        Me.PCONTROL.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PCONTROL.Location = New System.Drawing.Point(0, 0)
        Me.PCONTROL.Name = "PCONTROL"
        Me.PCONTROL.Size = New System.Drawing.Size(896, 449)
        Me.PCONTROL.TabIndex = 3
        '
        'PC
        '
        Me.PC.Controls.Add(Me.PNLWOW)
        Me.PC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PC.Location = New System.Drawing.Point(0, 0)
        Me.PC.Name = "PC"
        Me.PC.Size = New System.Drawing.Size(896, 449)
        Me.PC.TabIndex = 0
        '
        'PNLWOW
        '
        Me.PNLWOW.Controls.Add(Me.SplitContainer1)
        Me.PNLWOW.Controls.Add(Me.BOXDOWN)
        Me.PNLWOW.Controls.Add(Me.PanelTop)
        Me.PNLWOW.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNLWOW.Location = New System.Drawing.Point(0, 0)
        Me.PNLWOW.Name = "PNLWOW"
        Me.PNLWOW.Size = New System.Drawing.Size(896, 449)
        Me.PNLWOW.TabIndex = 0
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.SplitContainer1.Cursor = System.Windows.Forms.Cursors.SizeWE
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 35)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.VisualStudioVerticalScrollBar2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PanelMain)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel2)
        Me.SplitContainer1.Size = New System.Drawing.Size(896, 396)
        Me.SplitContainer1.SplitterDistance = 528
        Me.SplitContainer1.SplitterWidth = 5
        Me.SplitContainer1.TabIndex = 2
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.SplitContainer2.Cursor = System.Windows.Forms.Cursors.SizeNS
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.PNL0)
        Me.SplitContainer2.Panel1.Cursor = System.Windows.Forms.Cursors.Default
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.PNLLOGES)
        Me.SplitContainer2.Size = New System.Drawing.Size(528, 396)
        Me.SplitContainer2.SplitterDistance = 176
        Me.SplitContainer2.SplitterWidth = 5
        Me.SplitContainer2.TabIndex = 0
        '
        'PNL0
        '
        Me.PNL0.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.PNL0.Controls.Add(Me.DataGridView1)
        Me.PNL0.Controls.Add(Me.VisualStudioHorizontalScrollBar1)
        Me.PNL0.Controls.Add(Me.VisualStudioVerticalScrollBar1)
        Me.PNL0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNL0.Location = New System.Drawing.Point(0, 0)
        Me.PNL0.Name = "PNL0"
        Me.PNL0.Size = New System.Drawing.Size(528, 176)
        Me.PNL0.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Colum1, Me.Colum2, Me.Colum3, Me.Colum4, Me.Colum5, Me.Colum6, Me.Colum7, Me.Column10, Me.Colum8, Me.Colum9, Me.Colum10})
        Me.DataGridView1.ContextMenuStrip = Me.ContextControl
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.ShowCellToolTips = False
        Me.DataGridView1.Size = New System.Drawing.Size(518, 166)
        Me.DataGridView1.TabIndex = 6
        '
        'Colum1
        '
        Me.Colum1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Colum1.FillWeight = 45.0!
        Me.Colum1.HeaderText = "Image"
        Me.Colum1.MinimumWidth = 48
        Me.Colum1.Name = "Colum1"
        Me.Colum1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Colum1.Width = 48
        '
        'Colum2
        '
        Me.Colum2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Colum2.DefaultCellStyle = DataGridViewCellStyle2
        Me.Colum2.HeaderText = "Victim Name"
        Me.Colum2.Name = "Colum2"
        Me.Colum2.Width = 101
        '
        'Colum3
        '
        Me.Colum3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Colum3.HeaderText = "Country"
        Me.Colum3.Name = "Colum3"
        Me.Colum3.Width = 73
        '
        'Colum4
        '
        Me.Colum4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Colum4.FillWeight = 17.0!
        Me.Colum4.HeaderText = "Flag"
        Me.Colum4.Name = "Colum4"
        Me.Colum4.Width = 34
        '
        'Colum5
        '
        Me.Colum5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Colum5.DefaultCellStyle = DataGridViewCellStyle3
        Me.Colum5.HeaderText = "Remote Address"
        Me.Colum5.Name = "Colum5"
        Me.Colum5.Width = 117
        '
        'Colum6
        '
        Me.Colum6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Colum6.HeaderText = "Model"
        Me.Colum6.Name = "Colum6"
        Me.Colum6.Width = 65
        '
        'Colum7
        '
        Me.Colum7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Colum7.HeaderText = "Ver & Api"
        Me.Colum7.Name = "Colum7"
        Me.Colum7.Width = 81
        '
        'Column10
        '
        Me.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column10.HeaderText = "n/a"
        Me.Column10.Name = "Column10"
        Me.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column10.Width = 49
        '
        'Colum8
        '
        Me.Colum8.HeaderText = "n/a"
        Me.Colum8.Name = "Colum8"
        Me.Colum8.Width = 30
        '
        'Colum9
        '
        Me.Colum9.HeaderText = "n/a"
        Me.Colum9.Name = "Colum9"
        Me.Colum9.Width = 30
        '
        'Colum10
        '
        Me.Colum10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Colum10.HeaderText = "SMS & Calls"
        Me.Colum10.Name = "Colum10"
        Me.Colum10.Width = 95
        '
        'ContextControl
        '
        Me.ContextControl.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileManagerToolStripMenuItem, Me.SMSManagerToolStripMenuItem, Me.CallsManagerToolStripMenuItem, Me.ContactsManagerToolStripMenuItem, Me.LocationManagerToolStripMenuItem, Me.AccountManagerToolStripMenuItem, Me.CameraManagerToolStripMenuItem, Me.ShellTerminalToolStripMenuItem, Me.ApplicationsToolStripMenuItem, Me.MicrophoneToolStripMenuItem, Me.KeyloggerToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.CleintTCPToolStripMenuItem, Me.PhoneToolStripMenuItem, Me.ChatToolStripMenuItem, Me.FunToolStripMenuItem})
        Me.ContextControl.Name = "ContextControl"
        Me.ContextControl.Size = New System.Drawing.Size(172, 356)
        '
        'FileManagerToolStripMenuItem
        '
        Me.FileManagerToolStripMenuItem.Name = "FileManagerToolStripMenuItem"
        Me.FileManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.FileManagerToolStripMenuItem.Text = "File Manager"
        '
        'SMSManagerToolStripMenuItem
        '
        Me.SMSManagerToolStripMenuItem.Name = "SMSManagerToolStripMenuItem"
        Me.SMSManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.SMSManagerToolStripMenuItem.Text = "SMS Manager"
        '
        'CallsManagerToolStripMenuItem
        '
        Me.CallsManagerToolStripMenuItem.Name = "CallsManagerToolStripMenuItem"
        Me.CallsManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.CallsManagerToolStripMenuItem.Text = "Calls Manager"
        '
        'ContactsManagerToolStripMenuItem
        '
        Me.ContactsManagerToolStripMenuItem.Name = "ContactsManagerToolStripMenuItem"
        Me.ContactsManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ContactsManagerToolStripMenuItem.Text = "Contacts Manager"
        '
        'LocationManagerToolStripMenuItem
        '
        Me.LocationManagerToolStripMenuItem.Name = "LocationManagerToolStripMenuItem"
        Me.LocationManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.LocationManagerToolStripMenuItem.Text = "Location Manager"
        '
        'AccountManagerToolStripMenuItem
        '
        Me.AccountManagerToolStripMenuItem.Name = "AccountManagerToolStripMenuItem"
        Me.AccountManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.AccountManagerToolStripMenuItem.Text = "Account Manager"
        '
        'CameraManagerToolStripMenuItem
        '
        Me.CameraManagerToolStripMenuItem.Name = "CameraManagerToolStripMenuItem"
        Me.CameraManagerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.CameraManagerToolStripMenuItem.Text = "Camera Manager"
        '
        'ShellTerminalToolStripMenuItem
        '
        Me.ShellTerminalToolStripMenuItem.Name = "ShellTerminalToolStripMenuItem"
        Me.ShellTerminalToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ShellTerminalToolStripMenuItem.Text = "Shell Terminal"
        '
        'ApplicationsToolStripMenuItem
        '
        Me.ApplicationsToolStripMenuItem.Name = "ApplicationsToolStripMenuItem"
        Me.ApplicationsToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ApplicationsToolStripMenuItem.Text = "Applications"
        '
        'MicrophoneToolStripMenuItem
        '
        Me.MicrophoneToolStripMenuItem.Name = "MicrophoneToolStripMenuItem"
        Me.MicrophoneToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.MicrophoneToolStripMenuItem.Text = "Microphone"
        '
        'KeyloggerToolStripMenuItem
        '
        Me.KeyloggerToolStripMenuItem.Name = "KeyloggerToolStripMenuItem"
        Me.KeyloggerToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.KeyloggerToolStripMenuItem.Text = "Keylogger"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'CleintTCPToolStripMenuItem
        '
        Me.CleintTCPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReconnectToolStripMenuItem, Me.ToBlackListToolStripMenuItem})
        Me.CleintTCPToolStripMenuItem.Name = "CleintTCPToolStripMenuItem"
        Me.CleintTCPToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.CleintTCPToolStripMenuItem.Text = "Victim"
        '
        'ReconnectToolStripMenuItem
        '
        Me.ReconnectToolStripMenuItem.Name = "ReconnectToolStripMenuItem"
        Me.ReconnectToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.ReconnectToolStripMenuItem.Text = "Reconnect"
        '
        'ToBlackListToolStripMenuItem
        '
        Me.ToBlackListToolStripMenuItem.Name = "ToBlackListToolStripMenuItem"
        Me.ToBlackListToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.ToBlackListToolStripMenuItem.Text = "To Black list"
        '
        'PhoneToolStripMenuItem
        '
        Me.PhoneToolStripMenuItem.Name = "PhoneToolStripMenuItem"
        Me.PhoneToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.PhoneToolStripMenuItem.Text = "Phone"
        '
        'ChatToolStripMenuItem
        '
        Me.ChatToolStripMenuItem.Name = "ChatToolStripMenuItem"
        Me.ChatToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ChatToolStripMenuItem.Text = "Chat"
        '
        'FunToolStripMenuItem
        '
        Me.FunToolStripMenuItem.Name = "FunToolStripMenuItem"
        Me.FunToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.FunToolStripMenuItem.Text = "Fun"
        '
        'VisualStudioHorizontalScrollBar1
        '
        Me.VisualStudioHorizontalScrollBar1.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar1.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar1.Location = New System.Drawing.Point(0, 166)
        Me.VisualStudioHorizontalScrollBar1.Maximum = 1
        Me.VisualStudioHorizontalScrollBar1.Minimum = 0
        Me.VisualStudioHorizontalScrollBar1.Name = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar1.Size = New System.Drawing.Size(518, 10)
        Me.VisualStudioHorizontalScrollBar1.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar1.TabIndex = 5
        Me.VisualStudioHorizontalScrollBar1.Text = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.Value = 0
        '
        'VisualStudioVerticalScrollBar1
        '
        Me.VisualStudioVerticalScrollBar1.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar1.LargeChange = 10
        Me.VisualStudioVerticalScrollBar1.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Llen = -1
        Me.VisualStudioVerticalScrollBar1.Location = New System.Drawing.Point(518, 0)
        Me.VisualStudioVerticalScrollBar1.Maximum = 1
        Me.VisualStudioVerticalScrollBar1.Minimum = 0
        Me.VisualStudioVerticalScrollBar1.Name = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar1.Size = New System.Drawing.Size(10, 176)
        Me.VisualStudioVerticalScrollBar1.SmallChange = 10
        Me.VisualStudioVerticalScrollBar1.TabIndex = 4
        Me.VisualStudioVerticalScrollBar1.Text = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Value = 0
        '
        'PNLLOGES
        '
        Me.PNLLOGES.Controls.Add(Me.MTabControl)
        Me.PNLLOGES.Controls.Add(Me.PNLLOGESTOP)
        Me.PNLLOGES.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNLLOGES.Location = New System.Drawing.Point(0, 0)
        Me.PNLLOGES.Name = "PNLLOGES"
        Me.PNLLOGES.Size = New System.Drawing.Size(528, 215)
        Me.PNLLOGES.TabIndex = 0
        '
        'MTabControl
        '
        Me.MTabControl.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.MTabControl.BorderColor_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.MTabControl.Controls.Add(Me.TabPageMonitorAndroid)
        Me.MTabControl.Controls.Add(Me.TabPageBlackList)
        Me.MTabControl.Controls.Add(Me.TabPageConnectionLogs)
        Me.MTabControl.Cursor = System.Windows.Forms.Cursors.Default
        Me.MTabControl.DefaultBackColor_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.MTabControl.DefaultColor0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.MTabControl.DefaultColor1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.MTabControl.DefaultForColor_S = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.MTabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MTabControl.FForColorSelcted_S = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.MTabControl.ItemSize = New System.Drawing.Size(25, 25)
        Me.MTabControl.Location = New System.Drawing.Point(0, 21)
        Me.MTabControl.MouseOver0_S = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MTabControl.MouseOver1_S = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MTabControl.Multiline = True
        Me.MTabControl.Name = "MTabControl"
        Me.MTabControl.SelectedIndex = 0
        Me.MTabControl.Size = New System.Drawing.Size(528, 194)
        Me.MTabControl.TabIndex = 1
        '
        'TabPageMonitorAndroid
        '
        Me.TabPageMonitorAndroid.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPageMonitorAndroid.Controls.Add(Me.PNLMonitor)
        Me.TabPageMonitorAndroid.Location = New System.Drawing.Point(4, 4)
        Me.TabPageMonitorAndroid.Name = "TabPageMonitorAndroid"
        Me.TabPageMonitorAndroid.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageMonitorAndroid.Size = New System.Drawing.Size(520, 161)
        Me.TabPageMonitorAndroid.TabIndex = 2
        Me.TabPageMonitorAndroid.Text = "Monitor Android"
        '
        'PNLMonitor
        '
        Me.PNLMonitor.Controls.Add(Me.DataMonitorAndroidView)
        Me.PNLMonitor.Controls.Add(Me.VisualStudioHorizontalScrollBar4)
        Me.PNLMonitor.Controls.Add(Me.VisualStudioVerticalScrollBar5)
        Me.PNLMonitor.Controls.Add(Me.PNLTOOL_Monitor)
        Me.PNLMonitor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNLMonitor.Location = New System.Drawing.Point(3, 3)
        Me.PNLMonitor.Name = "PNLMonitor"
        Me.PNLMonitor.Size = New System.Drawing.Size(514, 155)
        Me.PNLMonitor.TabIndex = 0
        '
        'DataMonitorAndroidView
        '
        Me.DataMonitorAndroidView.AllowUserToAddRows = False
        Me.DataMonitorAndroidView.AllowUserToDeleteRows = False
        Me.DataMonitorAndroidView.AllowUserToResizeColumns = False
        Me.DataMonitorAndroidView.AllowUserToResizeRows = False
        Me.DataMonitorAndroidView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataMonitorAndroidView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataMonitorAndroidView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.DataMonitorAndroidView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataMonitorAndroidView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataMonitorAndroidView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataMonitorAndroidView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataMonitorAndroidView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn6, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.ColTime, Me.DataGridViewTextBoxColumn11})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataMonitorAndroidView.DefaultCellStyle = DataGridViewCellStyle11
        Me.DataMonitorAndroidView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataMonitorAndroidView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataMonitorAndroidView.EnableHeadersVisualStyles = False
        Me.DataMonitorAndroidView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DataMonitorAndroidView.Location = New System.Drawing.Point(0, 20)
        Me.DataMonitorAndroidView.MultiSelect = False
        Me.DataMonitorAndroidView.Name = "DataMonitorAndroidView"
        Me.DataMonitorAndroidView.RowHeadersVisible = False
        Me.DataMonitorAndroidView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataMonitorAndroidView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataMonitorAndroidView.Size = New System.Drawing.Size(504, 125)
        Me.DataMonitorAndroidView.TabIndex = 11
        '
        'DataGridViewImageColumn6
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DataGridViewImageColumn6.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridViewImageColumn6.FillWeight = 17.0!
        Me.DataGridViewImageColumn6.HeaderText = "Flag"
        Me.DataGridViewImageColumn6.Name = "DataGridViewImageColumn6"
        Me.DataGridViewImageColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewImageColumn6.Width = 34
        '
        'DataGridViewTextBoxColumn8
        '
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DataGridViewTextBoxColumn8.DefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridViewTextBoxColumn8.HeaderText = "Remote-Address"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 119
        '
        'DataGridViewTextBoxColumn9
        '
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.DataGridViewTextBoxColumn9.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridViewTextBoxColumn9.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 63
        '
        'ColTime
        '
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White
        Me.ColTime.DefaultCellStyle = DataGridViewCellStyle9
        Me.ColTime.HeaderText = "Time"
        Me.ColTime.Name = "ColTime"
        Me.ColTime.Width = 58
        '
        'DataGridViewTextBoxColumn11
        '
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.DataGridViewTextBoxColumn11.DefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridViewTextBoxColumn11.HeaderText = "Output"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 69
        '
        'VisualStudioHorizontalScrollBar4
        '
        Me.VisualStudioHorizontalScrollBar4.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar4.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar4.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar4.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar4.Location = New System.Drawing.Point(0, 145)
        Me.VisualStudioHorizontalScrollBar4.Maximum = 1
        Me.VisualStudioHorizontalScrollBar4.Minimum = 0
        Me.VisualStudioHorizontalScrollBar4.Name = "VisualStudioHorizontalScrollBar4"
        Me.VisualStudioHorizontalScrollBar4.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar4.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar4.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar4.Size = New System.Drawing.Size(504, 10)
        Me.VisualStudioHorizontalScrollBar4.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar4.TabIndex = 7
        Me.VisualStudioHorizontalScrollBar4.Text = "VisualStudioHorizontalScrollBar4"
        Me.VisualStudioHorizontalScrollBar4.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar4.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar4.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar4.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar4.Value = 0
        '
        'VisualStudioVerticalScrollBar5
        '
        Me.VisualStudioVerticalScrollBar5.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar5.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar5.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar5.LargeChange = 10
        Me.VisualStudioVerticalScrollBar5.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.Llen = -1
        Me.VisualStudioVerticalScrollBar5.Location = New System.Drawing.Point(504, 20)
        Me.VisualStudioVerticalScrollBar5.Maximum = 1
        Me.VisualStudioVerticalScrollBar5.Minimum = 0
        Me.VisualStudioVerticalScrollBar5.Name = "VisualStudioVerticalScrollBar5"
        Me.VisualStudioVerticalScrollBar5.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar5.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar5.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar5.Size = New System.Drawing.Size(10, 135)
        Me.VisualStudioVerticalScrollBar5.SmallChange = 10
        Me.VisualStudioVerticalScrollBar5.TabIndex = 6
        Me.VisualStudioVerticalScrollBar5.Text = "VisualStudioVerticalScrollBar2"
        Me.VisualStudioVerticalScrollBar5.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar5.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar5.Value = 0
        '
        'PNLTOOL_Monitor
        '
        Me.PNLTOOL_Monitor.Controls.Add(Me.BAutoDelete1)
        Me.PNLTOOL_Monitor.Controls.Add(Me.LinearLine8)
        Me.PNLTOOL_Monitor.Controls.Add(Me.BDeleteAll2)
        Me.PNLTOOL_Monitor.Controls.Add(Me.LinearLine9)
        Me.PNLTOOL_Monitor.Controls.Add(Me.BDelete2)
        Me.PNLTOOL_Monitor.Controls.Add(Me.LinearLine10)
        Me.PNLTOOL_Monitor.Controls.Add(Me.Bdown2)
        Me.PNLTOOL_Monitor.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNLTOOL_Monitor.Location = New System.Drawing.Point(0, 0)
        Me.PNLTOOL_Monitor.Name = "PNLTOOL_Monitor"
        Me.PNLTOOL_Monitor.Size = New System.Drawing.Size(514, 20)
        Me.PNLTOOL_Monitor.TabIndex = 1
        '
        'BAutoDelete1
        '
        Me.BAutoDelete1.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete1.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete1.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BAutoDelete1.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BAutoDelete1.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete1.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BAutoDelete1.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete1.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete1.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BAutoDelete1.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BAutoDelete1.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BAutoDelete1.Dock = System.Windows.Forms.DockStyle.Left
        Me.BAutoDelete1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BAutoDelete1.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BAutoDelete1.ImageChoice = Nothing
        Me.BAutoDelete1.Location = New System.Drawing.Point(84, 0)
        Me.BAutoDelete1.Name = "BAutoDelete1"
        Me.BAutoDelete1.ShowImage = False
        Me.BAutoDelete1.ShowText = False
        Me.BAutoDelete1.Size = New System.Drawing.Size(20, 20)
        Me.BAutoDelete1.TabIndex = 15
        Me.BAutoDelete1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BAutoDelete1.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete1.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BAutoDelete1.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine8
        '
        Me.LinearLine8.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine8.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine8.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine8.Location = New System.Drawing.Point(76, 0)
        Me.LinearLine8.Name = "LinearLine8"
        Me.LinearLine8.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine8.TabIndex = 14
        Me.LinearLine8.Text = "LinearLine1"
        '
        'BDeleteAll2
        '
        Me.BDeleteAll2.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll2.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll2.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll2.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll2.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll2.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll2.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll2.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll2.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDeleteAll2.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll2.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDeleteAll2.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDeleteAll2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDeleteAll2.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDeleteAll2.ImageChoice = Nothing
        Me.BDeleteAll2.Location = New System.Drawing.Point(56, 0)
        Me.BDeleteAll2.Name = "BDeleteAll2"
        Me.BDeleteAll2.ShowImage = False
        Me.BDeleteAll2.ShowText = False
        Me.BDeleteAll2.Size = New System.Drawing.Size(20, 20)
        Me.BDeleteAll2.TabIndex = 13
        Me.BDeleteAll2.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDeleteAll2.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll2.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDeleteAll2.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine9
        '
        Me.LinearLine9.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine9.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine9.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine9.Location = New System.Drawing.Point(48, 0)
        Me.LinearLine9.Name = "LinearLine9"
        Me.LinearLine9.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine9.TabIndex = 12
        Me.LinearLine9.Text = "LinearLine1"
        '
        'BDelete2
        '
        Me.BDelete2.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete2.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete2.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete2.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete2.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete2.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete2.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete2.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete2.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDelete2.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete2.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDelete2.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDelete2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDelete2.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDelete2.ImageChoice = Nothing
        Me.BDelete2.Location = New System.Drawing.Point(28, 0)
        Me.BDelete2.Name = "BDelete2"
        Me.BDelete2.ShowImage = False
        Me.BDelete2.ShowText = False
        Me.BDelete2.Size = New System.Drawing.Size(20, 20)
        Me.BDelete2.TabIndex = 11
        Me.BDelete2.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDelete2.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete2.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDelete2.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine10
        '
        Me.LinearLine10.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine10.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine10.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine10.Location = New System.Drawing.Point(20, 0)
        Me.LinearLine10.Name = "LinearLine10"
        Me.LinearLine10.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine10.TabIndex = 5
        Me.LinearLine10.Text = "LinearLine1"
        '
        'Bdown2
        '
        Me.Bdown2.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown2.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown2.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown2.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown2.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown2.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown2.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown2.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown2.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Bdown2.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown2.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Bdown2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Bdown2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Bdown2.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.Bdown2.ImageChoice = Nothing
        Me.Bdown2.Location = New System.Drawing.Point(0, 0)
        Me.Bdown2.Name = "Bdown2"
        Me.Bdown2.ShowImage = False
        Me.Bdown2.ShowText = False
        Me.Bdown2.Size = New System.Drawing.Size(20, 20)
        Me.Bdown2.TabIndex = 1
        Me.Bdown2.TextAlignment = System.Drawing.StringAlignment.Center
        Me.Bdown2.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown2.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Bdown2.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'TabPageBlackList
        '
        Me.TabPageBlackList.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPageBlackList.Controls.Add(Me.LNothing1)
        Me.TabPageBlackList.Controls.Add(Me.DataBlackListView)
        Me.TabPageBlackList.Controls.Add(Me.VisualStudioHorizontalScrollBar3)
        Me.TabPageBlackList.Controls.Add(Me.VisualStudioVerticalScrollBar4)
        Me.TabPageBlackList.Controls.Add(Me.PNLTOOL_BlackList)
        Me.TabPageBlackList.Location = New System.Drawing.Point(4, 4)
        Me.TabPageBlackList.Name = "TabPageBlackList"
        Me.TabPageBlackList.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageBlackList.Size = New System.Drawing.Size(520, 161)
        Me.TabPageBlackList.TabIndex = 1
        Me.TabPageBlackList.Text = "Black List"
        '
        'LNothing1
        '
        Me.LNothing1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.LNothing1.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LNothing1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LNothing1.Location = New System.Drawing.Point(10, 45)
        Me.LNothing1.Name = "LNothing1"
        Me.LNothing1.Size = New System.Drawing.Size(83, 16)
        Me.LNothing1.TabIndex = 11
        Me.LNothing1.Text = "Nothing "
        Me.LNothing1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LNothing1.Visible = False
        '
        'DataBlackListView
        '
        Me.DataBlackListView.AllowUserToAddRows = False
        Me.DataBlackListView.AllowUserToDeleteRows = False
        Me.DataBlackListView.AllowUserToResizeColumns = False
        Me.DataBlackListView.AllowUserToResizeRows = False
        Me.DataBlackListView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataBlackListView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataBlackListView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.DataBlackListView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataBlackListView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataBlackListView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.DataBlackListView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataBlackListView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column44})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataBlackListView.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataBlackListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataBlackListView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataBlackListView.EnableHeadersVisualStyles = False
        Me.DataBlackListView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DataBlackListView.Location = New System.Drawing.Point(3, 23)
        Me.DataBlackListView.MultiSelect = False
        Me.DataBlackListView.Name = "DataBlackListView"
        Me.DataBlackListView.RowHeadersVisible = False
        Me.DataBlackListView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataBlackListView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataBlackListView.Size = New System.Drawing.Size(504, 125)
        Me.DataBlackListView.TabIndex = 10
        '
        'Column44
        '
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(175, Byte), Integer))
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(175, Byte), Integer))
        Me.Column44.DefaultCellStyle = DataGridViewCellStyle13
        Me.Column44.HeaderText = "Ln"
        Me.Column44.Name = "Column44"
        Me.Column44.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column44.Width = 25
        '
        'VisualStudioHorizontalScrollBar3
        '
        Me.VisualStudioHorizontalScrollBar3.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar3.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar3.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar3.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar3.Location = New System.Drawing.Point(3, 148)
        Me.VisualStudioHorizontalScrollBar3.Maximum = 1
        Me.VisualStudioHorizontalScrollBar3.Minimum = 0
        Me.VisualStudioHorizontalScrollBar3.Name = "VisualStudioHorizontalScrollBar3"
        Me.VisualStudioHorizontalScrollBar3.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar3.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar3.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar3.Size = New System.Drawing.Size(504, 10)
        Me.VisualStudioHorizontalScrollBar3.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar3.TabIndex = 6
        Me.VisualStudioHorizontalScrollBar3.Text = "VisualStudioHorizontalScrollBar3"
        Me.VisualStudioHorizontalScrollBar3.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar3.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar3.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar3.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar3.Value = 0
        '
        'VisualStudioVerticalScrollBar4
        '
        Me.VisualStudioVerticalScrollBar4.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar4.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar4.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar4.LargeChange = 10
        Me.VisualStudioVerticalScrollBar4.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.Llen = -1
        Me.VisualStudioVerticalScrollBar4.Location = New System.Drawing.Point(507, 23)
        Me.VisualStudioVerticalScrollBar4.Maximum = 1
        Me.VisualStudioVerticalScrollBar4.Minimum = 0
        Me.VisualStudioVerticalScrollBar4.Name = "VisualStudioVerticalScrollBar4"
        Me.VisualStudioVerticalScrollBar4.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar4.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar4.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar4.Size = New System.Drawing.Size(10, 135)
        Me.VisualStudioVerticalScrollBar4.SmallChange = 10
        Me.VisualStudioVerticalScrollBar4.TabIndex = 5
        Me.VisualStudioVerticalScrollBar4.Text = "VisualStudioVerticalScrollBar2"
        Me.VisualStudioVerticalScrollBar4.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar4.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar4.Value = 0
        '
        'PNLTOOL_BlackList
        '
        Me.PNLTOOL_BlackList.Controls.Add(Me.LinearLine21)
        Me.PNLTOOL_BlackList.Controls.Add(Me.LBAddress)
        Me.PNLTOOL_BlackList.Controls.Add(Me.LinearLine7)
        Me.PNLTOOL_BlackList.Controls.Add(Me.BDeleteAll1)
        Me.PNLTOOL_BlackList.Controls.Add(Me.LinearLine6)
        Me.PNLTOOL_BlackList.Controls.Add(Me.BRefres0)
        Me.PNLTOOL_BlackList.Controls.Add(Me.LinearLine5)
        Me.PNLTOOL_BlackList.Controls.Add(Me.BDelete1)
        Me.PNLTOOL_BlackList.Controls.Add(Me.LinearLine4)
        Me.PNLTOOL_BlackList.Controls.Add(Me.TTextAddress)
        Me.PNLTOOL_BlackList.Controls.Add(Me.Bdown1)
        Me.PNLTOOL_BlackList.Controls.Add(Me.BADD0)
        Me.PNLTOOL_BlackList.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNLTOOL_BlackList.Location = New System.Drawing.Point(3, 3)
        Me.PNLTOOL_BlackList.Name = "PNLTOOL_BlackList"
        Me.PNLTOOL_BlackList.Size = New System.Drawing.Size(514, 20)
        Me.PNLTOOL_BlackList.TabIndex = 0
        '
        'LinearLine21
        '
        Me.LinearLine21.Colour0 = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.LinearLine21.Colour1 = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.LinearLine21.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine21.Location = New System.Drawing.Point(112, 0)
        Me.LinearLine21.Name = "LinearLine21"
        Me.LinearLine21.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine21.TabIndex = 11
        Me.LinearLine21.Text = "LinearLine1"
        '
        'LBAddress
        '
        Me.LBAddress.AutoSize = True
        Me.LBAddress.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBAddress.ForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.LBAddress.Location = New System.Drawing.Point(128, 3)
        Me.LBAddress.Name = "LBAddress"
        Me.LBAddress.Size = New System.Drawing.Size(51, 13)
        Me.LBAddress.TabIndex = 10
        Me.LBAddress.Text = "Address:"
        '
        'LinearLine7
        '
        Me.LinearLine7.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine7.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine7.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine7.Location = New System.Drawing.Point(104, 0)
        Me.LinearLine7.Name = "LinearLine7"
        Me.LinearLine7.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine7.TabIndex = 9
        Me.LinearLine7.Text = "LinearLine1"
        '
        'BDeleteAll1
        '
        Me.BDeleteAll1.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll1.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll1.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll1.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll1.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll1.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll1.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll1.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll1.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDeleteAll1.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll1.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDeleteAll1.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDeleteAll1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDeleteAll1.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDeleteAll1.ImageChoice = Nothing
        Me.BDeleteAll1.Location = New System.Drawing.Point(84, 0)
        Me.BDeleteAll1.Name = "BDeleteAll1"
        Me.BDeleteAll1.ShowImage = False
        Me.BDeleteAll1.ShowText = False
        Me.BDeleteAll1.Size = New System.Drawing.Size(20, 20)
        Me.BDeleteAll1.TabIndex = 8
        Me.BDeleteAll1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDeleteAll1.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll1.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDeleteAll1.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine6
        '
        Me.LinearLine6.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine6.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine6.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine6.Location = New System.Drawing.Point(76, 0)
        Me.LinearLine6.Name = "LinearLine6"
        Me.LinearLine6.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine6.TabIndex = 7
        Me.LinearLine6.Text = "LinearLine1"
        '
        'BRefres0
        '
        Me.BRefres0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BRefres0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BRefres0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BRefres0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BRefres0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BRefres0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BRefres0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRefres0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRefres0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BRefres0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BRefres0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BRefres0.Dock = System.Windows.Forms.DockStyle.Left
        Me.BRefres0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BRefres0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BRefres0.ImageChoice = Nothing
        Me.BRefres0.Location = New System.Drawing.Point(56, 0)
        Me.BRefres0.Name = "BRefres0"
        Me.BRefres0.ShowImage = False
        Me.BRefres0.ShowText = False
        Me.BRefres0.Size = New System.Drawing.Size(20, 20)
        Me.BRefres0.TabIndex = 6
        Me.BRefres0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BRefres0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRefres0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BRefres0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine5
        '
        Me.LinearLine5.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine5.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine5.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine5.Location = New System.Drawing.Point(48, 0)
        Me.LinearLine5.Name = "LinearLine5"
        Me.LinearLine5.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine5.TabIndex = 5
        Me.LinearLine5.Text = "LinearLine1"
        '
        'BDelete1
        '
        Me.BDelete1.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete1.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete1.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete1.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete1.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete1.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete1.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete1.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete1.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDelete1.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete1.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDelete1.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDelete1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDelete1.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDelete1.ImageChoice = Nothing
        Me.BDelete1.Location = New System.Drawing.Point(28, 0)
        Me.BDelete1.Name = "BDelete1"
        Me.BDelete1.ShowImage = False
        Me.BDelete1.ShowText = False
        Me.BDelete1.Size = New System.Drawing.Size(20, 20)
        Me.BDelete1.TabIndex = 4
        Me.BDelete1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDelete1.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete1.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDelete1.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine4
        '
        Me.LinearLine4.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine4.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine4.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine4.Location = New System.Drawing.Point(20, 0)
        Me.LinearLine4.Name = "LinearLine4"
        Me.LinearLine4.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine4.TabIndex = 3
        Me.LinearLine4.Text = "LinearLine1"
        '
        'TTextAddress
        '
        Me.TTextAddress.__CLRXX_S = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.TTextAddress.__CLRXX_SLave = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TTextAddress._CBorderEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TTextAddress._CBorderEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TTextAddress._CBorderEnter0_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TTextAddress._CBorderEnter1_S = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TTextAddress._CBorderLave0_S = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(72, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.TTextAddress._CBorderLave1_S = System.Drawing.Color.FromArgb(CType(CType(72, Byte), Integer), CType(CType(72, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.TTextAddress._CVK_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TTextAddress.BackColor = System.Drawing.Color.Transparent
        Me.TTextAddress.Btnshow = False
        Me.TTextAddress.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TTextAddress.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.TTextAddress.Location = New System.Drawing.Point(185, 1)
        Me.TTextAddress.MaxLength = 32767
        Me.TTextAddress.Multiline = False
        Me.TTextAddress.Name = "TTextAddress"
        Me.TTextAddress.ReadOnly = False
        Me.TTextAddress.Size = New System.Drawing.Size(117, 16)
        Me.TTextAddress.TabIndex = 2
        Me.TTextAddress.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left
        Me.TTextAddress.UseSystemPasswordChar = False
        '
        'Bdown1
        '
        Me.Bdown1.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown1.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown1.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown1.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown1.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown1.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown1.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown1.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown1.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Bdown1.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown1.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Bdown1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Bdown1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Bdown1.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.Bdown1.ImageChoice = Nothing
        Me.Bdown1.Location = New System.Drawing.Point(0, 0)
        Me.Bdown1.Name = "Bdown1"
        Me.Bdown1.ShowImage = False
        Me.Bdown1.ShowText = False
        Me.Bdown1.Size = New System.Drawing.Size(20, 20)
        Me.Bdown1.TabIndex = 1
        Me.Bdown1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.Bdown1.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown1.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Bdown1.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'BADD0
        '
        Me.BADD0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BADD0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BADD0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BADD0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BADD0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BADD0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BADD0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BADD0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BADD0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BADD0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BADD0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BADD0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BADD0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BADD0.ImageChoice = Nothing
        Me.BADD0.Location = New System.Drawing.Point(307, 0)
        Me.BADD0.Name = "BADD0"
        Me.BADD0.ShowImage = False
        Me.BADD0.ShowText = False
        Me.BADD0.Size = New System.Drawing.Size(20, 20)
        Me.BADD0.TabIndex = 0
        Me.BADD0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BADD0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BADD0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BADD0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'TabPageConnectionLogs
        '
        Me.TabPageConnectionLogs.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPageConnectionLogs.Controls.Add(Me.PanelLogsMove)
        Me.TabPageConnectionLogs.Location = New System.Drawing.Point(4, 4)
        Me.TabPageConnectionLogs.Name = "TabPageConnectionLogs"
        Me.TabPageConnectionLogs.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageConnectionLogs.Size = New System.Drawing.Size(520, 161)
        Me.TabPageConnectionLogs.TabIndex = 0
        Me.TabPageConnectionLogs.Text = "Connections Log"
        '
        'PanelLogsMove
        '
        Me.PanelLogsMove.Controls.Add(Me.DataLogsView)
        Me.PanelLogsMove.Controls.Add(Me.PNLTOOL_Logs)
        Me.PanelLogsMove.Controls.Add(Me.VisualStudioHorizontalScrollBar2)
        Me.PanelLogsMove.Controls.Add(Me.VisualStudioVerticalScrollBar3)
        Me.PanelLogsMove.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelLogsMove.Location = New System.Drawing.Point(3, 3)
        Me.PanelLogsMove.Name = "PanelLogsMove"
        Me.PanelLogsMove.Size = New System.Drawing.Size(514, 155)
        Me.PanelLogsMove.TabIndex = 0
        '
        'DataLogsView
        '
        Me.DataLogsView.AllowUserToAddRows = False
        Me.DataLogsView.AllowUserToDeleteRows = False
        Me.DataLogsView.AllowUserToResizeColumns = False
        Me.DataLogsView.AllowUserToResizeRows = False
        Me.DataLogsView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataLogsView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataLogsView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.DataLogsView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataLogsView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataLogsView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.DataLogsView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataLogsView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn4, Me.DataGridViewTextBoxColumn6, Me.Str0, Me.Str1, Me.Str2, Me.Str3})
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataLogsView.DefaultCellStyle = DataGridViewCellStyle18
        Me.DataLogsView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataLogsView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataLogsView.EnableHeadersVisualStyles = False
        Me.DataLogsView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.DataLogsView.Location = New System.Drawing.Point(0, 20)
        Me.DataLogsView.MultiSelect = False
        Me.DataLogsView.Name = "DataLogsView"
        Me.DataLogsView.RowHeadersVisible = False
        Me.DataLogsView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DataLogsView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataLogsView.ShowCellToolTips = False
        Me.DataLogsView.Size = New System.Drawing.Size(504, 125)
        Me.DataLogsView.TabIndex = 11
        '
        'DataGridViewImageColumn4
        '
        Me.DataGridViewImageColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn4.FillWeight = 17.0!
        Me.DataGridViewImageColumn4.HeaderText = "Flag"
        Me.DataGridViewImageColumn4.Name = "DataGridViewImageColumn4"
        Me.DataGridViewImageColumn4.Width = 34
        '
        'DataGridViewTextBoxColumn6
        '
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle16
        Me.DataGridViewTextBoxColumn6.HeaderText = "Remote-Address"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 119
        '
        'Str0
        '
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!)
        Me.Str0.DefaultCellStyle = DataGridViewCellStyle17
        Me.Str0.HeaderText = "Mode"
        Me.Str0.Name = "Str0"
        Me.Str0.Width = 62
        '
        'Str1
        '
        Me.Str1.HeaderText = "n/a"
        Me.Str1.Name = "Str1"
        Me.Str1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Str1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Str1.Width = 49
        '
        'Str2
        '
        Me.Str2.HeaderText = "Time"
        Me.Str2.Name = "Str2"
        Me.Str2.Width = 58
        '
        'Str3
        '
        Me.Str3.HeaderText = "Status"
        Me.Str3.Name = "Str3"
        Me.Str3.Width = 64
        '
        'PNLTOOL_Logs
        '
        Me.PNLTOOL_Logs.Controls.Add(Me.BAutoDelete0)
        Me.PNLTOOL_Logs.Controls.Add(Me.LinearLine3)
        Me.PNLTOOL_Logs.Controls.Add(Me.BDeleteAll0)
        Me.PNLTOOL_Logs.Controls.Add(Me.LinearLine2)
        Me.PNLTOOL_Logs.Controls.Add(Me.BDelete0)
        Me.PNLTOOL_Logs.Controls.Add(Me.LinearLine1)
        Me.PNLTOOL_Logs.Controls.Add(Me.Bdown0)
        Me.PNLTOOL_Logs.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNLTOOL_Logs.Location = New System.Drawing.Point(0, 0)
        Me.PNLTOOL_Logs.Name = "PNLTOOL_Logs"
        Me.PNLTOOL_Logs.Size = New System.Drawing.Size(504, 20)
        Me.PNLTOOL_Logs.TabIndex = 10
        '
        'BAutoDelete0
        '
        Me.BAutoDelete0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BAutoDelete0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BAutoDelete0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BAutoDelete0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BAutoDelete0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BAutoDelete0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BAutoDelete0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BAutoDelete0.Dock = System.Windows.Forms.DockStyle.Left
        Me.BAutoDelete0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BAutoDelete0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BAutoDelete0.ImageChoice = Nothing
        Me.BAutoDelete0.Location = New System.Drawing.Point(84, 0)
        Me.BAutoDelete0.Name = "BAutoDelete0"
        Me.BAutoDelete0.ShowImage = False
        Me.BAutoDelete0.ShowText = False
        Me.BAutoDelete0.Size = New System.Drawing.Size(20, 20)
        Me.BAutoDelete0.TabIndex = 15
        Me.BAutoDelete0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BAutoDelete0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BAutoDelete0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BAutoDelete0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine3
        '
        Me.LinearLine3.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine3.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine3.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine3.Location = New System.Drawing.Point(76, 0)
        Me.LinearLine3.Name = "LinearLine3"
        Me.LinearLine3.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine3.TabIndex = 14
        Me.LinearLine3.Text = "LinearLine3"
        '
        'BDeleteAll0
        '
        Me.BDeleteAll0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDeleteAll0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDeleteAll0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDeleteAll0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDeleteAll0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDeleteAll0.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDeleteAll0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDeleteAll0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDeleteAll0.ImageChoice = Nothing
        Me.BDeleteAll0.Location = New System.Drawing.Point(56, 0)
        Me.BDeleteAll0.Name = "BDeleteAll0"
        Me.BDeleteAll0.ShowImage = False
        Me.BDeleteAll0.ShowText = False
        Me.BDeleteAll0.Size = New System.Drawing.Size(20, 20)
        Me.BDeleteAll0.TabIndex = 13
        Me.BDeleteAll0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDeleteAll0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDeleteAll0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDeleteAll0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine2
        '
        Me.LinearLine2.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine2.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine2.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine2.Location = New System.Drawing.Point(48, 0)
        Me.LinearLine2.Name = "LinearLine2"
        Me.LinearLine2.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine2.TabIndex = 12
        Me.LinearLine2.Text = "LinearLine3"
        '
        'BDelete0
        '
        Me.BDelete0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BDelete0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.BDelete0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BDelete0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BDelete0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BDelete0.Dock = System.Windows.Forms.DockStyle.Left
        Me.BDelete0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BDelete0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.BDelete0.ImageChoice = Nothing
        Me.BDelete0.Location = New System.Drawing.Point(28, 0)
        Me.BDelete0.Name = "BDelete0"
        Me.BDelete0.ShowImage = False
        Me.BDelete0.ShowText = False
        Me.BDelete0.Size = New System.Drawing.Size(20, 20)
        Me.BDelete0.TabIndex = 11
        Me.BDelete0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BDelete0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BDelete0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BDelete0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LinearLine1
        '
        Me.LinearLine1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinearLine1.Dock = System.Windows.Forms.DockStyle.Left
        Me.LinearLine1.Location = New System.Drawing.Point(20, 0)
        Me.LinearLine1.Name = "LinearLine1"
        Me.LinearLine1.Size = New System.Drawing.Size(8, 20)
        Me.LinearLine1.TabIndex = 10
        Me.LinearLine1.Text = "LinearLine1"
        '
        'Bdown0
        '
        Me.Bdown0.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown0.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown0.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown0.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.Bdown0.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Bdown0.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown0.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown0.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown0.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.Bdown0.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.Bdown0.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Bdown0.Dock = System.Windows.Forms.DockStyle.Left
        Me.Bdown0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Bdown0.ImageAlignment = SpyNote_7._0.SN.ThemeButtonImge.__ImageAlignment.Left
        Me.Bdown0.ImageChoice = Nothing
        Me.Bdown0.Location = New System.Drawing.Point(0, 0)
        Me.Bdown0.Name = "Bdown0"
        Me.Bdown0.ShowImage = False
        Me.Bdown0.ShowText = False
        Me.Bdown0.Size = New System.Drawing.Size(20, 20)
        Me.Bdown0.TabIndex = 9
        Me.Bdown0.TextAlignment = System.Drawing.StringAlignment.Center
        Me.Bdown0.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Bdown0.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Bdown0.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'VisualStudioHorizontalScrollBar2
        '
        Me.VisualStudioHorizontalScrollBar2.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar2.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar2.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar2.Location = New System.Drawing.Point(0, 145)
        Me.VisualStudioHorizontalScrollBar2.Maximum = 1
        Me.VisualStudioHorizontalScrollBar2.Minimum = 0
        Me.VisualStudioHorizontalScrollBar2.Name = "VisualStudioHorizontalScrollBar2"
        Me.VisualStudioHorizontalScrollBar2.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar2.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar2.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar2.Size = New System.Drawing.Size(504, 10)
        Me.VisualStudioHorizontalScrollBar2.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar2.TabIndex = 8
        Me.VisualStudioHorizontalScrollBar2.Text = "VisualStudioHorizontalScrollBar2"
        Me.VisualStudioHorizontalScrollBar2.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar2.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar2.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar2.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar2.Value = 0
        '
        'VisualStudioVerticalScrollBar3
        '
        Me.VisualStudioVerticalScrollBar3.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar3.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar3.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar3.LargeChange = 10
        Me.VisualStudioVerticalScrollBar3.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.Llen = -1
        Me.VisualStudioVerticalScrollBar3.Location = New System.Drawing.Point(504, 0)
        Me.VisualStudioVerticalScrollBar3.Maximum = 1
        Me.VisualStudioVerticalScrollBar3.Minimum = 0
        Me.VisualStudioVerticalScrollBar3.Name = "VisualStudioVerticalScrollBar3"
        Me.VisualStudioVerticalScrollBar3.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar3.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar3.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar3.Size = New System.Drawing.Size(10, 155)
        Me.VisualStudioVerticalScrollBar3.SmallChange = 10
        Me.VisualStudioVerticalScrollBar3.TabIndex = 7
        Me.VisualStudioVerticalScrollBar3.Text = "VisualStudioVerticalScrollBar2"
        Me.VisualStudioVerticalScrollBar3.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar3.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar3.Value = 0
        '
        'PNLLOGESTOP
        '
        Me.PNLLOGESTOP.Controls.Add(Me.PNLTEXT)
        Me.PNLLOGESTOP.Cursor = System.Windows.Forms.Cursors.Default
        Me.PNLLOGESTOP.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNLLOGESTOP.Location = New System.Drawing.Point(0, 0)
        Me.PNLLOGESTOP.Name = "PNLLOGESTOP"
        Me.PNLLOGESTOP.Size = New System.Drawing.Size(528, 21)
        Me.PNLLOGESTOP.TabIndex = 0
        '
        'PNLTEXT
        '
        Me.PNLTEXT.Controls.Add(Me.MaximTab)
        Me.PNLTEXT.Controls.Add(Me.CloseTab)
        Me.PNLTEXT.Controls.Add(Me.LabelText)
        Me.PNLTEXT.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNLTEXT.Location = New System.Drawing.Point(0, 0)
        Me.PNLTEXT.Name = "PNLTEXT"
        Me.PNLTEXT.Size = New System.Drawing.Size(528, 21)
        Me.PNLTEXT.TabIndex = 0
        '
        'MaximTab
        '
        Me.MaximTab.BackColor = System.Drawing.Color.Transparent
        Me.MaximTab.Dock = System.Windows.Forms.DockStyle.Right
        Me.MaximTab.Location = New System.Drawing.Point(494, 0)
        Me.MaximTab.Name = "MaximTab"
        Me.MaximTab.Size = New System.Drawing.Size(17, 21)
        Me.MaximTab.TabIndex = 2
        Me.MaximTab.TabStop = False
        '
        'CloseTab
        '
        Me.CloseTab.BackColor = System.Drawing.Color.Transparent
        Me.CloseTab.Dock = System.Windows.Forms.DockStyle.Right
        Me.CloseTab.Location = New System.Drawing.Point(511, 0)
        Me.CloseTab.Name = "CloseTab"
        Me.CloseTab.Size = New System.Drawing.Size(17, 21)
        Me.CloseTab.TabIndex = 1
        Me.CloseTab.TabStop = False
        '
        'LabelText
        '
        Me.LabelText.BackColor = System.Drawing.Color.Transparent
        Me.LabelText.BackColorNone = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LabelText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelText.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.LabelText.FontColorNone = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabelText.Location = New System.Drawing.Point(0, 0)
        Me.LabelText.Name = "LabelText"
        Me.LabelText.Size = New System.Drawing.Size(528, 21)
        Me.LabelText.TabIndex = 0
        Me.LabelText.TabStop = False
        Me.LabelText.TxText = "Connections Log"
        '
        'VisualStudioVerticalScrollBar2
        '
        Me.VisualStudioVerticalScrollBar2.AmountOfInnerLines = SpyNote_7._0.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar2.Cursor = System.Windows.Forms.Cursors.Default
        Me.VisualStudioVerticalScrollBar2.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar2.LargeChange = 10
        Me.VisualStudioVerticalScrollBar2.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.Llen = -1
        Me.VisualStudioVerticalScrollBar2.Location = New System.Drawing.Point(353, 21)
        Me.VisualStudioVerticalScrollBar2.Maximum = 1
        Me.VisualStudioVerticalScrollBar2.Minimum = 0
        Me.VisualStudioVerticalScrollBar2.Name = "VisualStudioVerticalScrollBar2"
        Me.VisualStudioVerticalScrollBar2.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar2.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar2.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar2.Size = New System.Drawing.Size(10, 375)
        Me.VisualStudioVerticalScrollBar2.SmallChange = 10
        Me.VisualStudioVerticalScrollBar2.TabIndex = 7
        Me.VisualStudioVerticalScrollBar2.Text = "VisualStudioVerticalScrollBar2"
        Me.VisualStudioVerticalScrollBar2.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar2.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar2.Value = 0
        '
        'PanelMain
        '
        Me.PanelMain.AutoSize = True
        Me.PanelMain.Controls.Add(Me.PNL3)
        Me.PanelMain.Controls.Add(Me.Panel7)
        Me.PanelMain.Controls.Add(Me.PNL2)
        Me.PanelMain.Controls.Add(Me.Panel1)
        Me.PanelMain.Controls.Add(Me.PNL1)
        Me.PanelMain.Controls.Add(Me.P1)
        Me.PanelMain.Controls.Add(Me.PictureBox1)
        Me.PanelMain.Cursor = System.Windows.Forms.Cursors.Default
        Me.PanelMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMain.Location = New System.Drawing.Point(0, 21)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(363, 375)
        Me.PanelMain.TabIndex = 0
        '
        'PNL3
        '
        Me.PNL3.Controls.Add(Me.GView)
        Me.PNL3.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNL3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.PNL3.Location = New System.Drawing.Point(0, 124)
        Me.PNL3.Name = "PNL3"
        Me.PNL3.Size = New System.Drawing.Size(363, 24)
        Me.PNL3.TabIndex = 6
        '
        'GView
        '
        Me.GView.AllowUserToAddRows = False
        Me.GView.AllowUserToDeleteRows = False
        Me.GView.AllowUserToResizeColumns = False
        Me.GView.AllowUserToResizeRows = False
        Me.GView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.GView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.GView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.GView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.GView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.GView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GView.ColumnHeadersVisible = False
        Me.GView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.GView.ContextMenuStrip = Me.ContextControl
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        DataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.GView.DefaultCellStyle = DataGridViewCellStyle21
        Me.GView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.GView.EnableHeadersVisualStyles = False
        Me.GView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.GView.Location = New System.Drawing.Point(3, 3)
        Me.GView.Name = "GView"
        Me.GView.RowHeadersVisible = False
        Me.GView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.GView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GView.ShowCellToolTips = False
        Me.GView.Size = New System.Drawing.Size(365, 15)
        Me.GView.TabIndex = 13
        '
        'DataGridViewImageColumn3
        '
        Me.DataGridViewImageColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewImageColumn3.DefaultCellStyle = DataGridViewCellStyle20
        Me.DataGridViewImageColumn3.FillWeight = 25.12131!
        Me.DataGridViewImageColumn3.HeaderText = "Image"
        Me.DataGridViewImageColumn3.Name = "DataGridViewImageColumn3"
        Me.DataGridViewImageColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewImageColumn3.Width = 17
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.FillWeight = 132.9952!
        Me.DataGridViewTextBoxColumn4.HeaderText = "Property"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.FillWeight = 132.9952!
        Me.DataGridViewTextBoxColumn5.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.TSEP3)
        Me.Panel7.Controls.Add(Me.L3)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel7.Location = New System.Drawing.Point(0, 102)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(363, 22)
        Me.Panel7.TabIndex = 5
        '
        'TSEP3
        '
        Me.TSEP3.Colour0 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP3.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP3.Location = New System.Drawing.Point(0, 12)
        Me.TSEP3.Name = "TSEP3"
        Me.TSEP3.Size = New System.Drawing.Size(363, 10)
        Me.TSEP3.TabIndex = 1
        Me.TSEP3.Text = "ThemeSeparator1"
        '
        'L3
        '
        Me.L3.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(84, Byte), Integer), CType(CType(178, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.L3.AutoSize = True
        Me.L3.Dock = System.Windows.Forms.DockStyle.Top
        Me.L3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.L3.LinkColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L3.Location = New System.Drawing.Point(0, 0)
        Me.L3.Name = "L3"
        Me.L3.Size = New System.Drawing.Size(56, 15)
        Me.L3.TabIndex = 0
        Me.L3.TabStop = True
        Me.L3.Tag = "-"
        Me.L3.Text = "   Process"
        '
        'PNL2
        '
        Me.PNL2.Controls.Add(Me.NView)
        Me.PNL2.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNL2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.PNL2.Location = New System.Drawing.Point(0, 78)
        Me.PNL2.Name = "PNL2"
        Me.PNL2.Size = New System.Drawing.Size(363, 24)
        Me.PNL2.TabIndex = 4
        '
        'NView
        '
        Me.NView.AllowUserToAddRows = False
        Me.NView.AllowUserToDeleteRows = False
        Me.NView.AllowUserToResizeColumns = False
        Me.NView.AllowUserToResizeRows = False
        Me.NView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.NView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.NView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.NView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.NView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle22.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.NView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle22
        Me.NView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.NView.ColumnHeadersVisible = False
        Me.NView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn2, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.NView.ContextMenuStrip = Me.ContextControl
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle24.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.NView.DefaultCellStyle = DataGridViewCellStyle24
        Me.NView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.NView.EnableHeadersVisualStyles = False
        Me.NView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.NView.Location = New System.Drawing.Point(3, 3)
        Me.NView.Name = "NView"
        Me.NView.RowHeadersVisible = False
        Me.NView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.NView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.NView.ShowCellToolTips = False
        Me.NView.Size = New System.Drawing.Size(365, 15)
        Me.NView.TabIndex = 13
        '
        'DataGridViewImageColumn2
        '
        Me.DataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewImageColumn2.DefaultCellStyle = DataGridViewCellStyle23
        Me.DataGridViewImageColumn2.FillWeight = 25.12131!
        Me.DataGridViewImageColumn2.HeaderText = "Image"
        Me.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2"
        Me.DataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewImageColumn2.Width = 17
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.FillWeight = 132.9952!
        Me.DataGridViewTextBoxColumn2.HeaderText = "Property"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.FillWeight = 132.9952!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TSEP2)
        Me.Panel1.Controls.Add(Me.L2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 56)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(363, 22)
        Me.Panel1.TabIndex = 3
        '
        'TSEP2
        '
        Me.TSEP2.Colour0 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP2.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP2.Location = New System.Drawing.Point(0, 12)
        Me.TSEP2.Name = "TSEP2"
        Me.TSEP2.Size = New System.Drawing.Size(363, 10)
        Me.TSEP2.TabIndex = 2
        Me.TSEP2.Text = "ThemeSeparator1"
        '
        'L2
        '
        Me.L2.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(84, Byte), Integer), CType(CType(178, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.L2.AutoSize = True
        Me.L2.Dock = System.Windows.Forms.DockStyle.Top
        Me.L2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.L2.LinkColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L2.Location = New System.Drawing.Point(0, 0)
        Me.L2.Name = "L2"
        Me.L2.Size = New System.Drawing.Size(86, 15)
        Me.L2.TabIndex = 1
        Me.L2.TabStop = True
        Me.L2.Tag = "-"
        Me.L2.Text = "   Network Info"
        '
        'PNL1
        '
        Me.PNL1.Controls.Add(Me.PView)
        Me.PNL1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PNL1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.PNL1.Location = New System.Drawing.Point(0, 32)
        Me.PNL1.Name = "PNL1"
        Me.PNL1.Size = New System.Drawing.Size(363, 24)
        Me.PNL1.TabIndex = 2
        '
        'PView
        '
        Me.PView.AllowUserToAddRows = False
        Me.PView.AllowUserToDeleteRows = False
        Me.PView.AllowUserToResizeColumns = False
        Me.PView.AllowUserToResizeRows = False
        Me.PView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.PView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.PView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.PView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle25.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle25
        Me.PView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PView.ColumnHeadersVisible = False
        Me.PView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn1, Me.DataGridViewTextBoxColumn1, Me.Column33})
        Me.PView.ContextMenuStrip = Me.ContextControl
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle27.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        DataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PView.DefaultCellStyle = DataGridViewCellStyle27
        Me.PView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.PView.EnableHeadersVisualStyles = False
        Me.PView.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.PView.Location = New System.Drawing.Point(3, 3)
        Me.PView.Name = "PView"
        Me.PView.RowHeadersVisible = False
        Me.PView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.PView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.PView.ShowCellToolTips = False
        Me.PView.Size = New System.Drawing.Size(364, 15)
        Me.PView.TabIndex = 12
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewImageColumn1.DefaultCellStyle = DataGridViewCellStyle26
        Me.DataGridViewImageColumn1.FillWeight = 25.12131!
        Me.DataGridViewImageColumn1.HeaderText = "Image"
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        Me.DataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewImageColumn1.Width = 17
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.FillWeight = 132.9952!
        Me.DataGridViewTextBoxColumn1.HeaderText = "Property"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Column33
        '
        Me.Column33.FillWeight = 132.9952!
        Me.Column33.HeaderText = "Value"
        Me.Column33.Name = "Column33"
        '
        'P1
        '
        Me.P1.Controls.Add(Me.TSEP1)
        Me.P1.Controls.Add(Me.L1)
        Me.P1.Dock = System.Windows.Forms.DockStyle.Top
        Me.P1.Location = New System.Drawing.Point(0, 10)
        Me.P1.Name = "P1"
        Me.P1.Size = New System.Drawing.Size(363, 22)
        Me.P1.TabIndex = 1
        '
        'TSEP1
        '
        Me.TSEP1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP1.Location = New System.Drawing.Point(0, 12)
        Me.TSEP1.Name = "TSEP1"
        Me.TSEP1.Size = New System.Drawing.Size(363, 10)
        Me.TSEP1.TabIndex = 1
        Me.TSEP1.Text = "ThemeSeparator1"
        '
        'L1
        '
        Me.L1.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(84, Byte), Integer), CType(CType(178, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.L1.AutoSize = True
        Me.L1.Dock = System.Windows.Forms.DockStyle.Top
        Me.L1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.L1.LinkColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.L1.Location = New System.Drawing.Point(0, 0)
        Me.L1.Name = "L1"
        Me.L1.Size = New System.Drawing.Size(74, 15)
        Me.L1.TabIndex = 0
        Me.L1.TabStop = True
        Me.L1.Tag = "-"
        Me.L1.Text = "   Server Info"
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(363, 10)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Closeinformations)
        Me.Panel2.Controls.Add(Me.ThemeTit1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(363, 21)
        Me.Panel2.TabIndex = 1
        '
        'Closeinformations
        '
        Me.Closeinformations.Cursor = System.Windows.Forms.Cursors.Default
        Me.Closeinformations.Dock = System.Windows.Forms.DockStyle.Right
        Me.Closeinformations.Location = New System.Drawing.Point(346, 0)
        Me.Closeinformations.Name = "Closeinformations"
        Me.Closeinformations.Size = New System.Drawing.Size(17, 21)
        Me.Closeinformations.TabIndex = 0
        Me.Closeinformations.TabStop = False
        '
        'ThemeTit1
        '
        Me.ThemeTit1.BackColor = System.Drawing.Color.Transparent
        Me.ThemeTit1.BackColorNone = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ThemeTit1.Cursor = System.Windows.Forms.Cursors.Default
        Me.ThemeTit1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ThemeTit1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.ThemeTit1.FontColorNone = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.ThemeTit1.Location = New System.Drawing.Point(0, 0)
        Me.ThemeTit1.Name = "ThemeTit1"
        Me.ThemeTit1.Size = New System.Drawing.Size(363, 21)
        Me.ThemeTit1.TabIndex = 1
        Me.ThemeTit1.TabStop = False
        Me.ThemeTit1.TxText = "Service Status"
        '
        'BOXDOWN
        '
        Me.BOXDOWN.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BOXDOWN.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BOXDOWN.Location = New System.Drawing.Point(0, 431)
        Me.BOXDOWN.Name = "BOXDOWN"
        Me.BOXDOWN.Size = New System.Drawing.Size(896, 18)
        Me.BOXDOWN.TabIndex = 1
        Me.BOXDOWN.TabStop = False
        '
        'PanelTop
        '
        Me.PanelTop.Controls.Add(Me.TSEP0)
        Me.PanelTop.Controls.Add(Me.MenuStrip1)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Location = New System.Drawing.Point(0, 0)
        Me.PanelTop.Name = "PanelTop"
        Me.PanelTop.Size = New System.Drawing.Size(896, 35)
        Me.PanelTop.TabIndex = 0
        '
        'TSEP0
        '
        Me.TSEP0.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TSEP0.Colour0 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP0.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP0.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP0.Location = New System.Drawing.Point(0, 24)
        Me.TSEP0.Name = "TSEP0"
        Me.TSEP0.Size = New System.Drawing.Size(896, 11)
        Me.TSEP0.TabIndex = 2
        Me.TSEP0.Text = "ThemeSeparator1"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolsToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(896, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutSpyNoteToolStripMenuItem, Me.FacebookToolStripMenuItem})
        Me.HelpToolStripMenuItem.Image = Global.SpyNote_7._0.My.Resources.Resources.AboutSpyNote
        Me.HelpToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutSpyNoteToolStripMenuItem
        '
        Me.AboutSpyNoteToolStripMenuItem.Image = Global.SpyNote_7._0.My.Resources.Resources.AboutSpyNote
        Me.AboutSpyNoteToolStripMenuItem.Name = "AboutSpyNoteToolStripMenuItem"
        Me.AboutSpyNoteToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.AboutSpyNoteToolStripMenuItem.Text = "About SpyNote"
        '
        'FacebookToolStripMenuItem
        '
        Me.FacebookToolStripMenuItem.Name = "FacebookToolStripMenuItem"
        Me.FacebookToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.FacebookToolStripMenuItem.Text = "Facebook"
        '
        'UpdateLabels
        '
        Me.UpdateLabels.Interval = 1000
        '
        'DownPNL
        '
        Me.DownPNL.Interval = 10
        '
        'Trans
        '
        Me.Trans.Interval = 20
        '
        'TScrolls
        '
        Me.TScrolls.Interval = 1
        '
        'SELCT_Apks
        '
        Me.SELCT_Apks.Name = "SELCT_Apks"
        Me.SELCT_Apks.ShowImageMargin = False
        Me.SELCT_Apks.Size = New System.Drawing.Size(36, 4)
        '
        'MainSpyNote
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(896, 449)
        Me.Controls.Add(Me.PCONTROL)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(200, 200)
        Me.Name = "MainSpyNote"
        Me.Opacity = 0R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SpyNote [ Android Hack ] 7.0"
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.ContextTools.ResumeLayout(False)
        Me.ContextView.ResumeLayout(False)
        Me.PCONTROL.ResumeLayout(False)
        Me.PC.ResumeLayout(False)
        Me.PNLWOW.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.PNL0.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextControl.ResumeLayout(False)
        Me.PNLLOGES.ResumeLayout(False)
        Me.MTabControl.ResumeLayout(False)
        Me.TabPageMonitorAndroid.ResumeLayout(False)
        Me.PNLMonitor.ResumeLayout(False)
        CType(Me.DataMonitorAndroidView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PNLTOOL_Monitor.ResumeLayout(False)
        Me.TabPageBlackList.ResumeLayout(False)
        CType(Me.DataBlackListView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PNLTOOL_BlackList.ResumeLayout(False)
        Me.PNLTOOL_BlackList.PerformLayout()
        Me.TabPageConnectionLogs.ResumeLayout(False)
        Me.PanelLogsMove.ResumeLayout(False)
        CType(Me.DataLogsView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PNLTOOL_Logs.ResumeLayout(False)
        Me.PNLLOGESTOP.ResumeLayout(False)
        Me.PNLTEXT.ResumeLayout(False)
        CType(Me.MaximTab, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CloseTab, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LabelText, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelMain.ResumeLayout(False)
        Me.PNL3.ResumeLayout(False)
        CType(Me.GView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.PNL2.ResumeLayout(False)
        CType(Me.NView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.PNL1.ResumeLayout(False)
        CType(Me.PView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.P1.ResumeLayout(False)
        Me.P1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.Closeinformations, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ThemeTit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BOXDOWN, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTop.ResumeLayout(False)
        Me.PanelTop.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ContextTools As ContextMenuStrip
    Friend WithEvents PayloadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FoldersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientsFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientFolderDownloadsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OtherClientFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BuildingFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
    Friend WithEvents ScommandToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CCMDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PowhellToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WndToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FirStartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FirStopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EdweToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReceiveConnectionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckPortsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SdsafdToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SdfsdfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripSeparator
    Friend WithEvents sgsdfgvdfv As ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContextView As ContextMenuStrip
    Friend WithEvents LogsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BlackListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MonitorAndroidToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InformationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripSeparator
    Friend WithEvents OnLoginShowAlertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PCONTROL As Panel
    Friend WithEvents PC As Panel
    Friend WithEvents PNLWOW As Panel
    Friend WithEvents PanelTop As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutSpyNoteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TSEP0 As SN.ThemeSeparator
    Friend WithEvents BOXDOWN As PictureBox
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents PNL0 As Panel
    Friend WithEvents VisualStudioVerticalScrollBar1 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents VisualStudioHorizontalScrollBar1 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ContextControl As ContextMenuStrip
    Friend WithEvents FileManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SMSManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CallsManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContactsManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LocationManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AccountManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CameraManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShellTerminalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ApplicationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MicrophoneToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents KeyloggerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CleintTCPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReconnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToBlackListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PhoneToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FunToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PNLLOGES As Panel
    Friend WithEvents PNLLOGESTOP As Panel
    Friend WithEvents PNLTEXT As Panel
    Friend WithEvents LabelText As SN.ThemeTit
    Friend WithEvents CloseTab As PictureBox
    Friend WithEvents MaximTab As PictureBox
    Friend WithEvents MTabControl As SN.ThemeTabControl
    Friend WithEvents TabPageConnectionLogs As TabPage
    Friend WithEvents PanelLogsMove As Panel
    Friend WithEvents VisualStudioHorizontalScrollBar2 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents VisualStudioVerticalScrollBar3 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents TabPageBlackList As TabPage
    Friend WithEvents PNLTOOL_BlackList As Panel
    Friend WithEvents BADD0 As SN.ThemeButtonImge
    Friend WithEvents TTextAddress As SN.ThemeTextBox
    Friend WithEvents Bdown1 As SN.ThemeButtonImge
    Friend WithEvents LinearLine4 As SN.LinearLine
    Friend WithEvents BRefres0 As SN.ThemeButtonImge
    Friend WithEvents LinearLine5 As SN.LinearLine
    Friend WithEvents BDelete1 As SN.ThemeButtonImge
    Friend WithEvents LBAddress As Label
    Friend WithEvents LinearLine7 As SN.LinearLine
    Friend WithEvents BDeleteAll1 As SN.ThemeButtonImge
    Friend WithEvents LinearLine6 As SN.LinearLine
    Friend WithEvents LNothing1 As Label
    Friend WithEvents DataBlackListView As DataGridView
    Friend WithEvents VisualStudioHorizontalScrollBar3 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents VisualStudioVerticalScrollBar4 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents LinearLine21 As SN.LinearLine
    Friend WithEvents TabPageMonitorAndroid As TabPage
    Friend WithEvents PNLMonitor As Panel
    Friend WithEvents PNLTOOL_Monitor As Panel
    Friend WithEvents BAutoDelete1 As SN.ThemeButtonImge
    Friend WithEvents LinearLine8 As SN.LinearLine
    Friend WithEvents BDeleteAll2 As SN.ThemeButtonImge
    Friend WithEvents LinearLine9 As SN.LinearLine
    Friend WithEvents BDelete2 As SN.ThemeButtonImge
    Friend WithEvents LinearLine10 As SN.LinearLine
    Friend WithEvents Bdown2 As SN.ThemeButtonImge
    Friend WithEvents DataMonitorAndroidView As DataGridView
    Friend WithEvents VisualStudioHorizontalScrollBar4 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents VisualStudioVerticalScrollBar5 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents PanelMain As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents P1 As Panel
    Friend WithEvents L1 As LinkLabel
    Friend WithEvents TSEP1 As SN.ThemeSeparator
    Friend WithEvents PNL1 As Panel
    Friend WithEvents PView As DataGridView
    Friend WithEvents DataGridViewImageColumn1 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents Column33 As DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Panel
    Friend WithEvents L2 As LinkLabel
    Friend WithEvents TSEP2 As SN.ThemeSeparator
    Friend WithEvents PNL2 As Panel
    Friend WithEvents NView As DataGridView
    Friend WithEvents Panel7 As Panel
    Friend WithEvents TSEP3 As SN.ThemeSeparator
    Friend WithEvents L3 As LinkLabel
    Friend WithEvents PNL3 As Panel
    Friend WithEvents GView As DataGridView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Closeinformations As PictureBox
    Friend WithEvents ThemeTit1 As SN.ThemeTit
    Friend WithEvents VisualStudioVerticalScrollBar2 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents UpdateLabels As Timer
    Friend WithEvents DownPNL As Timer
    Friend WithEvents Trans As Timer
    Friend WithEvents TScrolls As Timer
    Friend WithEvents DataLogsView As DataGridView
    Friend WithEvents PNLTOOL_Logs As Panel
    Friend WithEvents BAutoDelete0 As SN.ThemeButtonImge
    Friend WithEvents LinearLine3 As SN.LinearLine
    Friend WithEvents BDeleteAll0 As SN.ThemeButtonImge
    Friend WithEvents LinearLine2 As SN.LinearLine
    Friend WithEvents BDelete0 As SN.ThemeButtonImge
    Friend WithEvents LinearLine1 As SN.LinearLine
    Friend WithEvents Bdown0 As SN.ThemeButtonImge
    Friend WithEvents SELCT_Apks As ContextMenuStrip
    Friend WithEvents DataGridViewImageColumn2 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn3 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents Colum1 As DataGridViewImageColumn
    Friend WithEvents Colum2 As DataGridViewTextBoxColumn
    Friend WithEvents Colum3 As DataGridViewTextBoxColumn
    Friend WithEvents Colum4 As DataGridViewImageColumn
    Friend WithEvents Colum5 As DataGridViewTextBoxColumn
    Friend WithEvents Colum6 As DataGridViewTextBoxColumn
    Friend WithEvents Colum7 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewImageColumn
    Friend WithEvents Colum8 As DataGridViewImageColumn
    Friend WithEvents Colum9 As DataGridViewImageColumn
    Friend WithEvents Colum10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn6 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents ColTime As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents Column44 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn4 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents Str0 As DataGridViewTextBoxColumn
    Friend WithEvents Str1 As DataGridViewImageColumn
    Friend WithEvents Str2 As DataGridViewTextBoxColumn
    Friend WithEvents Str3 As DataGridViewTextBoxColumn
    Friend WithEvents FacebookToolStripMenuItem As ToolStripMenuItem
End Class
