﻿Imports System.Threading

Public Class MainNotice

    Public AddNew As List(Of String) = New List(Of String)
    Private Sub MainNotice_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'siz = 305; 100
        'loc = 3; 132


        'frmsiz = 311; 132
        Dim workingArea As Rectangle = Screen.PrimaryScreen.WorkingArea
        Me.Left = ((workingArea.Width - Me.Width) - 5)
        Me.Top = ((workingArea.Height - Me.Height) - 5)
        Dim i As Thread = New System.Threading.Thread(AddressOf Me.Thread_1)
        i.Start()
    End Sub
    Delegate Sub StringArgReturningVoidDelegate([text] As String)
    Private Sub Thread_1()



        Dim i% = 0
        While Form1.s.TcpState
            If Not AddNew.Count = 0 Then
                If AddNew.Count = i Then
                    i = 0
                    AddNew.Clear()
                Else
                    If Not AddNew(i) = Nothing Then
                        SetText(CStr(AddNew(i)))
                        AddNew(i) = Nothing
                    End If
                    i += 1

                End If
            End If
            Thread.Sleep(store_0.CPU)
        End While

    End Sub

    Private Sub SetText(ByVal [text] As String)

        If Me.DataGridView1.InvokeRequired Then
            Dim d As New StringArgReturningVoidDelegate(AddressOf SetText)
            Me.Invoke(d, New Object() {[text]})
        Else
            Dim t As String = [text]
            If t.Contains(Form1.s.split_Ary) Then
                Dim split_Ary() As String = {Form1.s.split_Ary}
                Dim Ary() As String = t.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)

                If DataGridView1.Visible = False Then
                    DataGridView1.Visible = True
                End If

                Me.DataGridView1.Rows.Add(Form1.imageList_0.Images(CInt(Ary(0))), Ary(1), Ary(2), Ary(3))
                If DataGridView1.Rows.Count > 7 Then
                    DataGridView1.Rows.RemoveAt(0)
                End If
                If Not DataGridView1.Rows.Count = 0 Then
                    ToEnd()
                End If

            End If






        End If
    End Sub
    Private Sub ToEnd()
        Me.DataGridView1.FirstDisplayedScrollingRowIndex = Me.DataGridView1.RowCount - 1
        Me.DataGridView1.CurrentCell = Nothing
        Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Selected = True
        loop_0 = 0
    End Sub

    Dim loop_0% = 0

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Me.DataGridView1.Location.Y >= 2 Then
            Dim y% = Me.DataGridView1.Location.Y
            y = y - 2
            Me.DataGridView1.Location = New System.Drawing.Point(3, y)
        Else
            loop_0 += 1
            If loop_0 >= 400 Then
                DataGridView1.Rows.Clear()
                DataGridView1.Location = New System.Drawing.Point(3, 132)
                loop_0 = 0
                Timer1.Enabled = False
            End If
        End If
    End Sub


    Private Sub DataGridView1_MouseClick(sender As Object, e As MouseEventArgs) Handles DataGridView1.MouseClick
        DataGridView1.Visible = False
    End Sub
End Class