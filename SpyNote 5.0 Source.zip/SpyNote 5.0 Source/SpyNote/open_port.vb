﻿Public Class open_port
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Not CStr(NumericUpDown1.Value) = "0" Then
            DataGridView1.Rows.Add(CStr(NumericUpDown1.Value))

        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If
    End Sub
    Public GroupPrt$ = Nothing
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim ErrorCounter% = 0
        If DataGridView1.SelectedRows.Count <= 0 Then
            Me.ErrorProvider1.SetError(DataGridView1, "Cannot be Empty")
        Else
            Me.ErrorProvider1.SetError(DataGridView1, Nothing)
            ErrorCounter += 1
        End If
        If ErrorCounter = 1 Then
            If DataGridView1.SelectedRows.Count > 0 Then
                For r% = 0 To DataGridView1.Rows.Count - 1
                    GroupPrt += DataGridView1.Rows(r).Cells(0).Value + ","
                Next
                GroupPrt = GroupPrt.Remove(GroupPrt.Length - 1)
            End If
            Me.DialogResult = DialogResult.OK
            My.Settings.SVPORT = CInt(NumericUpDown1.Value)
            My.Settings.SVLISTPORT = GroupPrt
            My.Settings.Save()
        End If

    End Sub
    Sub tx(ByVal idstr As String)
        Text = idstr
    End Sub
    Private Sub open_port_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Me.Location = New System.Drawing.Point(Form1.Location.X, Form1.Location.Y)



        Dim ary$() = My.Settings.SVLISTPORT.Trim.Split(",")
        For Each prt In ary
            If IsNumeric(prt) Then
                DataGridView1.Rows.Add(prt.Trim)
            End If
        Next



        NumericUpDown1.Value = My.Settings.SVPORT




        ErrorProvider1.Icon = store_0.icons_0("errors")
        Me.Icon = store_0.icons_0("window")
    End Sub
End Class