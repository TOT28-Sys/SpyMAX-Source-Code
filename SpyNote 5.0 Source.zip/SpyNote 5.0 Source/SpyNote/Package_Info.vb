﻿Public Class Package_Info
    Public handle_Package_Info As Integer
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    'Public sender_name As String
    'Public sender_number As String
    Sub Package_Info_00(ByVal data As String)
        Try
            If data IsNot Nothing Then




                Dim split_Ary() As String = {Form1.s.split_Ary}
                Dim Ary() As String = data.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                If Ary.Length >= 10 Then
                    Dim Converts() As Byte = Convert.FromBase64String(Ary(0))
                    Dim ms As New IO.MemoryStream(Converts)
                    Dim base64 As New Bitmap(Image.FromStream(ms))
                    PictureBox1.Image = base64
                    ms.Dispose()

                    TextBox1.Text = Ary(1)
                    Label3.Text = Ary(2)
                    TextBox2.Text = Ary(3)
                    Label6.Text = Ary(4)
                    TextBox3.Text = store_0.FormatFileSize(CLng(Ary(5)))
                    TextBox4.Text = Ary(6)
                    TextBox5.Text = Ary(7)
                    TextBox6.Text = Ary(8)
                    TextBox7.Text = Ary(9)
                End If
                If Ary.Length > 10 Then
                    If Not Ary(10) = Nothing Then

                        If Ary(10).Contains(Form1.s.split_Line) Then
                            Dim spl_LN() As String = {Form1.s.split_Line}
                            Dim ln() As String = Ary(10).Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                            For i As Integer = 0 To ln.Length - 1
                                RichTextBox1.Text += ln(i) + vbNewLine
                            Next
                        Else
                            RichTextBox1.Text = Ary(10)
                        End If




                    End If

                End If


            End If





            'End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Package_Info_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox3.Image = store_0.Bitmap_0("ctx_applications_manager")
        PictureBox2.Image = store_0.Bitmap_0("ctx_file_manager")
        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1

        TabPage1.Text = "App Info"
        TabPage2.Text = "App permissions"
        Me.Icon = store_0.icons_0("window")

        Dim title As String = String.Format("Properties" & " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Try
            Dim st$ = TextBox4.Text
            If Not st = Nothing Then
                If st.Contains("/") Then
                    Dim a0, a1, a2, spl As String
                    spl = "/"
                    a0 = st
                    a1 = spl
                    If a0 = Nothing Then Exit Sub
                    If a0 = spl Then Exit Sub
                    Dim e0 As New System.Text.RegularExpressions.Regex(a1)
                    Dim e1 As System.Text.RegularExpressions.MatchCollection : e1 = e0.Matches(a0)
                    a2 = a0.Split(spl)(e1.Count.ToString())
                    Dim pt$ = st.Replace(spl + a2, Nothing)
                    Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + pt)
                End If
            End If

        Catch ex As Exception

        End Try







    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Try
            Dim st$ = TextBox2.Text
            If Not st = Nothing Then
                Dim action$ = "https://play.google.com/store/apps/details?id=" + st
                Process.Start(action)
            End If
        Catch ex As Exception

        End Try

    End Sub
End Class