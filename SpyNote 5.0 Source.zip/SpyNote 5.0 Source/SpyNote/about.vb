﻿Public Class about
    Private Sub about_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Label1.Text = store_0.name_prog + ":"
        PictureBox1.Image = store_0.Bitmap_0("img_0")
    End Sub
End Class