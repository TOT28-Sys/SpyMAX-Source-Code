﻿Public Class editor_sms
    Public handle_SMS As Integer
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Public sender_name As String
    Public sender_number As String
    Sub editor_sms_00(ByVal data As String)
        RichTextBox1.Text = data
    End Sub







    Private Sub editor_sms_Load(sender As Object, e As EventArgs) Handles MyBase.Load




        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1
        Me.Icon = store_0.icons_0("window")

        Dim title As String = String.Format("SMS Editor" & " - Remote Address & Port: {0} Client Name: {1} Name: {2} Number: {3}", Client_remote_Address, Name_Client, sender_name, sender_number)
        Text = title
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub




End Class