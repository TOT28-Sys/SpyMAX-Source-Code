﻿Public Class Shell_Terminal

    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then


                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim Except() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    DataGridView1.Rows.Add(Me.DataGridView1.RowCount - 1, "Shell Terminal : " + Client_remote_Address + " Outputs>", Except(0))
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(2).Style.ForeColor = System.Drawing.Color.Salmon

                    ToEnd()
                Else

                    Dim spl_LN() As String = {Form1.s.split_Line}
                    Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                    For i As Integer = 0 To ln.Length - 1
                        DataGridView1.Rows.Add(Me.DataGridView1.RowCount - 1, "Shell Terminal : " + Client_remote_Address + " Outputs>", ln(i))
                        DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(2).Style.BackColor = System.Drawing.Color.FromArgb(10, 10, 10)
                        ToEnd()
                    Next

                    '--->
                End If


                refres_title()
            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub ToEnd()
        Me.DataGridView1.FirstDisplayedScrollingRowIndex = Me.DataGridView1.RowCount - 1
        Me.DataGridView1.CurrentCell = Nothing
        Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Selected = True
    End Sub

    Private Sub Shell_Terminal_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        CopyToolStripMenuItem.Image = store_0.Bitmap_0("ctx_copy")

        EditToolStripMenuItem.Image = store_0.Bitmap_0("ctx_edit")


        ContextMenuStrip1.Renderer = New Theme_0
        Dim list() As String = IO.File.ReadAllLines(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Terminal.inf")
        For Each i In list
            TextBox1.AutoCompleteCustomSource.AddRange(New String() {i})
        Next
        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Shell Terminal" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub
    Sub Send(IP$, Data$)
        Try


            If CheckBox1.Checked = True Then
                DataGridView1.Rows.Add(Me.DataGridView1.RowCount - 1, IP, "@root " + Data)
                DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(2).Style.ForeColor = System.Drawing.Color.RosyBrown
                Form1.s.Send(handle_Number_Client, "shell_terminal" + Form1.s.SplitData + Data + Form1.s.SplitData + "root@")
            Else
                DataGridView1.Rows.Add(Me.DataGridView1.RowCount - 1, IP, Data)
                DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(2).Style.ForeColor = System.Drawing.Color.LightSeaGreen
                Form1.s.Send(handle_Number_Client, "shell_terminal" + Form1.s.SplitData + Data + Form1.s.SplitData + "0")
            End If
            ToEnd()

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub TextBox1_GotFocus(sender As Object, e As EventArgs) Handles TextBox1.GotFocus
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
    End Sub
    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            Send("Shell Terminal : " + Client_remote_Address + " Input>", TextBox1.Text)
            TextBox1.Text = String.Empty
        End If
    End Sub
    Private Sub EditToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.Click
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub RemoveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If
    End Sub

    Private Sub CleanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CleanToolStripMenuItem.Click
        DataGridView1.Rows.Clear()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Dim myCopy As System.Text.StringBuilder = New System.Text.StringBuilder()
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim p1$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                Dim p2$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value
                myCopy.Append(p1 + Space(1) + p2 + vbNewLine)
            Next
            If Not myCopy.ToString = Nothing Then
                Try
                    My.Computer.Clipboard.SetText(myCopy.ToString.Trim)
                Catch ex As Exception
                End Try
            End If

        End If


    End Sub
End Class