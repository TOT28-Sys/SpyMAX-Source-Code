﻿Public Class UserControl1
    Private Sub UserControl1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub DataLogs_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataLogs.CellContentClick

    End Sub

    Private Sub DataLogs_KeyDown(sender As Object, e As KeyEventArgs) Handles DataLogs.KeyDown
        If e.KeyCode = Keys.H Then
            Form1.PKeyDown(False)
        ElseIf e.KeyCode = Keys.S Then
            Form1.PKeyDown(True)
        End If
    End Sub

End Class
