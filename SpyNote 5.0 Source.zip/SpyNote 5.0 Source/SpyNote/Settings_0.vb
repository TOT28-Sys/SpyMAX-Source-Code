﻿Public Class Settings_0
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged


    End Sub

    Private Sub Settings_0_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = store_0.icons_0("window")
        Select Case CInt(My.Settings.Data_encoding)
            Case 0
                ComboBox1.Text = "Default"
            Case 1
                ComboBox1.Text = "UTF7"
            Case 2
                ComboBox1.Text = "UTF8"
            Case 3
                ComboBox1.Text = "UTF32"
            Case 4
                ComboBox1.Text = "Unicode"
            Case 5
                ComboBox1.Text = "ASCII"
            Case 6
                ComboBox1.Text = "BigEndianUnicode"
            Case Else
                ComboBox1.Text = "Unknown error"
        End Select



        Select Case CInt(My.Settings.Process_Priority)
            Case 0
                ComboBox2.Text = "RealTime"
            Case 1
                ComboBox2.Text = "High"
            Case 2
                ComboBox2.Text = "AboveNormal"
            Case 3
                ComboBox2.Text = "Normal"
            Case 4
                ComboBox2.Text = "BelowNormal"
            Case 5
                ComboBox2.Text = "Idle"
            Case Else
                ComboBox2.Text = "Unknown error"
        End Select




        If Not My.Settings.Protocol_tcp = 0 Then
            CheckBox2.Checked = True
        Else
            CheckBox2.Checked = False
        End If
        If Not My.Settings.Protocol_udp = 0 Then
            CheckBox1.Checked = True
        Else
            CheckBox1.Checked = False
        End If



        NumericUpDown1.Value = My.Settings.Maximum_Clients





        If Not store_0.IF_Admin Then
            GroupBox2.Enabled = False
        End If



        If My.Settings.Windows_foreground = True Then
            CheckBox4.Checked = True
        Else
            CheckBox4.Checked = False
        End If



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        My.Settings.Data_encoding = CInt(ComboBox1.SelectedIndex)

        If CheckBox2.Checked = True Then
            My.Settings.Protocol_tcp = 1
        Else
            My.Settings.Protocol_tcp = 0
        End If
        If CheckBox1.Checked = True Then
            My.Settings.Protocol_udp = 1
        Else
            My.Settings.Protocol_udp = 0
        End If


        My.Settings.Maximum_Clients = CInt(NumericUpDown1.Value)



        My.Settings.Process_Priority = CInt(ComboBox2.SelectedIndex)


        myProcessPreference()

        If CheckBox4.Checked = True Then
            My.Settings.Windows_foreground = True
        Else
            My.Settings.Windows_foreground = False
        End If






        My.Settings.Save()


        If Form1.s.ListenerTCP.Count > 0 Then
            MsgBox("Some features work after you restart the listener", MsgBoxStyle.Information)
        End If


        Me.Close()
    End Sub


End Class