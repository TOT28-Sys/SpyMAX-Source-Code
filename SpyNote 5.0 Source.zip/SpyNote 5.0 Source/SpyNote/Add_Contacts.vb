﻿Public Class Add_Contacts
    Private Sub Add_Contacts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Icon = store_0.icons_0("window")
        ErrorProvider1.Icon = store_0.icons_0("errors")
    End Sub
    Private Sub Add_Contacts_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ErrorProvider1.Clear()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim ErrorCounter% = 0

        For Each ctrl As Control In GroupBox1.Controls
            If TypeName(ctrl) = "TextBox" Then
                If ctrl.Tag = "ERROR" Then
                    If ctrl.Text.Length = 0 Then
                        Me.ErrorProvider1.SetError(ctrl, "Cannot be Empty")
                    Else
                        Me.ErrorProvider1.SetError(ctrl, Nothing)
                        ErrorCounter += 1
                    End If
                End If
            End If
        Next


        If ErrorCounter = 2 Then
            Me.DialogResult = DialogResult.OK

        End If





    End Sub
End Class